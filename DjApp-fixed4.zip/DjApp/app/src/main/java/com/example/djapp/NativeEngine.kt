package com.example.djapp

object NativeEngine {
    init { System.loadLibrary("djengine") }
    external fun start(): Boolean
    external fun stop()
    /** Loads the full mix (instant play). Resets position. */
    external fun loadDeck(deck: Int, pcmPath: String, sampleRate: Int)
    /** Swaps in 4 stems (vocals, drums, bass, other) without interrupting playback. */
    external fun setStems(deck: Int, paths: Array<String>)
    external fun setStemVolume(deck: Int, stem: Int, volume: Float)
    external fun setPlaying(deck: Int, playing: Boolean)
    external fun isPlaying(deck: Int): Boolean
    external fun setVolume(deck: Int, volume: Float)
    external fun setTempo(deck: Int, tempo: Float)
    external fun setCrossfader(x: Float)
    external fun getPosition(deck: Int): Double
    external fun getDuration(deck: Int): Double
    external fun seek(deck: Int, seconds: Double)
    external fun getLevel(): Float

    /** Scratch: while [active] the deck plays at [rate] x speed (negative = backwards). */
    external fun setJog(deck: Int, active: Boolean, rate: Float)
    /** Loop between two track positions (seconds). */
    external fun setLoop(deck: Int, startSec: Double, endSec: Double, on: Boolean)

    /** DJ filter: -1 = low-pass closed, 0 = off, +1 = high-pass closed. */
    external fun setFilter(deck: Int, value: Float)
    external fun setReverb(deck: Int, wet: Float, room: Float)
    external fun setPhaser(deck: Int, amount: Float, rateHz: Float)

    external fun startRecording(path: String): Boolean
    external fun stopRecording()
}
