package com.example.djapp

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class Panel(val title: String) {
    None(""), Stems("STEMS"), Loop("LOOP"), Mixer("MIXER"), Fx("EFFECTS"), Pads("HOT CUES"), Library("LIBRARY"), Settings("SETTINGS")
}

@Composable
fun PanelHost(panel: Panel, decks: List<DeckState>, onLoad: (Int, android.net.Uri) -> Unit, onClose: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(12.dp)).background(PanelBg.copy(alpha = 0.98f))
            .pointerInput(Unit) {   // swallow touches so nothing leaks to the platters underneath
                awaitPointerEventScope { while (true) awaitPointerEvent().changes.forEach { it.consume() } }
            }
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(28.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(panel.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 2.sp)
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(28.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                Text("✕", color = TextGray, fontSize = 15.sp)
            }
        }
        if (panel == Panel.Settings) {
            Box(Modifier.weight(1f).fillMaxWidth()) { SettingsPanel(decks) }
        } else if (panel == Panel.Library) {
            Box(Modifier.weight(1f).fillMaxWidth()) { LibraryPanel(onLoad) }
        } else {
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                for (d in decks) Column(Modifier.weight(1f).fillMaxHeight()) {
                    Text(
                        if (d.loaded) d.name else (if (d.id == 0) "DECK A" else "DECK B"),
                        color = d.accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                    when (panel) {
                        Panel.Stems -> StemsPanel(d)
                        Panel.Loop -> LoopPanel(d)
                        Panel.Mixer -> MixerPanel(d)
                        Panel.Fx -> FxPanel(d)
                        Panel.Pads -> PadsPanel(d)
                        else -> {}
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Stems
private val STEM_LABELS = listOf("VOCALS", "DRUMS", "BASS", "OTHER")

@Composable
private fun ColumnScope.StemsPanel(d: DeckState) {
    val ready = d.stemsReady
    val status = when {
        !d.loaded -> "Load a track first"
        ready -> "Stems ready"
        d.stemProg in 0f..1f -> "Preparing stems… ${(d.stemProg * 100).toInt()}%  (full mix keeps playing)"
        else -> "Stems unavailable"
    }
    Text(status, color = TextGray, fontSize = 10.sp, maxLines = 1)
    Row(Modifier.weight(1f).fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (i in 0..3) Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
            PadButton(STEM_LABELS[i], Modifier.fillMaxWidth().height(28.dp), active = d.stemOn[i] && ready, color = d.accent, enabled = ready, fontSize = 9) { d.toggleStem(i) }
            VFader(d.stemLevel[i], d.accent, ready, Modifier.weight(1f).fillMaxWidth()) { d.setStemLevel(i, it) }
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        PadButton("ACAPELLA", Modifier.weight(1f).height(28.dp), enabled = ready, fontSize = 9) { d.soloStem(0) }
        PadButton("NO VOCALS", Modifier.weight(1f).height(28.dp), enabled = ready, fontSize = 9) { d.muteOnly(0) }
        PadButton("BEATLESS", Modifier.weight(1f).height(28.dp), enabled = ready, fontSize = 9) { d.muteOnly(1) }
        PadButton("RESET", Modifier.weight(1f).height(28.dp), enabled = ready, fontSize = 9) { d.resetStems() }
    }
}

// ------------------------------------------------------------------ Loop
private val BEATS = listOf(0.25f to "1/4", 0.5f to "1/2", 1f to "1", 2f to "2", 4f to "4", 8f to "8", 16f to "16")

@Composable
private fun LoopPanel(d: DeckState) {
    val hasBpm = d.bpm > 0f
    Text(
        when {
            !d.loaded -> "Load a track first"
            d.loopActive && d.loopBeats > 0 -> "LOOP ON · ${BEATS.firstOrNull { it.first == d.loopBeats }?.second ?: "%.2f".format(d.loopBeats)} beats"
            d.loopActive -> "LOOP ON · %.2f s".format(d.loopOut - d.loopIn)
            !hasBpm -> "Detecting BPM… (manual IN/OUT works now)"
            else -> "Tap a beat length to loop from the current position"
        },
        color = if (d.loopActive) d.accent else TextGray, fontSize = 10.sp, maxLines = 1
    )
    Spacer(Modifier.height(6.dp))
    Text("AUTO LOOP (beats)", color = TextGray, fontSize = 9.sp)
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for ((b, label) in BEATS)
            PadButton(label, Modifier.weight(1f), active = d.loopActive && d.loopBeats == b, color = d.accent, enabled = d.loaded && hasBpm) { d.beatLoop(b) }
    }
    Spacer(Modifier.height(8.dp))
    Text("MANUAL", color = TextGray, fontSize = 9.sp)
    Row(Modifier.fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        PadButton("LOOP IN", Modifier.weight(1f), enabled = d.loaded) { d.loopInSet() }
        PadButton("LOOP OUT", Modifier.weight(1f), active = d.loopActive && d.loopBeats == 0f, color = d.accent, enabled = d.loaded) { d.loopOutSet() }
        PadButton(if (d.loopActive) "EXIT" else "RELOOP", Modifier.weight(1f), enabled = d.loaded && (d.loopActive || d.loopOut > d.loopIn)) {
            if (d.loopActive) d.exitLoop() else d.reloop()
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        PadButton("½  SHORTER", Modifier.weight(1f), enabled = d.loopActive) { d.halveLoop() }
        PadButton("×2  LONGER", Modifier.weight(1f), enabled = d.loopActive) { d.doubleLoop() }
    }
}

// ------------------------------------------------------------------ Mixer
@Composable
private fun MixerPanel(d: DeckState) {
    FxSlider("VOLUME", d.vol, 0f..1f, d.accent, "${(d.vol * 100).toInt()}%") { d.vol = it; d.pushVolume() }
    FxSlider("FILTER", d.filter, -1f..1f, d.accent, filterText(d.filter), centered = true) { d.filter = it; d.pushFilter() }
    Text("◄ low-pass          high-pass ►", color = TextGray, fontSize = 9.sp, modifier = Modifier.padding(start = 56.dp))
    Spacer(Modifier.height(6.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        PadButton("FILTER OFF", Modifier.width(100.dp), enabled = d.filter != 0f) { d.filter = 0f; d.pushFilter() }
    }
}

private fun filterText(v: Float) = when {
    v < -0.02f -> "LP ${(-v * 100).toInt()}"
    v > 0.02f -> "HP ${(v * 100).toInt()}"
    else -> "OFF"
}

// ------------------------------------------------------------------ Effects
@Composable
private fun FxPanel(d: DeckState) {
    FxSlider("FILTER", d.filter, -1f..1f, d.accent, filterText(d.filter), centered = true) { d.filter = it; d.pushFilter() }
    FxSlider("REVERB", d.reverb, 0f..1f, d.accent, "${(d.reverb * 100).toInt()}%") { d.reverb = it; d.pushReverb() }
    FxSlider("ROOM", d.room, 0f..1f, d.accent, "${(d.room * 100).toInt()}%") { d.room = it; d.pushReverb() }
    FxSlider("PHASER", d.phaser, 0f..1f, d.accent, "${(d.phaser * 100).toInt()}%") { d.phaser = it; d.pushPhaser() }
    FxSlider("RATE", d.phRate, 0.1f..4f, d.accent, "%.1f Hz".format(d.phRate)) { d.phRate = it; d.pushPhaser() }
    Spacer(Modifier.height(4.dp))
    PadButton("ALL FX OFF", Modifier.width(110.dp), enabled = d.filter != 0f || d.reverb > 0f || d.phaser > 0f) { d.resetFx() }
}

// ------------------------------------------------------------------ Hot cues
private val PAD_COLORS = listOf(Color(0xFFFF5C7A), Color(0xFFFFB74D), Color(0xFF64B5F6), Color(0xFFBA68C8))

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PadsPanel(d: DeckState) {
    Text("Tap: set / jump · Long-press: clear", color = TextGray, fontSize = 10.sp)
    Spacer(Modifier.height(6.dp))
    for (row in 0..1) Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (col in 0..1) {
            val i = row * 2 + col
            val set = d.hotcues[i] >= 0
            Box(
                Modifier.weight(1f).height(52.dp).clip(RoundedCornerShape(8.dp))
                    .background(if (set) PAD_COLORS[i] else Color(0xFF2F333B))
                    .combinedClickable(enabled = d.loaded, onClick = { d.hotcue(i) }, onLongClick = { d.clearHotcue(i) }),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (set) "${i + 1}  ·  %d:%02d".format(d.hotcues[i].toInt() / 60, d.hotcues[i].toInt() % 60) else "${i + 1}  SET",
                    color = if (set) Color.Black else TextGray, fontSize = 12.sp, fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ------------------------------------------------------------------ Settings
@Composable
private fun SettingsPanel(decks: List<DeckState>) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("TEMPO RANGE", color = TextGray, fontSize = 10.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((r, label) in listOf(0.08f to "±8%", 0.16f to "±16%", 0.5f to "±50%"))
                PadButton(label, Modifier.width(80.dp), active = AppSettings.tempoRange == r) {
                    AppSettings.tempoRange = r; decks.forEach { it.applyTempo(it.tempoPct) }
                }
        }
        Text("STEM QUALITY  (applies to the next track you load)", color = TextGray, fontSize = 10.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PadButton("FAST", Modifier.width(90.dp), active = !AppSettings.aiStems && !AppSettings.betterStems) { AppSettings.aiStems = false; AppSettings.betterStems = false }
            PadButton("BETTER", Modifier.width(90.dp), active = !AppSettings.aiStems && AppSettings.betterStems) { AppSettings.aiStems = false; AppSettings.betterStems = true }
            PadButton("AI", Modifier.width(90.dp), active = AppSettings.aiStems) { AppSettings.aiStems = true }
        }
        Text(
            if (AppSettings.aiStems) "AI: neural network (HT-Demucs) running fully offline on your phone. The model is built into the app and is unpacked once on first use. Each track takes a few minutes to prepare while the full mix keeps playing. Falls back to BETTER if it can't run."
            else if (AppSettings.betterStems) "Better: STFT percussive/harmonic + centre-channel split. Slower to prepare, much cleaner."
            else "Fast: simple filters. Ready in seconds, rougher separation.",
            color = TextGray, fontSize = 10.sp
        )
    }
}
