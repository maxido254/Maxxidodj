#include <jni.h>
#include <oboe/Oboe.h>
#include <atomic>
#include <mutex>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

struct Deck {
    std::mutex lock;                      // audio thread only try_locks it
    const int16_t *stem[4] = {nullptr, nullptr, nullptr, nullptr};  // memory-mapped stereo int16
    size_t mapBytes[4] = {0, 0, 0, 0};
    int nStems = 0;                       // 1 = full mix, 4 = stems
    int64_t frames = 0;
    int fileRate = 44100;
    double pos = 0;
    std::atomic<bool> playing{false};
    std::atomic<float> volume{1.f}, tempo{1.f};
    std::atomic<float> stemVol[4];
    std::atomic<double> posOut{0};
    std::atomic<float> filter{0.5f}, reverb{0.f};
    std::atomic<bool> loopEnabled{false};
    std::atomic<double> loopStart{0.0}, loopEnd{4.0};
    float lowL = 0.f, lowR = 0.f;
    float delayL[12000] = {}, delayR[12000] = {};
    int delayPos = 0;
    Deck() { for (auto &v : stemVol) v = 1.f; }
};

class Engine : public oboe::AudioStreamDataCallback {
public:
    Deck decks[2];
    std::atomic<float> crossfader{0.5f};
    std::shared_ptr<oboe::AudioStream> stream;
    int32_t lastXrun = 0;
    std::atomic<int> sampler{ -1 };
    std::atomic<int> samplerCountdown{0};
    std::atomic<double> samplerPhase{0.0};

    bool start() {
        oboe::AudioStreamBuilder b;
        b.setDirection(oboe::Direction::Output)
         ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
         ->setSharingMode(oboe::SharingMode::Exclusive)
         ->setFormat(oboe::AudioFormat::Float)
         ->setChannelCount(2)
         ->setUsage(oboe::Usage::Media)
         ->setDataCallback(this);
        if (b.openStream(stream) != oboe::Result::OK) return false;
        stream->setBufferSizeInFrames(stream->getFramesPerBurst() * 3);
        return stream->requestStart() == oboe::Result::OK;
    }
    void stop() { if (stream) { stream->stop(); stream->close(); stream.reset(); } }

    oboe::DataCallbackResult onAudioReady(oboe::AudioStream *s, void *data, int32_t n) override {
        auto xr = s->getXRunCount();
        if (xr && xr.value() > lastXrun) {   // grow buffer on underrun (weak CPUs)
            lastXrun = xr.value();
            s->setBufferSizeInFrames(s->getBufferSizeInFrames() + s->getFramesPerBurst());
        }
        float *out = static_cast<float *>(data);
        memset(out, 0, sizeof(float) * 2 * n);
        float x = crossfader.load();
        float gain[2] = { cosf(x * (float)M_PI / 2), sinf(x * (float)M_PI / 2) };
        for (int d = 0; d < 2; d++) {
            Deck &k = decks[d];
            if (!k.playing.load()) continue;
            std::unique_lock<std::mutex> g(k.lock, std::try_to_lock);
            if (!g.owns_lock() || k.frames < 2 || k.nStems == 0) continue;
            float vol = k.volume.load() * gain[d] / 32768.f;
            double step = (double)k.fileRate / s->getSampleRate() * k.tempo.load();
            float sv[4]; int act[4]; int na = 0;
            for (int i = 0; i < k.nStems; i++) { sv[i] = k.stemVol[i].load(); if (sv[i] > 0.001f) act[na++] = i; }
            for (int i = 0; i < n; i++) {
                if (k.loopEnabled.load()) {
                    double ls = k.loopStart.load() * k.fileRate, le = k.loopEnd.load() * k.fileRate;
                    if (le > ls + 2 && k.pos >= le) k.pos = std::max(0.0, ls);
                }
                int64_t p = (int64_t)k.pos;
                if (p + 1 >= k.frames) { k.playing = false; break; }
                float f = (float)(k.pos - p), l = 0, r = 0;
                for (int j = 0; j < na; j++) {
                    int si = act[j];
                    const int16_t *a = &k.stem[si][p * 2], *c = a + 2;
                    l += sv[si] * (a[0] + (c[0] - a[0]) * f);
                    r += sv[si] * (a[1] + (c[1] - a[1]) * f);
                }
                float flt = k.filter.load();
                float cutoff = 0.015f + 0.45f * std::abs(flt - 0.5f) * 2.f;
                k.lowL += cutoff * (l - k.lowL);
                k.lowR += cutoff * (r - k.lowR);
                if (flt < 0.48f) { l = k.lowL; r = k.lowR; }
                else if (flt > 0.52f) { l -= k.lowL; r -= k.lowR; }
                int dp = k.delayPos;
                float rv = k.reverb.load();
                float dl = k.delayL[dp], dr = k.delayR[dp];
                k.delayL[dp] = l + dl * 0.35f;
                k.delayR[dp] = r + dr * 0.35f;
                k.delayPos = (dp + 1) % 12000;
                l = l * (1.f - rv * 0.25f) + dl * rv;
                r = r * (1.f - rv * 0.25f) + dr * rv;
                out[2 * i] += l * vol;
                out[2 * i + 1] += r * vol;
                k.pos += step;
            }
            k.posOut = k.pos / k.fileRate;
        }
        int sm = sampler.load();
        int rem = samplerCountdown.load();
        if (sm >= 0 && rem > 0) {
            double phase = samplerPhase.load();
            for (int i = 0; i < n && rem > 0; ++i, --rem) {
                float env = (float)rem / (float)std::max(1, s->getSampleRate() / 2);
                float v = 0.f;
                if (sm == 0) { v = (std::sin(phase * 2.0 * M_PI) > 0.0 ? 0.8f : -0.8f) * env; phase += 880.0 / s->getSampleRate(); }
                else if (sm == 1) { v = std::sin(phase * 2.0 * M_PI) * env * 0.7f; phase += (220.0 + 500.0 * std::sin(phase * 0.4)) / s->getSampleRate(); }
                else if (sm == 2) { v = std::sin(phase * 2.0 * M_PI) * env; phase += 65.0 / s->getSampleRate(); }
                else { v = std::sin(phase * 2.0 * M_PI) * env * 0.65f; phase += 1800.0 / s->getSampleRate(); }
                out[2*i] += v; out[2*i+1] += v;
            }
            samplerPhase = phase; samplerCountdown = rem;
            if (rem <= 0) sampler = -1;
        }
        for (int i = 0; i < n * 2; ++i) out[i] = std::max(-1.0f, std::min(1.0f, out[i]));
        return oboe::DataCallbackResult::Continue;
    }
};

static Engine engine;

static bool mapFile(const char *path, const int16_t *&out, size_t &bytes) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) return false;
    struct stat st;
    if (fstat(fd, &st) != 0 || st.st_size < 8) { close(fd); return false; }
    void *m = mmap(nullptr, st.st_size, PROT_READ, MAP_PRIVATE | MAP_POPULATE, fd, 0);
    close(fd);
    if (m == MAP_FAILED) return false;
    out = (const int16_t *)m; bytes = st.st_size;
    return true;
}

// Mapping happens outside the lock; only the pointer swap is locked so audio never stalls.
static void swapIn(Deck &k, const int16_t *p[4], size_t b[4], int n, int rate, bool resetPos) {
    int64_t frames = 0;
    if (n > 0) { frames = (int64_t)(b[0] / 4); for (int i = 1; i < n; i++) frames = std::min(frames, (int64_t)(b[i] / 4)); }
    std::lock_guard<std::mutex> g(k.lock);
    for (int i = 0; i < 4; i++) if (k.stem[i]) munmap((void *)k.stem[i], k.mapBytes[i]);
    for (int i = 0; i < 4; i++) { k.stem[i] = i < n ? p[i] : nullptr; k.mapBytes[i] = i < n ? b[i] : 0; }
    k.nStems = n; k.frames = frames;
    if (rate > 0) k.fileRate = rate;
    if (resetPos) { k.pos = 0; k.posOut = 0; for (auto &v : k.stemVol) v = 1.f; }
    else if (k.pos >= frames - 2) k.pos = std::max<int64_t>(0, frames - 2);
}

extern "C" {
JNIEXPORT jboolean JNICALL Java_com_example_djapp_NativeEngine_start(JNIEnv *, jobject) { return engine.start(); }
JNIEXPORT void JNICALL Java_com_example_djapp_NativeEngine_stop(JNIEnv *, jobject) { engine.stop(); }

JNIEXPORT void JNICALL Java_com_example_djapp_NativeEngine_loadDeck(JNIEnv *env, jobject, jint d, jstring path, jint rate) {
    Deck &k = engine.decks[d];
    k.playing = false;
    const int16_t *p[4] = {nullptr, nullptr, nullptr, nullptr}; size_t b[4] = {0, 0, 0, 0};
    const char *s = env->GetStringUTFChars(path, nullptr);
    int n = mapFile(s, p[0], b[0]) ? 1 : 0;
    env->ReleaseStringUTFChars(path, s);
    swapIn(k, p, b, n, rate, true);
}

JNIEXPORT void JNICALL Java_com_example_djapp_NativeEngine_setStems(JNIEnv *env, jobject, jint d, jobjectArray paths) {
    Deck &k = engine.decks[d];
    const int16_t *p[4] = {nullptr, nullptr, nullptr, nullptr}; size_t b[4] = {0, 0, 0, 0};
    bool ok = env->GetArrayLength(paths) == 4;
    for (int i = 0; i < 4 && ok; i++) {
        jstring js = (jstring)env->GetObjectArrayElement(paths, i);
        const char *s = env->GetStringUTFChars(js, nullptr);
        ok = mapFile(s, p[i], b[i]);
        env->ReleaseStringUTFChars(js, s);
        env->DeleteLocalRef(js);
    }
    if (!ok) { for (int i = 0; i < 4; i++) if (p[i]) munmap((void *)p[i], b[i]); return; }
    swapIn(k, p, b, 4, 0, false);   // keeps position and keeps playing
}

JNIEXPORT void JNICALL Java_com_example_djapp_NativeEngine_setStemVolume(JNIEnv *, jobject, jint d, jint s, jfloat v) { engine.decks[d].stemVol[s] = v; }
JNIEXPORT void JNICALL Java_com_example_djapp_NativeEngine_setPlaying(JNIEnv *, jobject, jint d, jboolean p) { engine.decks[d].playing = p; }
JNIEXPORT void JNICALL Java_com_example_djapp_NativeEngine_setVolume(JNIEnv *, jobject, jint d, jfloat v) { engine.decks[d].volume = v; }
JNIEXPORT void JNICALL Java_com_example_djapp_NativeEngine_setTempo(JNIEnv *, jobject, jint d, jfloat t) { engine.decks[d].tempo = t; }
JNIEXPORT void JNICALL Java_com_example_djapp_NativeEngine_setCrossfader(JNIEnv *, jobject, jfloat x) { engine.crossfader = x; }
JNIEXPORT jdouble JNICALL Java_com_example_djapp_NativeEngine_getPosition(JNIEnv *, jobject, jint d) { return engine.decks[d].posOut.load(); }
JNIEXPORT void JNICALL Java_com_example_djapp_NativeEngine_setFilter(JNIEnv *, jobject, jint d, jfloat v) { engine.decks[d].filter = v; }
JNIEXPORT void JNICALL Java_com_example_djapp_NativeEngine_setReverb(JNIEnv *, jobject, jint d, jfloat v) { engine.decks[d].reverb = v; }
JNIEXPORT void JNICALL Java_com_example_djapp_NativeEngine_setLoop(JNIEnv *, jobject, jint d, jboolean en, jdouble a, jdouble b) {
    auto &k = engine.decks[d]; k.loopStart = std::max(0.0, a); k.loopEnd = std::max(a + 0.25, b); k.loopEnabled = en;
}
JNIEXPORT void JNICALL Java_com_example_djapp_NativeEngine_triggerSampler(JNIEnv *, jobject, jint sm) {
    engine.sampler = sm; engine.samplerPhase = 0.0; engine.samplerCountdown = 22050;
}
}
