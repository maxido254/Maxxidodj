package com.example.djapp

import android.net.Uri
import android.os.Bundle
import android.os.Process
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.roundToInt

private val prepDispatcher = Executors.newSingleThreadExecutor { r ->
    Thread({ Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND); r.run() }, "stem-prep")
}.asCoroutineDispatcher()

private val purple = Color(0xFF6840D0)
private val mint = Color(0xFF35C9AD)
private val panel = Color(0xFF292C33)
private val bg = Color(0xFF1D2026)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NativeEngine.start()
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = mint, background = bg, surface = panel)) { Surface(Modifier.fillMaxSize(), color = bg) { Mixer() } } }
    }
    override fun onDestroy() { NativeEngine.stop(); super.onDestroy() }
}

@Composable
fun Mixer() {
    var cross by remember { mutableFloatStateOf(0.5f) }
    var sampler by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 10.dp, vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("MAXXIDODJ", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("DUAL DECK • MIXER", color = mint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DeckPanel(0, "DECK A", purple, Modifier.weight(1f))
            DeckPanel(1, "DECK B", mint, Modifier.weight(1f))
        }
        Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 5.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("A", color = purple, fontWeight = FontWeight.Bold)
                    Text("CROSSFADER", fontSize = 11.sp, color = Color.LightGray)
                    Text("B", color = mint, fontWeight = FontWeight.Bold)
                }
                Slider(value = cross, onValueChange = { cross = it; NativeEngine.setCrossfader(it) }, colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = mint, inactiveTrackColor = purple))
            }
        }
        Spacer(Modifier.height(5.dp))
        Text("SAMPLER", color = Color.LightGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("AIRHORN", "SIREN", "KICK", "CLAP").forEachIndexed { i, label ->
                Button(onClick = { sampler = i; NativeEngine.triggerSampler(i) }, modifier = Modifier.weight(1f).height(40.dp), contentPadding = PaddingValues(2.dp), colors = ButtonDefaults.buttonColors(containerColor = if (sampler == i) mint else Color(0xFF414650))) { Text(label, fontSize = 10.sp, color = Color.White) }
            }
        }
    }
}

@Composable
fun DeckPanel(id: Int, title: String, accent: Color, modifier: Modifier = Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("Load a track") }
    var loading by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var vol by remember { mutableFloatStateOf(1f) }
    var tempo by remember { mutableFloatStateOf(1f) }
    var pos by remember { mutableDoubleStateOf(0.0) }
    var prog by remember { mutableFloatStateOf(-1f) }
    var filter by remember { mutableFloatStateOf(0.5f) }
    var reverb by remember { mutableFloatStateOf(0f) }
    var loop by remember { mutableStateOf(false) }
    val on = remember { mutableStateListOf(true, true, true, true) }
    var prepJob by remember { mutableStateOf<Job?>(null) }
    var curMix by remember { mutableStateOf<File?>(null) }
    val labels = listOf("VOCALS", "DRUMS", "BASS", "OTHER")
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        prepJob?.cancel(); prog = -1f; for (i in 0..3) on[i] = true
        loading = true; name = "Decoding…"; playing = false
        scope.launch {
            try {
                val f = File(ctx.cacheDir, "deck${id}_${System.nanoTime()}.pcm")
                val rate = withContext(Dispatchers.IO) { Decoder.decode(ctx, uri, f) }
                NativeEngine.loadDeck(id, f.absolutePath, rate)
                curMix?.delete(); curMix = f
                name = uri.lastPathSegment?.substringAfterLast('/') ?: "Loaded track"
                loading = false
                prog = 0f
                prepJob = scope.launch(prepDispatcher) {
                    val key = uri.toString().hashCode().toUInt().toString(16)
                    val paths = StemCache.prepare(ctx, f, rate, key, { prog = it }, { !isActive })
                    if (isActive && paths != null) { NativeEngine.setStems(id, paths); prog = 2f }
                    else if (isActive) prog = -1f
                }
            } catch (e: Exception) { name = "Load error: ${e.message}"; loading = false }
        }
    }
    LaunchedEffect(Unit) { while (true) { pos = NativeEngine.getPosition(id); delay(200) } }

    Card(modifier.fillMaxHeight(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = panel)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = accent, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Box(Modifier.fillMaxWidth().height(3.dp).background(accent, RoundedCornerShape(2.dp)))
            Box(Modifier.size(110.dp).background(accent, CircleShape).border(2.dp, Color.Black, CircleShape), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(54.dp).background(Color(0xFF26313A), CircleShape), contentAlignment = Alignment.Center) { Text("●", color = Color.White, fontSize = 24.sp) }
                    Text(if (playing) "PLAYING" else "READY", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
            Text(name, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("%02d:%02d".format(pos.toInt()/60, pos.toInt()%60), color = Color.LightGray, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Button(onClick = { picker.launch(arrayOf("audio/*")) }, enabled = !loading, modifier = Modifier.weight(1f), contentPadding = PaddingValues(3.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF414650))) { Text(if (loading) "WAIT" else "LOAD", fontSize = 10.sp) }
                Button(onClick = { playing = !playing; NativeEngine.setPlaying(id, playing) }, enabled = !loading, modifier = Modifier.weight(1f), contentPadding = PaddingValues(3.dp), colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text(if (playing) "PAUSE" else "▶ PLAY", color = Color.Black, fontSize = 10.sp) }
            }
            if (prog in 0f..1f) {
                Text("Preparing lite stems ${(prog*100).roundToInt()}%", fontSize = 9.sp, color = Color.LightGray)
                LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth(), color = accent)
            }
            Text(if (prog == 2f) "STEMS READY • frequency split" else "STEMS • vocals / drums / bass / other", color = Color.LightGray, fontSize = 9.sp)
            labels.forEachIndexed { i, label ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, modifier = Modifier.width(53.dp), fontSize = 9.sp, color = if (on[i]) accent else Color.Gray, fontWeight = FontWeight.Bold)
                    Slider(value = if (on[i]) 1f else 0f, onValueChange = { v -> on[i] = v > .5f; NativeEngine.setStemVolume(id, i, if (on[i]) 1f else 0f) }, enabled = prog == 2f, modifier = Modifier.weight(1f), colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
                }
            }
            Text("VOLUME ${(vol*100).roundToInt()}%", color = Color.LightGray, fontSize = 9.sp)
            Slider(vol, { vol = it; NativeEngine.setVolume(id, it) }, colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
            Text("TEMPO ${"%+.0f".format((tempo-1)*100)}%", color = Color.LightGray, fontSize = 9.sp)
            Slider(tempo, { tempo = it; NativeEngine.setTempo(id, it) }, valueRange = .8f..1.2f, colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedButton(onClick = { loop = !loop; NativeEngine.setLoop(id, loop, pos, pos + 4.0) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(2.dp)) { Text(if (loop) "LOOP OUT ✓" else "LOOP OUT", fontSize = 8.sp, color = accent) }
                OutlinedButton(onClick = { filter = if (filter > .5f) 0f else 1f; NativeEngine.setFilter(id, filter) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(2.dp)) { Text("FILTER", fontSize = 8.sp, color = accent) }
            }
            Text("REVERB", color = Color.LightGray, fontSize = 9.sp)
            Slider(reverb, { reverb = it; NativeEngine.setReverb(id, it) }, colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
            Text("Filter and reverb are real-time effects. Lite stems are frequency-based, not AI source separation.", color = Color.Gray, fontSize = 9.sp, lineHeight = 11.sp)
        }
    }
}
