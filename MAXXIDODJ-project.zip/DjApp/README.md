# MAXXIDODJ

Android dual-deck DJ app built with Kotlin/Jetpack Compose and Oboe native audio.

## Current features
- Dual decks, loading Android-supported audio, play/pause, tempo and volume
- Crossfader
- Four frequency-based stem controls (vocals/drums/bass/other)
- Real-time filter and delay-based reverb controls
- Basic synthesized sampler pads
- Short loop-out toggle

## Important stem limitation
The included `LiteSeparator` is a lightweight frequency/center-channel heuristic, not an AI source-separation model. It cannot reliably isolate vocals, drums, bass and instruments from every song. Stronger isolation requires integrating a trained model such as a compatible Demucs/MDX model, handling its license and model size, and optimizing inference for Android. The current controls should be treated as experimental frequency stems, not true AI stems.

## Build
Open this folder in Android Studio or run `gradle assembleDebug` with Android SDK 34, NDK 26.1.10909125, CMake 3.22.1 and JDK 17 installed.
