'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { loadConfig } = require('../src/config');
const { createApp } = require('../src/app');
const { Ledger } = require('../src/ledger');
const { Mpesa, Flutterwave } = require('../src/payments');
const { Pricing } = require('../src/pricing');
const C = require('../src/crypto');

const PRIV = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' }).privateKey.export({ type: 'pkcs8', format: 'pem' });
const ADMIN = 'a'.repeat(32);

const rateFetch = async (url) => ({ json: async () => ({ result: 'success', rates: { USD: 0.0077, UGX: 28.1, EUR: 0.0071 } }) });

const opened = [];
test.after(async () => { await Promise.all(opened.map((a) => a.close())); });

async function boot(extraEnv = {}, dir) {
  dir = dir || fs.mkdtempSync(path.join(os.tmpdir(), 'billing-'));
  const cfg = loadConfig({ PAYMENT_MODE: 'mock', TOKEN_PRIVATE_KEY: PRIV, LEDGER_KEY: 'k'.repeat(40), ADMIN_TOKEN: ADMIN, DATA_DIR: dir, ...extraEnv });
  const app = createApp(cfg, { fetch: rateFetch });
  opened.push(app);
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + app.server.address().port;
  return { app, cfg, base, dir };
}

/** A pretend phone: its own P-256 key, signs every request exactly like the Android app does. */
function phone(base) {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const pub = publicKey.export({ type: 'spki', format: 'der' }).toString('base64');
  const did = C.deviceIdOf(pub);
  async function call(method, p, body, over = {}) {
    const raw = body === undefined ? '' : JSON.stringify(body);
    const ts = over.ts ?? Date.now();
    const nonce = over.nonce ?? crypto.randomBytes(12).toString('hex');
    const msg = C.requestMessage(method, p, ts, nonce, raw);
    const sig = over.sig ?? crypto.sign('sha256', Buffer.from(msg), privateKey).toString('base64');
    const res = await fetch(base + p, {
      method, body: raw || undefined,
      headers: { 'x-device': over.did ?? did, 'x-ts': String(ts), 'x-nonce': nonce, 'x-sig': sig, 'content-type': 'application/json' },
    });
    return { status: res.status, body: await res.json() };
  }
  return { pub, did, call, register: () => call('POST', '/v1/register', { pub, cc: 'KE' }) };
}

const verifyToken = (token, serverPub) => {
  const [p, s] = token.split('.');
  const key = crypto.createPublicKey({ key: Buffer.from(serverPub, 'base64'), format: 'der', type: 'spki' });
  assert.ok(crypto.verify('sha256', Buffer.from(p), key, Buffer.from(s, 'base64url')), 'token signature must verify');
  return JSON.parse(Buffer.from(p, 'base64url').toString());
};

const mpesaHook = (b, order, receipt = 'SJK1ABC234', secret = 'mock-callback-secret-mock-callback') =>
  fetch(`${b.base}/hook/stk/${secret}`, {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ Body: { stkCallback: { CheckoutRequestID: order.ref, ResultCode: 0, ResultDesc: 'ok',
      CallbackMetadata: { Item: [{ Name: 'Amount', Value: 150 }, { Name: 'MpesaReceiptNumber', Value: receipt }] } } } }),
  });

// ------------------------------------------------------------------------------------------------------------------
test('full purchase: M-Pesa -> signed device-bound token that verifies with the public key', async () => {
  const b = await boot(); const p = phone(b.base);
  assert.equal((await p.register()).status, 200);
  assert.equal((await p.call('POST', '/v1/entitlement', {})).status, 402);                 // not paid yet

  const co = await p.call('POST', '/v1/checkout', { method: 'mpesa', phone: '0712 345 678' });
  assert.equal(co.status, 200);
  assert.equal(co.body.amount, 150); assert.equal(co.body.currency, 'KES');
  assert.equal((await p.call('GET', '/v1/order/' + co.body.orderId)).body.status, 'pending');
  assert.equal((await p.call('POST', '/v1/entitlement', {})).status, 402);

  const order = b.app.state.orders.get(co.body.orderId);
  b.app.payments.mock.markPaid(order, 'REC1');
  order._last = 0;                                                   // (a real phone polls every few seconds)
  assert.equal((await p.call('GET', '/v1/order/' + co.body.orderId)).body.status, 'paid');

  const ent = await p.call('POST', '/v1/entitlement', {});
  assert.equal(ent.status, 200);
  const t = verifyToken(ent.body.token, b.app.publicKey);
  assert.equal(t.did, p.did);
  assert.deepEqual(t.feat, ['video', 'stems']);
  assert.ok(t.exp - t.iat === 14 * 86400);
  assert.equal((await p.call('POST', '/v1/checkout', { method: 'mpesa', phone: '0712345678' })).status, 409);   // no double charge
  await b.app.close();
});

test('the phone cannot choose the price, and bad input is refused', async () => {
  const b = await boot(); const p = phone(b.base); await p.register();
  const co = await p.call('POST', '/v1/checkout', { method: 'mpesa', phone: '0712345678', amount: 1, currency: 'USD' });
  assert.equal(b.app.state.orders.get(co.body.orderId).amount, 150);
  assert.equal((await p.call('POST', '/v1/checkout', { method: 'mpesa', phone: '12345' })).body.error, 'bad_phone');
  assert.equal((await p.call('POST', '/v1/checkout', { method: 'card', email: 'nope' })).body.error, 'bad_email');
  assert.equal((await p.call('POST', '/v1/checkout', { method: 'bitcoin' })).body.error, 'bad_method');
  await b.app.close();
});

test('forged, replayed, stale and stolen-identity requests are rejected', async () => {
  const b = await boot(); const p = phone(b.base); const q = phone(b.base);
  await p.register(); await q.register();
  assert.equal((await p.call('POST', '/v1/entitlement', {}, { sig: Buffer.from('garbage').toString('base64') })).body.error, 'bad_signature');
  assert.equal((await p.call('POST', '/v1/entitlement', {}, { ts: Date.now() - 10 * 60e3 })).body.error, 'clock_skew');
  const nonce = 'abcdef0123456789';
  assert.equal((await p.call('POST', '/v1/entitlement', {}, { nonce })).status, 402);
  assert.equal((await p.call('POST', '/v1/entitlement', {}, { nonce })).body.error, 'replay');      // same signed request twice
  // phone Q signs but claims to be P:
  assert.equal((await q.call('POST', '/v1/entitlement', {}, { did: p.did })).body.error, 'bad_signature');
  // an unregistered phone
  const r = phone(b.base);
  assert.equal((await r.call('POST', '/v1/entitlement', {})).body.error, 'unknown_device');
  // a registration whose id does not match its key
  assert.equal((await r.call('POST', '/v1/register', { pub: q.pub, cc: 'KE' })).body.error, 'bad_device');
  await b.app.close();
});

test('one phone cannot read or use another phone\'s order / token', async () => {
  const b = await boot(); const a = phone(b.base); const m = phone(b.base);
  await a.register(); await m.register();
  const co = await a.call('POST', '/v1/checkout', { method: 'mpesa', phone: '0712345678' });
  b.app.payments.mock.markPaid(b.app.state.orders.get(co.body.orderId));
  await b.app.refresh(b.app.state.orders.get(co.body.orderId), true);
  assert.equal((await m.call('GET', '/v1/order/' + co.body.orderId)).status, 404);
  assert.equal((await m.call('POST', '/v1/entitlement', {})).status, 402);
  const tokA = (await a.call('POST', '/v1/entitlement', {})).body.token;
  assert.equal(verifyToken(tokA, b.app.publicKey).did, a.did);        // the app also checks did === its own id
  await b.app.close();
});

test('underpayment and wrong currency never unlock PRO', async () => {
  const b = await boot(); const p = phone(b.base); await p.register();
  const co = await p.call('POST', '/v1/checkout', { method: 'card', email: 'dj@example.com', cc: 'US', cur: 'USD' });
  assert.equal(co.body.currency, 'USD');
  const order = b.app.state.orders.get(co.body.orderId);
  b.app.payments.mock.states.set(order.ref, { state: 'paid', amount: order.amount - 0.5, currency: 'USD', receipt: 'FLW1' });
  assert.equal((await p.call('GET', '/v1/order/' + order.id)).body.status, 'pending');
  order._last = 0;
  b.app.payments.mock.states.set(order.ref, { state: 'paid', amount: 99999, currency: 'UGX', receipt: 'FLW1' });
  assert.equal((await p.call('GET', '/v1/order/' + order.id)).body.status, 'pending');
  assert.equal((await p.call('POST', '/v1/entitlement', {})).status, 402);
  order._last = 0;
  b.app.payments.mock.markPaid(order, 'FLW1');
  assert.equal((await p.call('GET', '/v1/order/' + order.id)).body.status, 'paid');
  await b.app.close();
});

test('forged webhooks do nothing; only the provider\'s own answer counts', async () => {
  const b = await boot(); const p = phone(b.base); await p.register();
  const co = await p.call('POST', '/v1/checkout', { method: 'mpesa', phone: '0712345678' });
  const order = b.app.state.orders.get(co.body.orderId);
  assert.equal((await mpesaHook(b, order, 'SJK1ABC234', 'wrong-secret-wrong-secret-wrong')).status, 404);
  await mpesaHook(b, order);                                          // right secret, but Safaricom has NOT said paid
  assert.equal(order.status, 'pending');
  const f = await fetch(b.base + '/hook/flw', { method: 'POST', headers: { 'verif-hash': 'nope', 'content-type': 'application/json' }, body: '{}' });
  assert.equal(f.status, 401);
  // genuine: provider says paid, callback delivers the SMS receipt
  b.app.payments.mock.markPaid(order);
  await mpesaHook(b, order);
  assert.equal(order.status, 'paid');
  assert.equal(order.userReceipt, 'SJK1ABC234');
  await b.app.close();
});

test('one receipt can never unlock two orders', async () => {
  const b = await boot(); const p = phone(b.base); const q = phone(b.base);
  await p.register(); await q.register();
  const o1 = b.app.state.orders.get((await p.call('POST', '/v1/checkout', { method: 'mpesa', phone: '0712345678' })).body.orderId);
  const o2 = b.app.state.orders.get((await q.call('POST', '/v1/checkout', { method: 'mpesa', phone: '0722222222' })).body.orderId);
  b.app.payments.mock.markPaid(o1, 'SAMEREC001');
  b.app.payments.mock.markPaid(o2, 'SAMEREC001');
  await p.call('GET', '/v1/order/' + o1.id); await q.call('GET', '/v1/order/' + o2.id);
  assert.equal(o1.status, 'paid'); assert.notEqual(o2.status, 'paid');
  await b.app.close();
});

test('new phone: restore needs receipt + the payer\'s phone, and is capped', async () => {
  const b = await boot(); const d = [phone(b.base), phone(b.base), phone(b.base), phone(b.base)];
  for (const x of d) await x.register();
  const co = await d[0].call('POST', '/v1/checkout', { method: 'mpesa', phone: '0712345678' });
  const order = b.app.state.orders.get(co.body.orderId);
  b.app.payments.mock.markPaid(order); await mpesaHook(b, order, 'RCPT123456');
  assert.equal(order.status, 'paid');

  assert.equal((await d[1].call('POST', '/v1/restore', { receipt: 'RCPT123456', proof: '0799999999' })).status, 404);   // wrong phone
  assert.equal((await d[1].call('POST', '/v1/restore', { receipt: 'NOSUCH', proof: '0712345678' })).status, 404);        // unknown receipt: same answer
  assert.equal((await d[1].call('POST', '/v1/restore', { receipt: 'rcpt123456', proof: '+254712345678' })).status, 200);
  assert.equal((await d[1].call('POST', '/v1/entitlement', {})).status, 200);
  assert.equal((await d[0].call('POST', '/v1/entitlement', {})).body.error, 'moved');                                    // old phone loses PRO
  assert.equal((await d[2].call('POST', '/v1/restore', { receipt: 'RCPT123456', proof: '0712345678' })).status, 200);
  assert.equal((await d[3].call('POST', '/v1/restore', { receipt: 'RCPT123456', proof: '0712345678' })).body.error, 'device_limit');
  await b.app.close();
});

test('ledger: edits, deletions and reordering are detected; restart keeps state', async () => {
  const b = await boot(); const p = phone(b.base); await p.register();
  const o = b.app.state.orders.get((await p.call('POST', '/v1/checkout', { method: 'mpesa', phone: '0712345678' })).body.orderId);
  b.app.payments.mock.markPaid(o, 'REC9'); await p.call('GET', '/v1/order/' + o.id);
  const file = path.join(b.dir, 'ledger.jsonl');
  const head = b.app.ledger.head;
  await b.app.close();

  // restart: still paid
  const again = await boot({}, b.dir);
  assert.equal(again.app.ledger.head, head);
  assert.equal(again.app.state.entitlements.get(p.did).revoked, false);
  await again.app.close();

  const original = fs.readFileSync(file, 'utf8');
  const lines = original.trim().split('\n');
  const boom = (text, re) => { fs.writeFileSync(file, text); assert.throws(() => boot.sync(b.dir), re); };
  boot.sync = (dir) => createApp(loadConfig({ PAYMENT_MODE: 'mock', TOKEN_PRIVATE_KEY: PRIV, LEDGER_KEY: 'k'.repeat(40), ADMIN_TOKEN: ADMIN, DATA_DIR: dir }), { fetch: rateFetch });

  boom(original.replace('"amount":150', '"amount":1'), /changed/);                         // price edited
  boom(lines.filter((_, i) => i !== 1).join('\n') + '\n', /sequence|broken/);                 // a line removed
  boom([lines[0], lines[2], lines[1], ...lines.slice(3)].join('\n') + '\n', /sequence|broken|changed/);   // reordered
  const forged = JSON.parse(lines[lines.length - 1]); forged.seq += 1;
  boom(original + JSON.stringify(forged) + '\n', /changed|broken/);                           // appended without the secret key
  fs.writeFileSync(file, original);
  assert.doesNotThrow(() => boot.sync(b.dir).close());
  // a different LEDGER_KEY cannot re-sign history either
  assert.throws(() => Ledger.verifyFile(file, 'x'.repeat(40)), /changed/);
});

test('admin: revoke removes PRO; manual grants are ledgered; endpoints need the admin token', async () => {
  const b = await boot(); const p = phone(b.base); await p.register();
  const adm = (m, u, body) => fetch(b.base + u, { method: m, headers: { authorization: 'Bearer ' + ADMIN, 'content-type': 'application/json' }, body: body && JSON.stringify(body) }).then(async r => ({ status: r.status, body: await r.json() }));
  assert.equal((await fetch(b.base + '/admin/orders')).status, 401);
  assert.equal((await fetch(b.base + '/admin/orders', { headers: { authorization: 'Bearer wrong' } })).status, 401);

  assert.equal((await adm('POST', '/admin/grant', { deviceId: p.did.slice(0, 6) })).status, 404);                 // too short to be safe
  assert.equal((await adm('POST', '/admin/grant', { deviceId: p.did.slice(0, 8).toUpperCase(), note: 'tester', days: 30 })).status, 200);   // 8+ letters of the Phone ID are enough
  assert.equal((await p.call('POST', '/v1/entitlement', {})).status, 200);
  const g = [...b.app.state.entitlements.values()][0];
  assert.ok(g.until > Date.now());
  const ver = await adm('GET', '/admin/verify');
  assert.equal(ver.body.ok, true);

  const q = phone(b.base); await q.register();
  const o = b.app.state.orders.get((await q.call('POST', '/v1/checkout', { method: 'mpesa', phone: '0712345678' })).body.orderId);
  b.app.payments.mock.markPaid(o); await q.call('GET', '/v1/order/' + o.id);
  assert.equal((await q.call('POST', '/v1/entitlement', {})).status, 200);
  assert.equal((await adm('POST', '/admin/revoke', { orderId: o.id, reason: 'chargeback' })).status, 200);
  assert.equal((await q.call('POST', '/v1/entitlement', {})).body.error, 'revoked');
  await b.app.close();
});

test('pricing: KSh 150 always, local currency rounded up, zero-decimal currencies, fallback when rates are down', async () => {
  const cfg = loadConfig({ PAYMENT_MODE: 'mock', TOKEN_PRIVATE_KEY: PRIV, LEDGER_KEY: 'k'.repeat(40), ADMIN_TOKEN: ADMIN });
  const pr = new Pricing(cfg, rateFetch);
  assert.deepEqual(await pr.priceIn('KES'), { amount: 150, currency: 'KES', approx: false });
  assert.deepEqual(await pr.priceIn('USD'), { amount: 1.2, currency: 'USD', approx: false });     // 1.155 -> 1.20
  assert.deepEqual(await pr.priceIn('UGX'), { amount: 4220, currency: 'UGX', approx: false });    // 4215 -> 4220
  assert.equal((await pr.cardQuote('XYZ')).currency, 'USD');                                       // unsupported -> USD
  const q = await pr.quote({ cc: 'KE', cur: 'USD' });
  assert.deepEqual(q.options.map(o => [o.method, o.currency, o.amount]), [['mpesa', 'KES', 150], ['card', 'KES', 150]]);
  const down = new Pricing(cfg, async () => { throw new Error('offline'); });
  const f = await down.priceIn('EUR'); assert.equal(f.approx, true); assert.ok(f.amount > 0.5 && f.amount < 2);
});

test('M-Pesa and Flutterwave clients send what the providers expect (stubbed network)', async () => {
  const cfg = loadConfig({
    PAYMENT_MODE: 'live', TOKEN_PRIVATE_KEY: PRIV, LEDGER_KEY: 'k'.repeat(40), ADMIN_TOKEN: ADMIN, PUBLIC_URL: 'https://pay.example.com',
    MPESA_KEY: 'k', MPESA_SECRET: 's', MPESA_SHORTCODE: '174379', MPESA_PASSKEY: 'pk', MPESA_CALLBACK_SECRET: 'c'.repeat(30),
    FLW_SECRET_KEY: 'FLWSECK-x', FLW_WEBHOOK_HASH: 'h'.repeat(20),
  });
  const calls = [];
  const fake = async (url, init = {}) => {
    calls.push({ url, init });
    const J = (o, ok = true) => ({ ok, status: ok ? 200 : 500, json: async () => o });
    if (url.includes('/oauth/')) return J({ access_token: 'T', expires_in: '3599' });
    if (url.includes('stkpush/v1/processrequest')) return J({ ResponseCode: '0', CheckoutRequestID: 'ws_CO_1' });
    if (url.includes('stkpushquery')) return J({ ResultCode: '0', ResultDesc: 'ok' });
    if (url.includes('/v3/payments')) return J({ status: 'success', data: { link: 'https://checkout.flutterwave.com/v3/hosted/pay/abc' } });
    if (url.includes('verify_by_reference')) return J({ status: 'success', data: { id: 77, tx_ref: 'ord_1', status: 'successful', amount: 1.2, currency: 'USD' } });
    throw new Error('unexpected ' + url);
  };
  const m = new Mpesa(cfg, fake);
  const r = await m.start({ id: 'ord_1', amount: 150 }, { phone: '254712345678' });
  assert.equal(r.ref, 'ws_CO_1');
  const body = JSON.parse(calls.find(c => c.url.includes('processrequest')).init.body);
  assert.equal(body.Amount, 150); assert.equal(body.PartyA, '254712345678');
  assert.equal(body.CallBackURL, 'https://pay.example.com/hook/stk/' + 'c'.repeat(30));
  assert.equal(Buffer.from(body.Password, 'base64').toString(), '174379pk' + body.Timestamp);
  assert.equal((await m.query({ ref: 'ws_CO_1' })).state, 'paid');

  const f = new Flutterwave(cfg, fake);
  const s = await f.start({ id: 'ord_1', amount: 1.2, currency: 'USD' }, { email: 'dj@example.com' });
  assert.match(s.link, /^https:\/\/checkout\.flutterwave\.com/);
  assert.deepEqual(await f.query({ id: 'ord_1' }), { state: 'paid', amount: 1.2, currency: 'USD', receipt: 'FLW77' });
  assert.equal(Mpesa.normalizePhone('+254 712-345-678'), '254712345678');
  assert.equal(Mpesa.normalizePhone('0112345678'), '254112345678');
  assert.equal(Mpesa.normalizePhone('0612345678'), null);
});

test('startup refuses weak or missing secrets', () => {
  assert.throws(() => loadConfig({ PAYMENT_MODE: 'mock', TOKEN_PRIVATE_KEY: PRIV, LEDGER_KEY: 'short', ADMIN_TOKEN: ADMIN }), /LEDGER_KEY/);
  assert.throws(() => loadConfig({ PAYMENT_MODE: 'mock', LEDGER_KEY: 'k'.repeat(40), ADMIN_TOKEN: ADMIN }), /TOKEN_PRIVATE_KEY/);
  assert.throws(() => loadConfig({ PAYMENT_MODE: 'live', TOKEN_PRIVATE_KEY: PRIV, LEDGER_KEY: 'k'.repeat(40), ADMIN_TOKEN: ADMIN }), /PUBLIC_URL/);
});
