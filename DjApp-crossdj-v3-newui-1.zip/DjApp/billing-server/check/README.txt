HOW TO CHECK PAYMENTS LATER (takes about a minute)

1. In your Paystack dashboard open Transactions and export them (Export / Download CSV).
   Save the file in THIS folder and name it:  paystack.csv
2. Make a text file in this folder named:  claims.txt
   Paste into it all the WhatsApp messages customers sent you after unlocking (the ones that start "Hi, I paid for MAXIDO DJ PRO").
3. Double-click reconcile.bat (one folder up). It writes reconcile-report.txt and shows it on screen.
