#!/usr/bin/env bash
# One-command installer for the MAXIDO billing server on a fresh Ubuntu/Debian server (run as root).
#   sudo bash deploy/install.sh billing.yourdomain.com
# It installs Node 22 and Caddy (automatic https), creates the keys and secrets, starts the server in LIVE mode
# (fake payments, safe to test) and sets up a daily local backup of the payment ledger.
set -euo pipefail

DOMAIN="${1:-}"
[ -n "$DOMAIN" ] || { echo "Usage: sudo bash deploy/install.sh your.domain.example"; exit 1; }
[ "$(id -u)" -eq 0 ] || { echo "Run as root (sudo)."; exit 1; }

SRC="$(cd "$(dirname "$0")/.." && pwd)"
APP=/opt/maxido-billing
DATA=/var/lib/maxido-billing
BACKUP=/var/backups/maxido-billing

echo "==> Installing Node 22 and Caddy"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates gnupg openssl debian-keyring debian-archive-keyring apt-transport-https rsync
if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 20 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
if ! command -v caddy >/dev/null; then
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y
  apt-get install -y caddy
fi

echo "==> Copying the server to $APP"
id maxido >/dev/null 2>&1 || useradd --system --home "$APP" --shell /usr/sbin/nologin maxido
mkdir -p "$APP" "$DATA" "$BACKUP"
rsync -a --delete --exclude keys --exclude data --exclude .env --exclude node_modules "$SRC"/ "$APP"/

echo "==> Keys and secrets (existing ones are never overwritten)"
cd "$APP"
if [ ! -f keys/token_private.pem ]; then
  node scripts/gen-keys.js | awk '/^App public key/{getline; print; exit}' > PUBLIC_KEY.txt
fi
if [ ! -f .env ]; then
  cat > .env <<ENV
PAYMENT_MODE=live
PORT=8080
PUBLIC_URL=https://$DOMAIN
DATA_DIR=$DATA
TOKEN_PRIVATE_KEY_FILE=$APP/keys/token_private.pem
LEDGER_KEY=$(openssl rand -hex 32)
ADMIN_TOKEN=$(openssl rand -hex 24)
MPESA_CALLBACK_SECRET=$(openssl rand -hex 24)
TRUST_PROXY=1
PRICE_KES=150
LEASE_DAYS=14
ENTITLEMENT_DAYS=0
MAX_DEVICES=3
MPESA_ENV=production
MPESA_KEY=
MPESA_SECRET=
MPESA_SHORTCODE=
MPESA_PASSKEY=
MPESA_TXN_TYPE=CustomerPayBillOnline
MPESA_PARTYB=
FLW_SECRET_KEY=
FLW_WEBHOOK_HASH=
ENV
fi
chown -R maxido:maxido "$APP" "$DATA"
chmod 700 "$APP/keys" "$DATA"; chmod 600 "$APP/.env" "$APP/keys/token_private.pem"

echo "==> Starting the service"
cat > /etc/systemd/system/maxido-billing.service <<UNIT
[Unit]
Description=MAXIDO billing server
After=network-online.target
Wants=network-online.target

[Service]
User=maxido
WorkingDirectory=$APP
ExecStart=/usr/bin/node --env-file=$APP/.env server.js
Restart=always
RestartSec=3
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=$DATA
PrivateTmp=true

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now maxido-billing
systemctl restart maxido-billing

echo "==> https with Caddy"
cat > /etc/caddy/Caddyfile <<CADDY
$DOMAIN {
    reverse_proxy localhost:8080
}
CADDY
systemctl reload caddy || systemctl restart caddy

echo "==> Daily backup of the ledger (also copy it OFF this server now and then)"
cat > /etc/cron.daily/maxido-billing-backup <<CRON
#!/bin/sh
cp $DATA/ledger.jsonl $BACKUP/ledger-\$(date +%F).jsonl 2>/dev/null
find $BACKUP -name 'ledger-*.jsonl' -mtime +60 -delete
CRON
chmod +x /etc/cron.daily/maxido-billing-backup

sleep 2
echo
echo "================================================================"
echo " Server status:   $(systemctl is-active maxido-billing)"
echo " Check in browser: https://$DOMAIN/health   (should show {\"ok\":true})"
echo
echo " 1) Paste into Billing.kt:"
echo "    SERVER_URL        = \"https://$DOMAIN\""
echo "    SERVER_PUBLIC_KEY = \"$(cat "$APP/PUBLIC_KEY.txt" 2>/dev/null)\""
echo
echo " 2) Your admin password is in $APP/.env (ADMIN_TOKEN). Back up $APP/keys/token_private.pem OFF this server."
echo
echo " 3) It is in LIVE mode (real money). Edit $APP/.env and fill the MPESA_* and/or FLW_* lines, then:  systemctl restart maxido-billing"
echo "    Logs:  journalctl -u maxido-billing -f"
echo "================================================================"
