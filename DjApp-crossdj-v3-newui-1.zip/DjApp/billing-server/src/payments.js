'use strict';
/**
 * Payment providers. The rule for all of them: a payment counts ONLY when the provider's own API (called by this
 * server with our secret keys) says it was paid. A webhook is just a "go and check now" signal, never proof.
 *
 * Every provider offers:  start(order, extra) -> { ref, link? }     and     query(order) -> { state, amount?, currency?, receipt? }
 * where state is 'paid' | 'failed' | 'pending'.
 */

const TIMEOUT = 15000;

// ------------------------------------------------------------------------------------------------ M-Pesa (Daraja STK push)
class Mpesa {
  constructor(cfg, fetchImpl = fetch) { this.c = cfg.mpesa; this.cfg = cfg; this.fetch = fetchImpl; this.tok = null; this.tokExp = 0; }
  get base() { return this.c.env === 'production' ? 'https://api.safaricom.co.ke' : 'https://sandbox.safaricom.co.ke'; }

  /** Kenyan numbers only: 07xx, 01xx, +2547xx, 2547xx, 2541xx -> 2547xxxxxxxx */
  static normalizePhone(p) {
    const m = String(p || '').replace(/[\s-]/g, '').match(/^(?:\+?254|0)([17]\d{8})$/);
    return m ? '254' + m[1] : null;
  }
  static stamp() { return new Date(Date.now() + 3 * 3600e3).toISOString().replace(/[-:T]/g, '').slice(0, 14); }

  async token() {
    if (this.tok && Date.now() < this.tokExp) return this.tok;
    const r = await this.fetch(this.base + '/oauth/v1/generate?grant_type=client_credentials', {
      headers: { Authorization: 'Basic ' + Buffer.from(this.c.key + ':' + this.c.secret).toString('base64') },
      signal: AbortSignal.timeout(TIMEOUT),
    });
    const j = await r.json();
    if (!j.access_token) throw new Error('M-Pesa auth failed');
    this.tok = j.access_token; this.tokExp = Date.now() + (Number(j.expires_in) || 3000) * 1000 - 60000;
    return this.tok;
  }
  password(ts) { return Buffer.from(this.c.shortcode + this.c.passkey + ts).toString('base64'); }

  async start(order, { phone }) {
    const ts = Mpesa.stamp();
    const body = {
      BusinessShortCode: this.c.shortcode, Password: this.password(ts), Timestamp: ts,
      TransactionType: this.c.txnType, Amount: Math.round(order.amount), PartyA: phone, PartyB: this.c.partyB,
      PhoneNumber: phone, CallBackURL: `${this.cfg.publicUrl}/hook/stk/${this.c.callbackSecret}`,
      AccountReference: 'MAXIDO PRO', TransactionDesc: 'MAXIDO DJ PRO',
    };
    const r = await this.fetch(this.base + '/mpesa/stkpush/v1/processrequest', {
      method: 'POST', headers: { Authorization: 'Bearer ' + await this.token(), 'Content-Type': 'application/json' },
      body: JSON.stringify(body), signal: AbortSignal.timeout(TIMEOUT),
    });
    const j = await r.json();
    if (String(j.ResponseCode) !== '0' || !j.CheckoutRequestID) throw new Error('M-Pesa refused the request: ' + (j.errorMessage || j.ResponseDescription || r.status));
    return { ref: j.CheckoutRequestID };
  }

  async query(order) {
    if (!order.ref) return { state: 'pending' };
    const ts = Mpesa.stamp();
    const r = await this.fetch(this.base + '/mpesa/stkpushquery/v1/query', {
      method: 'POST', headers: { Authorization: 'Bearer ' + await this.token(), 'Content-Type': 'application/json' },
      body: JSON.stringify({ BusinessShortCode: this.c.shortcode, Password: this.password(ts), Timestamp: ts, CheckoutRequestID: order.ref }),
      signal: AbortSignal.timeout(TIMEOUT),
    });
    if (!r.ok) return { state: 'pending' };                  // "being processed" comes back as an HTTP error
    const j = await r.json();
    const code = String(j.ResultCode);
    if (code === '0') return { state: 'paid', currency: 'KES' };      // the query reports no amount: we asked for exactly order.amount
    if (code === '4999' || j.ResultCode === undefined) return { state: 'pending' };
    return { state: 'failed', reason: String(j.ResultDesc || code).slice(0, 80) };
  }
}

// ------------------------------------------------------------------------------------------------ Flutterwave (cards, local currencies)
class Flutterwave {
  constructor(cfg, fetchImpl = fetch) { this.c = cfg.flw; this.cfg = cfg; this.fetch = fetchImpl; }
  get headers() { return { Authorization: 'Bearer ' + this.c.secretKey, 'Content-Type': 'application/json' }; }

  async start(order, { email }) {
    const r = await this.fetch('https://api.flutterwave.com/v3/payments', {
      method: 'POST', headers: this.headers, signal: AbortSignal.timeout(TIMEOUT),
      body: JSON.stringify({
        tx_ref: order.id, amount: order.amount, currency: order.currency,
        redirect_url: `${this.cfg.publicUrl}/pay/done`,
        customer: { email }, customizations: { title: 'MAXIDO DJ PRO', description: 'Video mixing and stem separation' },
        meta: { order: order.id },
      }),
    });
    const j = await r.json();
    if (j.status !== 'success' || !j.data || !j.data.link) throw new Error('Flutterwave refused the request: ' + (j.message || r.status));
    return { ref: order.id, link: j.data.link };
  }

  async query(order) {
    const r = await this.fetch('https://api.flutterwave.com/v3/transactions/verify_by_reference?tx_ref=' + encodeURIComponent(order.id), {
      headers: this.headers, signal: AbortSignal.timeout(TIMEOUT),
    });
    if (!r.ok) return { state: 'pending' };
    const j = await r.json();
    const d = j && j.data;
    if (j.status !== 'success' || !d || d.tx_ref !== order.id) return { state: 'pending' };
    if (d.status === 'successful') return { state: 'paid', amount: Number(d.amount), currency: String(d.currency).toUpperCase(), receipt: 'FLW' + d.id };
    if (d.status === 'failed' || d.status === 'cancelled') return { state: 'failed', reason: d.status };
    return { state: 'pending' };
  }
}

// ------------------------------------------------------------------------------------------------ Paystack (hosted checkout: M-Pesa prompt, cards)
class Paystack {
  constructor(cfg, fetchImpl = fetch) { this.c = cfg.paystack; this.cfg = cfg; this.fetch = fetchImpl; }
  get headers() { return { Authorization: 'Bearer ' + this.c.secretKey, 'Content-Type': 'application/json' }; }

  async start(order, extra) {
    const email = extra.email || `${order.did.slice(0, 16)}@users.maxido.app`;    // Paystack needs an e-mail; M-Pesa buyers are not asked for one
    const body = {
      email, amount: Math.round(order.amount * 100), currency: order.currency, reference: order.id,    // Paystack counts in cents
      callback_url: `${this.cfg.publicUrl}/pay/done`, metadata: { order: order.id, method: order.method },
    };
    if (order.method === 'mpesa') body.channels = ['mobile_money'];
    const r = await this.fetch('https://api.paystack.co/transaction/initialize', {
      method: 'POST', headers: this.headers, body: JSON.stringify(body), signal: AbortSignal.timeout(TIMEOUT),
    });
    const j = await r.json();
    if (!j.status || !j.data || !j.data.authorization_url) throw new Error('Paystack refused the request: ' + (j.message || r.status));
    return { ref: order.id, link: j.data.authorization_url };
  }

  /** Only a "success" from Paystack's own verify call counts. A failed attempt can still be retried on the same checkout, so it stays pending. */
  async query(order) {
    const r = await this.fetch('https://api.paystack.co/transaction/verify/' + encodeURIComponent(order.id), { headers: this.headers, signal: AbortSignal.timeout(TIMEOUT) });
    if (!r.ok) return { state: 'pending' };
    const j = await r.json();
    const d = j && j.data;
    if (!j.status || !d || d.reference !== order.id) return { state: 'pending' };
    if (d.status === 'success') return { state: 'paid', amount: Number(d.amount) / 100, currency: String(d.currency).toUpperCase(), receipt: 'PS' + d.id };
    return { state: 'pending' };
  }
}

// ------------------------------------------------------------------------------------------------ Mock (tests / local trial only)
class Mock {
  constructor() { this.states = new Map(); }                       // ref -> result handed back by query()
  async start(order) { return { ref: 'mock_' + order.id, link: `/mock/pay/${order.id}` }; }
  async query(order) { return this.states.get(order.ref) || { state: 'pending' }; }
  markPaid(order, receipt) {
    this.states.set(order.ref, { state: 'paid', amount: order.amount, currency: order.currency, receipt: receipt || 'MOCK' + Math.random().toString(36).slice(2, 10).toUpperCase() });
  }
}

function createPayments(cfg, fetchImpl = fetch) {
  if (!cfg.live) {
    const mock = new Mock();
    return { mpesa: mock, card: mock, mock };
  }
  const paystack = cfg.paystack ? new Paystack(cfg, fetchImpl) : null;
  return { mpesa: cfg.mpesa ? new Mpesa(cfg, fetchImpl) : paystack, card: cfg.flw ? new Flutterwave(cfg, fetchImpl) : paystack, mock: null };
}

module.exports = { createPayments, Mpesa, Flutterwave, Paystack, Mock };
