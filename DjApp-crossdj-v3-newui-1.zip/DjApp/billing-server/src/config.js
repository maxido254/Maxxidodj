'use strict';
const fs = require('fs');

/** Reads and validates settings from environment variables. Throws a readable error when something is missing. */
function loadConfig(env = process.env) {
  const live = (env.PAYMENT_MODE || 'live') === 'live';
  const need = (n, min = 1) => {
    const v = env[n];
    if (!v || v.length < min) throw new Error(`Missing or too short environment variable ${n}`);
    return v;
  };

  let priv = env.TOKEN_PRIVATE_KEY ? env.TOKEN_PRIVATE_KEY.replace(/\\n/g, '\n') : null;
  if (!priv && env.TOKEN_PRIVATE_KEY_FILE) priv = fs.readFileSync(env.TOKEN_PRIVATE_KEY_FILE, 'utf8');
  if (!priv) throw new Error('Set TOKEN_PRIVATE_KEY or TOKEN_PRIVATE_KEY_FILE (create one with: npm run keys)');

  const cfg = {
    live,
    port: Number(env.PORT) || 8080,
    publicUrl: (env.PUBLIC_URL || '').replace(/\/$/, ''),
    dataDir: env.DATA_DIR || './data',
    trustProxy: env.TRUST_PROXY === '1',
    priceKes: Number(env.PRICE_KES) || 150,
    features: (env.FEATURES || 'video,stems').split(',').map(s => s.trim()).filter(Boolean),
    leaseDays: Number(env.LEASE_DAYS) || 14,                 // how long an offline phone keeps PRO without contacting us
    entitlementDays: Number(env.ENTITLEMENT_DAYS) || 0,      // 0 = a payment unlocks PRO for life
    maxDevices: Number(env.MAX_DEVICES) || 3,                // phones one payment may be moved across (lost / new phone)
    cardCurrencies: (env.CARD_CURRENCIES || 'KES,USD,EUR,GBP,UGX,TZS,RWF,NGN,GHS,ZAR,ZMW').split(',').map(s => s.trim().toUpperCase()),
    tokenPrivateKey: priv,
    ledgerKey: need('LEDGER_KEY', 24),
    adminToken: need('ADMIN_TOKEN', 24),
    mpesa: null,
    flw: null,
  };

  if (env.MPESA_KEY || !live) {
    cfg.mpesa = {
      env: env.MPESA_ENV === 'production' ? 'production' : 'sandbox',
      key: env.MPESA_KEY, secret: env.MPESA_SECRET,
      shortcode: env.MPESA_SHORTCODE, passkey: env.MPESA_PASSKEY,
      txnType: env.MPESA_TXN_TYPE === 'CustomerBuyGoodsOnline' ? 'CustomerBuyGoodsOnline' : 'CustomerPayBillOnline',
      partyB: env.MPESA_PARTYB || env.MPESA_SHORTCODE,       // paybill: the paybill number. Till: the till number
      callbackSecret: env.MPESA_CALLBACK_SECRET,
    };
  }
  if (env.FLW_SECRET_KEY || !live) {
    cfg.flw = { secretKey: env.FLW_SECRET_KEY, webhookHash: env.FLW_WEBHOOK_HASH };
  }
  if (live) {
    need('PUBLIC_URL');
    if (!cfg.mpesa && !cfg.flw) throw new Error('Live mode needs M-Pesa (MPESA_*) and/or Flutterwave (FLW_*) settings');
    if (cfg.mpesa) {
      for (const n of ['MPESA_KEY', 'MPESA_SECRET', 'MPESA_SHORTCODE', 'MPESA_PASSKEY']) need(n);
      cfg.mpesa.callbackSecret = need('MPESA_CALLBACK_SECRET', 24);
    }
    if (cfg.flw) cfg.flw.webhookHash = need('FLW_WEBHOOK_HASH', 16);
  } else {
    cfg.mpesa.callbackSecret = cfg.mpesa.callbackSecret || 'mock-callback-secret-mock-callback';
    cfg.flw.webhookHash = cfg.flw.webhookHash || 'mock-flutterwave-hash';
  }
  return cfg;
}
module.exports = { loadConfig };
