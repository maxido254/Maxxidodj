'use strict';

/** Current state, rebuilt by replaying the ledger. The ledger is the only source of truth. */
class State {
  constructor() {
    this.devices = new Map();       // deviceId -> { pub, cc, created }
    this.orders = new Map();        // orderId  -> { id, did, method, amount, currency, status, ref, receipt, proof, created, paidAt }
    this.receipts = new Map();      // receipt  -> orderId   (one payment can never unlock two orders)
    this.entitlements = new Map();  // deviceId -> { orderId, features, since, until, revoked, reason }
    this.binds = new Map();         // orderId  -> Set(deviceId)
    this.byRef = new Map();         // provider reference (M-Pesa CheckoutRequestID / Flutterwave tx_ref) -> orderId
  }
  apply(e) {
    const d = e.data;
    switch (e.type) {
      case 'device_registered':
        this.devices.set(d.did, { pub: d.pub, cc: d.cc, created: e.ts });
        break;
      case 'order_created':
        this.orders.set(d.id, { ...d, status: 'pending', ref: null, receipt: null, created: e.ts, paidAt: null });
        break;
      case 'order_ref': {
        const o = this.orders.get(d.id);
        if (o) { o.ref = d.ref; this.byRef.set(d.ref, d.id); }
        break;
      }
      case 'order_expired': {
        const o = this.orders.get(d.id); if (o && o.status === 'pending') o.status = 'expired';
        break;
      }
      case 'payment_failed': {
        const o = this.orders.get(d.id); if (o && o.status === 'pending') { o.status = 'failed'; o.reason = d.reason; }
        break;
      }
      case 'payment_confirmed': {
        const o = this.orders.get(d.id);
        if (!o || o.status === 'paid') break;
        o.status = 'paid'; o.receipt = d.receipt; o.paidAt = e.ts; o.until = d.until || null;
        this.receipts.set(d.receipt, o.id);
        this.grant(o.did, o.id, d.features, d.until, e.ts);
        break;
      }
      case 'receipt_noted': {   // the receipt number the customer sees (M-Pesa SMS), learnt from the callback after the payment was confirmed
        const o = this.orders.get(d.id);
        if (o && o.status === 'paid' && !this.receipts.has(d.receipt)) { this.receipts.set(d.receipt, o.id); o.userReceipt = d.receipt; }
        break;
      }
      case 'manual_grant':     // support / testing: always visible in the ledger
        this.grant(d.did, d.orderId || 'manual', d.features, d.until, e.ts);
        break;
      case 'order_revoked': {
        const o = this.orders.get(d.id);
        for (const ent of this.entitlements.values()) if (ent.orderId === d.id) { ent.revoked = true; ent.reason = d.reason || 'revoked'; }
        if (o) o.status = 'revoked';
        break;
      }
      case 'device_rebound': {
        const from = this.entitlements.get(d.from);
        if (from) { from.revoked = true; from.reason = 'moved'; }
        const o = this.orders.get(d.orderId);
        this.grant(d.to, d.orderId, d.features, d.until, e.ts);
        if (o) o.rebinds = (o.rebinds || 0) + 1;
        break;
      }
      default: break;
    }
  }
  grant(did, orderId, features, until, ts) {
    this.entitlements.set(did, { orderId, features, since: ts, until: until || null, revoked: false, reason: null });
    if (!this.binds.has(orderId)) this.binds.set(orderId, new Set());
    this.binds.get(orderId).add(did);
  }
}
module.exports = { State };
