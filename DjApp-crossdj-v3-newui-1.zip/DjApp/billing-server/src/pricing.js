'use strict';

// Emergency fallback only (approximate units of currency per 1 KES). Live rates are used whenever they can be fetched;
// a quote made from this table is flagged approx:true and logged.
const FALLBACK_PER_KES = {
  KES: 1, USD: 0.0077, EUR: 0.0070, GBP: 0.0059, UGX: 28, TZS: 19.5, RWF: 11, NGN: 11.5, GHS: 0.09, ZAR: 0.14, ZMW: 0.19,
};
const ZERO_DECIMAL = new Set(['UGX', 'TZS', 'RWF', 'XOF', 'XAF', 'JPY', 'KRW', 'VND', 'CLP']);
const RATE_URL = 'https://open.er-api.com/v6/latest/KES';
const RATE_TTL_MS = 12 * 3600 * 1000;

class Pricing {
  constructor(cfg, fetchImpl = fetch) {
    this.cfg = cfg;
    this.fetch = fetchImpl;
    this.rates = null;       // { USD: 0.0077, ... } per 1 KES
    this.ratesAt = 0;
  }

  async loadRates() {
    if (this.rates && Date.now() - this.ratesAt < RATE_TTL_MS) return;
    try {
      const r = await this.fetch(RATE_URL, { signal: AbortSignal.timeout(8000) });
      const j = await r.json();
      if (j && j.result === 'success' && j.rates && j.rates.USD > 0) { this.rates = j.rates; this.ratesAt = Date.now(); }
    } catch { /* keep old rates (even stale ones) or fall back to the table */ }
  }

  /** Rounds UP so the customer is never charged less than the KES 150 equivalent, to a tidy number. */
  static tidy(amount, cur) {
    if (ZERO_DECIMAL.has(cur)) {
      const step = amount >= 10000 ? 100 : amount >= 1000 ? 10 : 1;
      return Math.ceil(amount / step) * step;
    }
    if (amount >= 1000) return Math.ceil(amount / 10) * 10;
    if (amount >= 100) return Math.ceil(amount);
    if (amount >= 10) return Math.ceil(amount * 2) / 2;
    return Math.ceil(amount * 20) / 20;
  }

  /** Price of PRO in [currency] (the base price is always KSh cfg.priceKes). */
  async priceIn(currency) {
    const cur = String(currency || 'USD').toUpperCase();
    if (cur === 'KES') return { amount: this.cfg.priceKes, currency: 'KES', approx: false };
    await this.loadRates();
    const live = this.rates && this.rates[cur] > 0;
    const per = live ? this.rates[cur] : FALLBACK_PER_KES[cur];
    if (!per) return null;
    return { amount: Pricing.tidy(this.cfg.priceKes * per, cur), currency: cur, approx: !live };
  }

  /** What to charge by card: the visitor's currency when we can take it, otherwise USD. */
  async cardQuote(wantedCurrency) {
    const want = String(wantedCurrency || '').toUpperCase();
    const cur = this.cfg.cardCurrencies.includes(want) ? want : 'USD';
    return (await this.priceIn(cur)) || (await this.priceIn('USD'));
  }

  /** Both ways to pay, for the paywall screen. M-Pesa is always KES (Kenyan numbers only). */
  async quote({ cc, cur }) {
    const out = { baseKes: this.cfg.priceKes, options: [] };
    if (this.cfg.mpesa || this.cfg.paystack) out.options.push({ method: 'mpesa', amount: this.cfg.priceKes, currency: 'KES' });
    if (this.cfg.flw || this.cfg.paystack) {
      const want = String(cc || '').toUpperCase() === 'KE' ? 'KES' : cur;
      const q = await this.cardQuote(want);
      out.options.push({ method: 'card', amount: q.amount, currency: q.currency, approx: q.approx });
    }
    return out;
  }
}
module.exports = { Pricing, ZERO_DECIMAL };
