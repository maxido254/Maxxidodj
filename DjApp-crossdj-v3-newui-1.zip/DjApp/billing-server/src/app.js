'use strict';
const http = require('http');
const path = require('path');
const crypto = require('crypto');
const { Ledger } = require('./ledger');
const { State } = require('./state');
const C = require('./crypto');
const { Pricing } = require('./pricing');
const { createPayments, Mpesa } = require('./payments');

const MAX_BODY = 16 * 1024;
const SKEW_MS = 5 * 60 * 1000;          // a signed request is accepted for +/- 5 minutes, once
const ORDER_TTL_MS = 30 * 60 * 1000;
const MPESA_RECEIPT = /^[A-Z0-9]{8,12}$/;

class HttpError extends Error {
  constructor(status, code, extra) { super(code); this.status = status; this.code = code; this.extra = extra; }
}

function createApp(cfg, opts = {}) {
  const ledger = new Ledger(path.join(cfg.dataDir, 'ledger.jsonl'), cfg.ledgerKey);
  const state = new State();
  for (const e of ledger.load()) state.apply(e);               // throws if the ledger was tampered with: the server refuses to start
  const payments = createPayments(cfg, opts.fetch);
  const pricing = new Pricing(cfg, opts.fetch);
  const publicKey = C.publicKeyB64(cfg.tokenPrivateKey);

  const commit = (type, data) => { const e = ledger.append(type, data); state.apply(e); return e; };
  const proofHash = (v) => crypto.createHmac('sha256', cfg.ledgerKey).update('proof|' + v).digest('hex');

  // ------------------------------------------------------------------ small in-memory guards
  const nonces = new Map();         // "device:nonce" -> expiry
  const buckets = new Map();        // rate-limit key -> { n, reset }
  const limit = (key, max, windowMs) => {
    const now = Date.now();
    let b = buckets.get(key);
    if (!b || now > b.reset) { b = { n: 0, reset: now + windowMs }; buckets.set(key, b); }
    return ++b.n <= max;
  };
  const sweeper = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of nonces) if (v < now) nonces.delete(k);
    for (const [k, v] of buckets) if (v.reset < now) buckets.delete(k);
  }, 60000);
  sweeper.unref();

  // ------------------------------------------------------------------ money logic
  function activeEntitlement(did) {
    const e = state.entitlements.get(did);
    if (!e) return { ok: false, reason: 'not_paid' };
    if (e.revoked) return { ok: false, reason: e.reason === 'moved' ? 'moved' : 'revoked' };
    if (e.until && Date.now() > e.until) return { ok: false, reason: 'expired' };
    return { ok: true, ent: e };
  }

  /** Turns a provider-verified payment into an entitlement. Idempotent. */
  function confirm(order, r) {
    if (order.status === 'paid') return;
    if (order.status !== 'pending' && order.status !== 'expired') return;          // failed / revoked orders never come back to life
    if (r.currency && r.currency !== order.currency) { console.error('[billing] currency mismatch on', order.id); return; }
    if (r.amount !== undefined && !(r.amount >= order.amount)) { console.error('[billing] underpayment on', order.id, r.amount, '<', order.amount); return; }
    const receipt = String(r.receipt || 'REF:' + order.ref).toUpperCase().slice(0, 40);
    const owner = state.receipts.get(receipt);
    if (owner && owner !== order.id) { console.error('[billing] receipt', receipt, 'already used by', owner); return; }
    const until = cfg.entitlementDays ? Date.now() + cfg.entitlementDays * 86400e3 : null;
    commit('payment_confirmed', { id: order.id, receipt, amount: order.amount, currency: order.currency, features: cfg.features, until });
  }

  /** Asks the provider (never the phone, never a webhook body) what happened to the order. */
  async function refresh(order, force = false) {
    if (order.status !== 'pending' && order.status !== 'expired') return;
    const now = Date.now();
    if (order._busy || (!force && now - (order._last || 0) < 3000)) return;
    order._busy = true; order._last = now;
    try {
      const provider = order.method === 'mpesa' ? payments.mpesa : order.method === 'online' ? payments.online : payments.card;
      const r = await provider.query(order);
      if (r.state === 'paid') confirm(order, r);
      else if (r.state === 'failed') { if (order.status === 'pending') commit('payment_failed', { id: order.id, reason: r.reason || 'failed' }); }
      else if (order.status === 'pending' && now - order.created > ORDER_TTL_MS) commit('order_expired', { id: order.id });
    } catch (e) {
      console.error('[billing] refresh failed for', order.id, '-', e.message);
    } finally { order._busy = false; }
  }

  // ------------------------------------------------------------------ request plumbing
  async function authenticate(ctx, isRegister) {
    const h = ctx.req.headers;
    const did = String(h['x-device'] || ''), nonce = String(h['x-nonce'] || ''), sig = String(h['x-sig'] || '');
    const ts = Number(h['x-ts']);
    if (!did || !sig || !Number.isFinite(ts) || nonce.length < 8 || nonce.length > 64) throw new HttpError(401, 'unsigned');
    if (Math.abs(Date.now() - ts) > SKEW_MS) throw new HttpError(401, 'clock_skew', { serverTime: Date.now() });
    let pub;
    if (isRegister) {
      pub = ctx.json && ctx.json.pub;
      if (typeof pub !== 'string' || C.deviceIdOf(pub) !== did) throw new HttpError(401, 'bad_device');
    } else {
      const dev = state.devices.get(did);
      if (!dev) throw new HttpError(401, 'unknown_device');
      pub = dev.pub;
    }
    const msg = C.requestMessage(ctx.req.method, ctx.url.pathname + ctx.url.search, ts, nonce, ctx.raw);
    if (!C.verifyDeviceSignature(pub, msg, sig)) throw new HttpError(401, 'bad_signature');
    const nk = did + ':' + nonce;
    if (nonces.has(nk)) throw new HttpError(401, 'replay');
    nonces.set(nk, Date.now() + 2 * SKEW_MS);
    if (!limit('dev:' + did, 60, 60000)) throw new HttpError(429, 'rate_limited');
    ctx.did = did;
  }

  function requireAdmin(ctx) {
    const m = /^Bearer (.+)$/.exec(String(ctx.req.headers.authorization || ''));
    if (!limit('admin:' + ctx.ip, 30, 60000)) throw new HttpError(429, 'rate_limited');
    if (!m || !C.safeEqual(m[1], cfg.adminToken)) throw new HttpError(401, 'unauthorized');
  }

  const routes = [];
  const route = (method, re, handler, auth) => routes.push({ method, re, handler, auth });
  const html = (body) => ({ __raw: true, status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' }, body });
  const cardWanted = (cc, cur) => (String(cc || '').toUpperCase() === 'KE' || (!cc && !cur) ? 'KES' : cur);   // KES unless a visitor abroad says otherwise

  // ------------------------------------------------------------------ public routes
  route('GET', /^\/health$/, () => ({ ok: true }));
  route('GET', /^\/v1\/config$/, () => ({ serverTime: Date.now(), publicKey, features: cfg.features }));
  route('GET', /^\/v1\/quote$/, async (ctx) => ({
    ...(await pricing.quote({ cc: ctx.url.searchParams.get('cc'), cur: ctx.url.searchParams.get('cur') })),
    features: cfg.features, serverTime: Date.now(),
  }));

  // ------------------------------------------------------------------ device routes (every request is signed by the phone's own key)
  route('POST', /^\/v1\/register$/, async (ctx) => {
    const b = ctx.json || {};
    try { C.parseDevicePublicKey(b.pub); } catch { throw new HttpError(400, 'bad_key'); }
    const did = C.deviceIdOf(b.pub);
    if (!state.devices.has(did)) {
      const cc = /^[A-Za-z]{2}$/.test(b.cc || '') ? b.cc.toUpperCase() : '';
      commit('device_registered', { did, pub: b.pub, cc });
    }
    return { deviceId: did, serverTime: Date.now() };
  }, 'register');

  route('POST', /^\/v1\/checkout$/, async (ctx) => {
    const b = ctx.json || {};
    if (activeEntitlement(ctx.did).ok) throw new HttpError(409, 'already_pro');
    if (!limit('order:' + ctx.did, 6, 3600e3)) throw new HttpError(429, 'too_many_orders');
    let amount, currency, provider, proof; const extra = {};
    if (b.method === 'mpesa') {
      if (!payments.mpesa) throw new HttpError(400, 'method_unavailable');
      const phone = Mpesa.normalizePhone(b.phone);
      if (!phone) throw new HttpError(400, 'bad_phone');
      amount = cfg.priceKes; currency = 'KES'; provider = payments.mpesa; extra.phone = phone; proof = phone;
    } else if (b.method === 'card') {
      if (!payments.card) throw new HttpError(400, 'method_unavailable');
      const email = String(b.email || '').trim().toLowerCase();
      if (!/^[^\s@]{1,64}@[^\s@]{1,120}\.[^\s@]{2,}$/.test(email)) throw new HttpError(400, 'bad_email');
      const q = await pricing.cardQuote(cardWanted(b.cc, b.cur));
      amount = q.amount; currency = q.currency; provider = payments.card; extra.email = email; proof = email;
    } else if (b.method === 'online') {                 // hosted payment page (Paystack): the customer chooses M-Pesa or card on that page
      if (!payments.online) throw new HttpError(400, 'method_unavailable');
      const email = String(b.email || '').trim().toLowerCase();
      if (!/^[^\s@]{1,64}@[^\s@]{1,120}\.[^\s@]{2,}$/.test(email)) throw new HttpError(400, 'bad_email');
      const q = await pricing.cardQuote(cardWanted(b.cc, b.cur));
      amount = q.amount; currency = q.currency; provider = payments.online; extra.email = email; proof = email;
    } else throw new HttpError(400, 'bad_method');

    const id = 'ord_' + crypto.randomBytes(9).toString('base64url');     // the PRICE is decided here, never by the phone
    commit('order_created', { id, did: ctx.did, method: b.method, amount, currency, kes: cfg.priceKes, proof: proofHash(proof) });
    const order = state.orders.get(id);
    try {
      const r = await provider.start(order, extra);
      commit('order_ref', { id, ref: r.ref });
      const link = r.link && r.link.startsWith('/') ? cfg.publicUrl + r.link : r.link;
      return { orderId: id, status: 'pending', amount, currency, link, serverTime: Date.now() };
    } catch (e) {
      console.error('[billing] could not start payment', id, '-', e.message);
      commit('payment_failed', { id, reason: 'start_failed' });
      throw new HttpError(502, 'provider_error');
    }
  }, 'device');

  route('GET', /^\/v1\/order\/(?<id>[A-Za-z0-9_-]{4,40})$/, async (ctx) => {
    const order = state.orders.get(ctx.params.id);
    if (!order || order.did !== ctx.did) throw new HttpError(404, 'not_found');
    await refresh(order);
    return { status: order.status, amount: order.amount, currency: order.currency, serverTime: Date.now() };
  }, 'device');

  route('POST', /^\/v1\/entitlement$/, (ctx) => {
    const a = activeEntitlement(ctx.did);
    if (!a.ok) throw new HttpError(402, a.reason);
    const now = Date.now();
    const exp = Math.min(now + cfg.leaseDays * 86400e3, a.ent.until || Infinity);
    const payload = { v: 1, did: ctx.did, feat: a.ent.features, iat: Math.floor(now / 1000), exp: Math.floor(exp / 1000), oid: a.ent.orderId };
    return { token: C.signToken(cfg.tokenPrivateKey, payload), serverTime: now };
  }, 'device');

  route('POST', /^\/v1\/restore$/, (ctx) => {
    const b = ctx.json || {};
    if (!limit('restore:' + ctx.did, 6, 3600e3) || !limit('restore-ip:' + ctx.ip, 20, 3600e3)) throw new HttpError(429, 'rate_limited');
    const receipt = String(b.receipt || '').trim().toUpperCase();
    const order = state.orders.get(state.receipts.get(receipt));
    const p = order && (order.method === 'mpesa' ? Mpesa.normalizePhone(b.proof) : String(b.proof || '').trim().toLowerCase());
    // One answer for every kind of mismatch, so this cannot be used to probe which receipts exist.
    if (!order || order.status !== 'paid' || !p || !C.safeEqual(proofHash(p), order.proof)) throw new HttpError(404, 'not_found');
    if (order.until && Date.now() > order.until) throw new HttpError(402, 'expired');
    const mine = state.entitlements.get(ctx.did);
    if (mine && !mine.revoked && mine.orderId === order.id) return { ok: true, already: true };
    if (activeEntitlement(ctx.did).ok) throw new HttpError(409, 'already_pro');
    const binds = state.binds.get(order.id) || new Set();
    if (!binds.has(ctx.did) && binds.size >= cfg.maxDevices) throw new HttpError(403, 'device_limit');
    let from = null;
    for (const did of binds) { const e = state.entitlements.get(did); if (e && !e.revoked && e.orderId === order.id) from = did; }
    commit('device_rebound', { orderId: order.id, from, to: ctx.did, features: cfg.features, until: order.until || null });
    return { ok: true };
  }, 'device');

  // ------------------------------------------------------------------ provider callbacks (only ever a hint to go and ask the provider)
  route('POST', /^\/hook\/stk\/(?<secret>[^/]{8,80})$/, async (ctx) => {
    const ack = { ResultCode: 0, ResultDesc: 'Accepted' };
    if (!cfg.mpesa || !C.safeEqual(ctx.params.secret, cfg.mpesa.callbackSecret)) throw new HttpError(404, 'not_found');
    const cb = ctx.json && ctx.json.Body && ctx.json.Body.stkCallback;
    if (!cb || typeof cb.CheckoutRequestID !== 'string') return ack;
    const order = state.orders.get(state.byRef.get(cb.CheckoutRequestID));
    if (!order || order.method !== 'mpesa') return ack;
    const items = (cb.CallbackMetadata && Array.isArray(cb.CallbackMetadata.Item)) ? cb.CallbackMetadata.Item : [];
    const rc = items.find(i => i && i.Name === 'MpesaReceiptNumber');
    const receipt = rc && MPESA_RECEIPT.test(String(rc.Value)) ? String(rc.Value) : null;
    // Confirm with Safaricom first (that is what makes the order "paid"), then remember the SMS receipt number for restores.
    await refresh(order, true);
    if (receipt && order.status === 'paid' && !order.userReceipt && !state.receipts.has(receipt)) {
      commit('receipt_noted', { id: order.id, receipt });
    }
    return ack;
  });

  route('POST', /^\/hook\/flw$/, async (ctx) => {
    if (!cfg.flw || !C.safeEqual(ctx.req.headers['verif-hash'] || '', cfg.flw.webhookHash)) throw new HttpError(401, 'unauthorized');
    const txRef = ctx.json && ctx.json.data && ctx.json.data.tx_ref;
    const order = typeof txRef === 'string' ? state.orders.get(txRef) : null;
    if (order && order.method === 'card') await refresh(order, true);
    return { ok: true };
  });

  route('POST', /^\/hook\/paystack$/, async (ctx) => {
    if (!cfg.paystack) throw new HttpError(404, 'not_found');
    const sig = crypto.createHmac('sha512', cfg.paystack.secretKey).update(ctx.raw).digest('hex');
    if (!C.safeEqual(String(ctx.req.headers['x-paystack-signature'] || ''), sig)) throw new HttpError(401, 'unauthorized');
    const ref = ctx.json && ctx.json.data && ctx.json.data.reference;
    const order = typeof ref === 'string' ? state.orders.get(ref) : null;
    if (order) await refresh(order, true);
    return { ok: true };
  });

  route('GET', /^\/pay\/done$/, () => html(
    '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>MAXIDO DJ</title>' +
    '<body style="font-family:sans-serif;background:#111;color:#eee;text-align:center;padding:48px 20px">' +
    '<h2>Thank you</h2><p>Go back to MAXIDO DJ. PRO switches on by itself as soon as the payment is confirmed.</p></body>'));

  if (!cfg.live) {
    route('POST', /^\/mock\/pay\/(?<id>[A-Za-z0-9_-]+)$/, async (ctx) => {
      const order = state.orders.get(ctx.params.id);
      if (!order) throw new HttpError(404, 'not_found');
      payments.mock.markPaid(order);
      await refresh(order, true);
      return { status: order.status };
    });
  }

  // ------------------------------------------------------------------ admin
  route('GET', /^\/admin\/head$/, (ctx) => { requireAdmin(ctx); return { seq: ledger.seq, head: ledger.head }; });
  route('GET', /^\/admin\/verify$/, (ctx) => {
    requireAdmin(ctx);
    try { const v = Ledger.verifyFile(ledger.file, cfg.ledgerKey); return { ok: true, entries: v.entries.length, head: v.head }; }
    catch (e) { return { ok: false, error: e.message }; }
  });
  route('GET', /^\/admin\/orders$/, (ctx) => {
    requireAdmin(ctx);
    const rows = [...state.orders.values()].slice(-200).reverse().map(o => ({
      id: o.id, device: o.did.slice(0, 12), method: o.method, amount: o.amount, currency: o.currency, status: o.status,
      receipt: o.userReceipt || o.receipt, created: o.created, paidAt: o.paidAt, devices: (state.binds.get(o.id) || new Set()).size,
    }));
    return { orders: rows };
  });
  route('POST', /^\/admin\/revoke$/, (ctx) => {
    requireAdmin(ctx);
    const id = ctx.json && ctx.json.orderId;
    if (!state.orders.has(id)) throw new HttpError(404, 'not_found');
    commit('order_revoked', { id, reason: String(ctx.json.reason || 'revoked').slice(0, 80) });
    return { ok: true };
  });
  route('POST', /^\/admin\/grant$/, (ctx) => {
    requireAdmin(ctx);
    const b = ctx.json || {};
    const q = String(b.deviceId || '').toLowerCase();
    const matches = q.length >= 8 ? [...state.devices.keys()].filter((d) => d.startsWith(q)) : [];
    if (matches.length !== 1) throw new HttpError(404, matches.length > 1 ? 'ambiguous_device' : 'unknown_device');
    const did = matches[0];
    const note = String(b.note || '').trim().toUpperCase().slice(0, 120);
    if (note && state.manualNotes.has(note) && state.manualNotes.get(note) !== did && !b.force) throw new HttpError(409, 'receipt_already_used');
    const until = Number(b.days) > 0 ? Date.now() + Number(b.days) * 86400e3 : null;
    commit('manual_grant', { did, orderId: 'manual:' + crypto.randomBytes(4).toString('hex'), features: cfg.features, until, note });
    return { ok: true };
  });

  // ------------------------------------------------------------------ server
  function clientIp(req) {
    if (cfg.trustProxy) { const f = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim(); if (f) return f; }
    return req.socket.remoteAddress || '?';
  }
  function readBody(req) {
    return new Promise((resolve, reject) => {
      let n = 0; const chunks = [];
      req.on('data', (c) => { n += c.length; if (n > MAX_BODY) { reject(new HttpError(413, 'too_large')); req.destroy(); return; } chunks.push(c); });
      req.on('end', () => resolve(Buffer.concat(chunks)));
      req.on('error', reject);
    });
  }
  function send(res, status, obj) {
    const body = JSON.stringify(obj);
    res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    res.end(body);
  }

  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      const ip = clientIp(req);
      if (!limit('ip:' + ip, 120, 60000)) throw new HttpError(429, 'rate_limited');
      const raw = await readBody(req);
      for (const r of routes) {
        if (r.method !== req.method) continue;
        const m = url.pathname.match(r.re);
        if (!m) continue;
        const ctx = { req, res, url, raw, params: m.groups || {}, ip, json: null, did: null };
        if (raw.length) { try { ctx.json = JSON.parse(raw.toString('utf8')); } catch { throw new HttpError(400, 'bad_json'); } }
        if (r.auth) await authenticate(ctx, r.auth === 'register');
        const out = await r.handler(ctx);
        if (out && out.__raw) { res.writeHead(out.status, out.headers); res.end(out.body); return; }
        return send(res, 200, out === undefined ? { ok: true } : out);
      }
      throw new HttpError(404, 'not_found');
    } catch (e) {
      if (e instanceof HttpError) return send(res, e.status, { error: e.code, ...(e.extra || {}) });
      console.error('[billing] unexpected error:', e);
      send(res, 500, { error: 'server_error' });
    }
  });

  return {
    server, ledger, state, payments, publicKey, refresh, confirm,
    close: () => new Promise((r) => { clearInterval(sweeper); server.close(() => r()); server.closeAllConnections && server.closeAllConnections(); }),
  };
}

module.exports = { createApp, HttpError };
