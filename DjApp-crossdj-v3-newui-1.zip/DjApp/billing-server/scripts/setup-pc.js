'use strict';
// First-run helper for running the billing server on your own PC: creates the signing key, random secrets and a
// ready-to-use .env in TEST mode (fake payments). Safe to run again: existing keys and .env are never overwritten.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const keyFile = path.join(root, 'keys', 'token_private.pem');
const envFile = path.join(root, '.env');
const pubFile = path.join(root, 'PUBLIC_KEY.txt');

fs.mkdirSync(path.join(root, 'keys'), { recursive: true });
if (!fs.existsSync(keyFile)) {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  fs.writeFileSync(keyFile, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
  fs.writeFileSync(pubFile, publicKey.export({ type: 'spki', format: 'der' }).toString('base64'));
  console.log('Created your signing key in the "keys" folder. BACK IT UP (copy the folder to a USB stick).');
}
if (!fs.existsSync(envFile)) {
  const r = (n) => crypto.randomBytes(n).toString('hex');
  fs.writeFileSync(envFile, [
    'PAYMENT_MODE=live', 'PORT=8080', 'PUBLIC_URL=http://localhost:8080', 'DATA_DIR=./data',
    'TOKEN_PRIVATE_KEY_FILE=./keys/token_private.pem',
    'LEDGER_KEY=' + r(32), 'ADMIN_TOKEN=' + r(24), 'MPESA_CALLBACK_SECRET=' + r(24),
    'PRICE_KES=150', 'LEASE_DAYS=30', 'ENTITLEMENT_DAYS=0', 'MAX_DEVICES=3',
    'MPESA_ENV=production', 'MPESA_KEY=', 'MPESA_SECRET=', 'MPESA_SHORTCODE=', 'MPESA_PASSKEY=',
    'MPESA_TXN_TYPE=CustomerPayBillOnline', 'MPESA_PARTYB=', 'FLW_SECRET_KEY=', 'FLW_WEBHOOK_HASH=', '',
  ].join('\n'));
  console.log('Created .env (LIVE mode: real payments. Fill in MPESA_KEY, MPESA_SECRET, MPESA_SHORTCODE, MPESA_PASSKEY).');
}
console.log('\nPaste this into Billing.kt as SERVER_PUBLIC_KEY:\n' + fs.readFileSync(pubFile, 'utf8').trim() + '\n');
