'use strict';
// Runs before the server starts. If the Safaricom key/secret are not in .env yet, asks for them once (paste), then never again.
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { setEnv } = require('./envfile');

const envFile = path.join(__dirname, '..', '.env');
if (!fs.existsSync(envFile)) { console.log('.env is missing. Run connect.bat first.'); process.exit(1); }
const env = Object.fromEntries(fs.readFileSync(envFile, 'utf8').split(/\r?\n/).filter((l) => l.includes('=')).map((l) => [l.slice(0, l.indexOf('=')), l.slice(l.indexOf('=') + 1)]));
if (env.PAYMENT_MODE !== 'live' || (env.MPESA_KEY && env.MPESA_SECRET)) process.exit(0);

console.log('\nOne-time step: paste your Safaricom sandbox keys (portal > My Apps > your app > the copy buttons).\n');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const lines = []; const waiters = [];
rl.on('line', (l) => { lines.push(l); const w = waiters.shift(); if (w) w(); });
const ask = (q) => new Promise((res) => { process.stdout.write(q); const take = () => res((lines.shift() || '').trim()); if (lines.length) take(); else waiters.push(take); });
(async () => {
  const key = await ask('Consumer Key: ');
  const secret = await ask('Consumer Secret: ');
  rl.close();
  if (!/^[A-Za-z0-9]{20,100}$/.test(key) || !/^[A-Za-z0-9]{20,100}$/.test(secret)) {
    console.log('\nThat does not look right (letters and numbers only, no spaces). Use the copy buttons and try again.');
    process.exit(1);
  }
  setEnv(envFile, { MPESA_KEY: key, MPESA_SECRET: secret });
  console.log('\nSaved. You will not be asked again.\n');
})();
