'use strict';
// Creates the key that signs PRO tokens, plus random secrets for the ledger and the admin API.
// The PRIVATE key never leaves the server. The PUBLIC key is pasted into the app (Billing.kt).
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, '..', 'keys');
fs.mkdirSync(dir, { recursive: true });
const file = path.join(dir, 'token_private.pem');
if (fs.existsSync(file)) { console.error(file + ' already exists: refusing to overwrite (that would lock out every paid phone).'); process.exit(1); }

const { privateKey, publicKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
fs.writeFileSync(file, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
const pub = publicKey.export({ type: 'spki', format: 'der' }).toString('base64');

console.log('Private key written to keys/token_private.pem  (BACK IT UP, never share it, never commit it)\n');
console.log('App public key (paste into Billing.kt as SERVER_PUBLIC_KEY):\n' + pub + '\n');
console.log('Random secrets for your environment settings:');
console.log('LEDGER_KEY=' + crypto.randomBytes(32).toString('hex'));
console.log('ADMIN_TOKEN=' + crypto.randomBytes(24).toString('hex'));
console.log('MPESA_CALLBACK_SECRET=' + crypto.randomBytes(24).toString('hex'));
