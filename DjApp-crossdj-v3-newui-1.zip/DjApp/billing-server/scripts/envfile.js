'use strict';
const fs = require('fs');

/** Sets KEY=value lines in a .env file (replaces an existing KEY, otherwise appends). */
function setEnv(file, values) {
  let lines = fs.existsSync(file) ? fs.readFileSync(file, 'utf8').split(/\r?\n/) : [];
  for (const [k, v] of Object.entries(values)) {
    const i = lines.findIndex((l) => l.startsWith(k + '='));
    if (i >= 0) lines[i] = k + '=' + v; else lines.push(k + '=' + v);
  }
  fs.writeFileSync(file, lines.filter((l, i) => l !== '' || i < lines.length - 1).join('\n').replace(/\n*$/, '\n'), { mode: 0o600 });
}
module.exports = { setEnv };
