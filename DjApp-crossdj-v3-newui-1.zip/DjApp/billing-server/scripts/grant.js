'use strict';
// Unlock PRO by hand after you have checked that the money really arrived in YOUR M-Pesa.
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const envFile = path.join(__dirname, '..', '.env');
if (!fs.existsSync(envFile)) { console.log('.env not found. Run start-all.bat once first.'); process.exit(1); }
const env = Object.fromEntries(fs.readFileSync(envFile, 'utf8').split(/\r?\n/).filter((l) => l.includes('=')).map((l) => [l.slice(0, l.indexOf('=')), l.slice(l.indexOf('=') + 1)]));

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const lines = []; const waiters = [];
rl.on('line', (l) => { lines.push(l); const w = waiters.shift(); if (w) w(); });
const ask = (q) => new Promise((res) => { process.stdout.write(q); const take = () => res((lines.shift() || '').trim()); if (lines.length) take(); else waiters.push(take); });

(async () => {
  console.log('\nBEFORE you continue: open your M-Pesa app / statement (not just a screenshot) and confirm that');
  console.log('  - the money (KSh 150 or more) really arrived, from this customer, a few minutes ago');
  console.log('  - the receipt code (10 letters/numbers, like SJK1ABC234) matches what the customer sent\n');
  const id = (await ask('Customer Phone ID (from their WhatsApp message, or the 8 letters in Settings > PRO): ')).replace(/\s+/g, '');
  const receipt = (await ask('M-Pesa receipt code: ')).toUpperCase().replace(/\s+/g, '');
  const days = await ask('Days of PRO [Enter = for life]: ');
  rl.close();
  if (id.length < 8) { console.log('\nThe Phone ID must be at least 8 characters. Nothing done.'); process.exit(1); }
  if (!/^[A-Z0-9]{8,12}$/.test(receipt)) { console.log('\nThat does not look like an M-Pesa receipt code. Nothing done.'); process.exit(1); }
  const body = { deviceId: id, note: receipt };
  if (/^\d+$/.test(days)) body.days = Number(days);
  try {
    const r = await fetch(`http://127.0.0.1:${env.PORT || 8080}/admin/grant`, {
      method: 'POST', headers: { Authorization: 'Bearer ' + env.ADMIN_TOKEN, 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    });
    const j = await r.json().catch(() => ({}));
    if (r.status === 200) console.log('\nDONE. Tell the customer to open the app (with internet) and tap CHECK PRO NOW.');
    else if (j.error === 'unknown_device') console.log('\nThat Phone ID is not known to the server yet. Ask the customer to open Settings > PRO and tap CHECK PRO STATUS NOW (or tap WHATSAPP US MY PHONE ID), then try again.');
    else if (j.error === 'ambiguous_device') console.log('\nMore than one phone starts with that. Use the full Phone ID from their WhatsApp message.');
    else if (j.error === 'receipt_already_used') console.log('\nSTOP: that receipt code was already used to unlock a DIFFERENT phone. Do not unlock this one.');
    else console.log('\nFailed (' + r.status + '): ' + (j.error || 'unknown'));
  } catch (e) {
    console.log('\nCould not reach the server. Is start-all.bat running?');
  }
})();
