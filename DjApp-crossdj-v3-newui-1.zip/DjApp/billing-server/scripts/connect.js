'use strict';
// Connects everything for testing on your PC:
//   * your ngrok address  -> .env (PUBLIC_URL) and the app (SERVER_URL in Billing.kt)
//   * your Safaricom Daraja sandbox keys -> .env (you paste them; nothing is stored anywhere else)
//   * your server's public key -> the app (SERVER_PUBLIC_KEY in Billing.kt)
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { setEnv } = require('./envfile');

require('./setup-pc.js');                                   // makes keys + .env first if they do not exist yet
const root = path.join(__dirname, '..');
const envFile = path.join(root, '.env');
const billingKt = path.join(root, '..', 'app', 'src', 'main', 'java', 'com', 'example', 'djapp', 'Billing.kt');
const DEFAULT_URL = 'https://recoil-flashback-battalion.ngrok-free.dev';
const SANDBOX_PASSKEY = 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919';

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const lines = [];
rl.on('line', (l) => lines.push(l));
const waiters = [];
rl.on('line', () => { const w = waiters.shift(); if (w) w(); });
const ask = (q) => new Promise((res) => {
  process.stdout.write(q);
  const take = () => res((lines.shift() || '').trim());
  if (lines.length) take(); else waiters.push(take);
});

(async () => {
  console.log('\n--- Connect MAXIDO billing (test mode with the Safaricom SANDBOX) ---\n');
  let url = (await ask(`Your ngrok address [Enter = ${DEFAULT_URL}]: `)) || DEFAULT_URL;
  url = url.replace(/\/+$/, '');
  if (!/^https:\/\/[a-z0-9.-]+$/i.test(url)) { console.log('That is not an https address. Nothing changed.'); process.exit(1); }

  const key = await ask('Consumer Key (use the copy button in the Safaricom portal, then paste): ');
  const secret = await ask('Consumer Secret (paste): ');
  const pass = (await ask('Passkey [Enter = the sandbox one from the portal]: ')) || SANDBOX_PASSKEY;
  const code = (await ask('Short Code [Enter = 174379]: ')) || '174379';
  rl.close();
  if (!/^[A-Za-z0-9]{20,100}$/.test(key) || !/^[A-Za-z0-9]{20,100}$/.test(secret)) {
    console.log('\nThe Consumer Key or Secret does not look right (letters and numbers only, no spaces). Nothing changed. Try again with the copy buttons.');
    process.exit(1);
  }
  setEnv(envFile, {
    PAYMENT_MODE: 'live', MPESA_ENV: 'sandbox', MPESA_KEY: key, MPESA_SECRET: secret,
    MPESA_SHORTCODE: code, MPESA_PASSKEY: pass, PUBLIC_URL: url, TRUST_PROXY: '1',
  });
  console.log('\nSaved to .env (M-Pesa SANDBOX, your ngrok address).');

  const pub = fs.readFileSync(path.join(root, 'PUBLIC_KEY.txt'), 'utf8').trim();
  if (fs.existsSync(billingKt)) {
    let s = fs.readFileSync(billingKt, 'utf8');
    const a = /(private const val SERVER_URL = )"[^"]*"/, b = /(private const val SERVER_PUBLIC_KEY = )"[^"]*"/;
    if (a.test(s) && b.test(s)) {
      s = s.replace(a, `$1"${url}"`).replace(b, `$1"${pub}"`);
      fs.writeFileSync(billingKt, s);
      console.log('Updated the app: Billing.kt now has your address and public key.');
    } else console.log('Could not find the two settings in Billing.kt. Paste them by hand:\nSERVER_URL = "' + url + '"\nSERVER_PUBLIC_KEY = "' + pub + '"');
  } else {
    console.log('Billing.kt not found next to this folder. Paste these into it:\nSERVER_URL = "' + url + '"\nSERVER_PUBLIC_KEY = "' + pub + '"');
  }
  console.log('\nNext:\n 1) Run start-pc.bat (keep it open)\n 2) In another window: ngrok http --url=' + url.replace('https://', '') + ' 8080   (port 8080, not 80)\n 3) Rebuild the app.\n');
})();
