'use strict';
const { loadConfig } = require('./src/config');
const { createApp } = require('./src/app');

let cfg;
try { cfg = loadConfig(); } catch (e) { console.error('Configuration error:', e.message); process.exit(1); }
if (cfg.live && !/^https:\/\//.test(cfg.publicUrl)) console.warn('WARNING: PUBLIC_URL should be https:// (Safaricom and Flutterwave call back to it, and the app only talks https)');

let app;
try { app = createApp(cfg); } catch (e) { console.error('REFUSING TO START:', e.message); process.exit(2); }

if (cfg.testPayments) {
  console.warn('\n!!! TEST PAYMENTS ARE ON: fake payments unlock PRO. Fine for testing. NEVER give the app to customers while you see this. !!!\n');
}
app.server.listen(cfg.port, () => {
  console.log(`MAXIDO billing server on :${cfg.port}  mode=${cfg.live ? 'LIVE' : 'MOCK'}  price=KSh ${cfg.priceKes}  ledger entries=${app.ledger.seq}`);
  console.log('ledger head:', app.ledger.head);
  console.log('app public key (paste into Billing.kt SERVER_PUBLIC_KEY):', app.publicKey);
});
// Tell the owner straight away whether the M-Pesa keys work (instead of finding out when a customer pays).
if (cfg.live && app.payments.mpesa && typeof app.payments.mpesa.token === 'function') {
  app.payments.mpesa.token()
    .then(() => console.log(`M-Pesa login OK (${cfg.mpesa.env})`))
    .catch((e) => console.log('M-Pesa login FAILED: ' + e.message + '. Check MPESA_KEY / MPESA_SECRET in .env (delete those two lines\' values and run start-all.bat to paste them again).'));
}
if (cfg.live && cfg.paystack) {
  fetch('https://api.paystack.co/transaction?perPage=1', { headers: { Authorization: 'Bearer ' + cfg.paystack.secretKey }, signal: AbortSignal.timeout(15000) })
    .then((r) => console.log(r.ok ? `Paystack key OK (${/_live_/.test(cfg.paystack.secretKey) ? 'LIVE money' : 'TEST mode, fake money'})` : `Paystack key REJECTED (HTTP ${r.status}). Check PAYSTACK_SECRET_KEY in .env.`))
    .catch((e) => console.log('Paystack check failed: ' + e.message));
}
process.on('SIGTERM', () => app.close().then(() => process.exit(0)));
