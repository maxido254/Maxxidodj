'use strict';
const { loadConfig } = require('./src/config');
const { createApp } = require('./src/app');

let cfg;
try { cfg = loadConfig(); } catch (e) { console.error('Configuration error:', e.message); process.exit(1); }
if (cfg.live && !/^https:\/\//.test(cfg.publicUrl)) console.warn('WARNING: PUBLIC_URL should be https:// (Safaricom and Flutterwave call back to it, and the app only talks https)');

let app;
try { app = createApp(cfg); } catch (e) { console.error('REFUSING TO START:', e.message); process.exit(2); }

app.server.listen(cfg.port, () => {
  console.log(`MAXIDO billing server on :${cfg.port}  mode=${cfg.live ? 'LIVE' : 'MOCK'}  price=KSh ${cfg.priceKes}  ledger entries=${app.ledger.seq}`);
  console.log('ledger head:', app.ledger.head);
  console.log('app public key (paste into Billing.kt SERVER_PUBLIC_KEY):', app.publicKey);
});
// Tell the owner straight away whether the M-Pesa keys work (instead of finding out when a customer pays).
if (cfg.live && app.payments.mpesa && typeof app.payments.mpesa.token === 'function') {
  app.payments.mpesa.token()
    .then(() => console.log(`M-Pesa login OK (${cfg.mpesa.env})`))
    .catch((e) => console.log('M-Pesa login FAILED: ' + e.message + '. Check MPESA_KEY / MPESA_SECRET in .env (delete those two lines\' values and run start-all.bat to paste them again).'));
}
process.on('SIGTERM', () => app.close().then(() => process.exit(0)));
