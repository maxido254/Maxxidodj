@echo off
title Unlock PRO by hand
cd /d "%~dp0"
node scripts\grant.js
echo.
pause
