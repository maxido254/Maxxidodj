@echo off
title MAXIDO billing server
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Get the LTS version from https://nodejs.org then run this again. & pause & exit /b 1)
node scripts\setup-pc.js
echo Starting the server. Keep this window open. Close it to stop.
:loop
node --env-file=.env server.js
echo Server stopped. Restarting in 5 seconds (close this window to quit)...
timeout /t 5 >nul
goto loop
