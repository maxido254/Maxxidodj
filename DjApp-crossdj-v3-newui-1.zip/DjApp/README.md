# MAXIDO DJ

Landscape 2-deck DJ app with sampler packs and video mixing (Kotlin/Compose UI + C++/Oboe audio engine).

## Build
1. Open in Android Studio (Ladybug or newer), let Gradle sync (NDK + CMake via SDK Manager).
2. Run on a real device (emulators have poor audio latency).
Cloud build: push to GitHub, Actions > Build APK > Run workflow, download `DjApp-debug-apk`.

## Screen map
| Control | What it does |
|---|---|
| purple / teal **+** | load a track onto deck A / B |
| **platter** | drag in circles to scratch; hold still to stop; ring = track progress |
| **TEMPO** fader | +/- range set in Settings (default 8 %); snaps to 0 |
| **CUE** | playing: back to cue and pause. Paused elsewhere: set cue. Hold at cue: preview |
| **SYNC** | matches tempo to the other deck (needs BPM, detected after load) |
| waveform icon (left) | **Stems**: mute / level per stem, ACAPELLA, NO VOCALS, BEATLESS |
| ↻ | **Loop**: auto-loop 1/4..16 beats, LOOP IN / LOOP OUT / EXIT / RELOOP, halve / double |
| **LIB** | **Library**: every audio file on the phone with BPM + key, sortable, load to deck A / B |
| sliders icon | **Mixer**: volume + DJ filter |
| **FX** | **Effects**: filter, reverb (+ room size), phaser (+ rate) per deck |
| grid icon | 4 **hot cues** per deck (tap set/jump, long-press clear) |
| **SMP** | **Sampler**: built-in free samples on 2 banks of 8 pads, one-shot / hold / loop (see below) |
| **VID** | **Video mixer**: one video per deck, crossfaded on screen, fullscreen output (see below) |
| gear (right) | Settings: MIXER (tempo range, crossfader curve, master), STEMS, SAMPLER, VIDEO, DISPLAY, **DEVELOPERS** (Maxido Ent. contact, WhatsApp, report a problem) |
| **REC** | records the master output to a 16-bit WAV (app Music folder) |

## EQ
Each deck has a 3-band EQ (bass 110 Hz shelf, mid 1 kHz, treble 5 kHz shelf), -26 dB (almost a kill) to +12 dB (boost), with a click-free smoothing.
A **BASS fader sits next to the filter fader** on every deck (middle = flat, tap the label to reset); Mixer panel has all three bands, EQ FLAT and BASS KILL.
Measured here: bass +12 dB lifts a 60 Hz tone +10.8 dB and leaves 1 kHz / 8 kHz unchanged.

## Videos with their sound
Videos now appear in the **Library** (marked ▶; Android 13+ asks for video access once). Load one to deck A or B and its **sound plays like a track while the
picture is mixed on the VID screen**, locked to the deck (play, cue, scratch, tempo). On the VID panel use **VIDEO + SOUND** for this; **SILENT LOOP** is for
extra picture-only loops. Beat sync, EQ, filter and stems all work on a video's sound.

## Deck layout
Each jog wheel has a **filter fader on its left** (centre = off, down = low-pass, up = high-pass, snaps to off in the middle; tap its label to reset)
and **VOCAL / MELODY / BASS / INSTR buttons underneath** (INSTR = the drums/percussion part). Tap a button to mute that part, tap again to bring it back.
They light up once the track's stems are ready (prepared tracks: immediately).

## Beat sync, key lock and scratch
* **SYNC** makes this deck play at **exactly** the other deck's BPM (the BPM shown under the deck name is the live, tempo-adjusted value, so
  both decks read the same number), jumps to the same place in the beat and then **stays locked**. The tempo is never nudged: if the beats drift
  apart (after a scratch, say) the deck is re-aligned with a small jump. Only a track more than 50 % away in tempo (e.g. 64 vs 128 BPM) is matched
  in half / double time. The button stays lit; tap it again, or move that deck's tempo fader, to leave sync.
* **KEYLOCK** (button under each tempo fader, default in Settings > PERF): tempo changes without changing pitch (WSOLA time-stretch in the
  native engine, about 6 million multiply-adds per second per deck). It switches itself off at exactly 0 % tempo.
  Tested on this machine: a 440 Hz tone stays at 440.0 Hz at +12 % tempo; without key lock it rises to 492.8 Hz.
* **Scratch**: the platter angle is now the track position (200 deg/s = 33 rpm) and the deck follows it with ~18 ms smoothing, so there is no zipper
  noise between touch events. Holding the platter still is silence; backspins and slow drags work. A tap does not stop the music.

## Prepared stems (the VirtualDJ way) and the PRO separator
* Stems are **VOCAL, MELODY, BASS, DRUMS**. ACAPELLA = vocal only, INSTRUMENTAL = no vocal, BEATLESS = no drums.
* **Prepare tracks before your set**: Library > **P** on a track (or PREP ALL), or STEMS panel > PREPARE THIS TRACK. A low-priority queue decodes,
  finds BPM / beat grid / key, separates the stems and saves them in the app's own storage. Loading a prepared track is **instant** (no decoding,
  analysis or separation) and uses almost no CPU while you play. By default the queue pauses while a deck is playing.
* Storage: about 170 MB per 4-minute song; a cap (1 / 3 / 8 GB) deletes the least recently used tracks first (Settings > STEMS).
* **PRO** separator (used by PREP, or live if you choose it): 4096-point FFT, looser drum margin for the voice, 4-way masks that sum to 1,
  mask smoothing. It is still classical signal processing, not a neural network: cleaner than BETTER but with some bleed. I could not listen to it
  here, so judge it by ear and tell me what to tune. AI (SCNet) is now light enough for budget phones when used on prepared tracks.

## Budget phones (Itel A80 and similar)
First launch detects a budget phone (low-RAM flag or under ~5 GB) and applies: audio buffer BALANCED, LITE UI, and stems only for prepared tracks.
Also: track loading no longer maps files on the UI thread, analysis runs on one background thread, the overview waveform is drawn from a cached bitmap,
the playhead updates no longer recompose the whole waveform. Settings > PERF: audio buffer FAST / BALANCED / SAFE (use SAFE if you still hear crackle).

## Sampler
Tap **SMP** again (or Back) to close it. The strip at the top (over the waveforms) shows the 8 pads of the current bank (banks 1-2). Pads fire on touch-down. The strip leaves the filter / bass faders, platters, CUE and PLAY uncovered, so you can hit pads
  while using them (multi-touch).
* The built-in free samples are fixed on the pads (bank 1: pads 1-8, bank 2: pads 9-10). Samples cannot be added or removed,
  and there is no browse button.
* Pad mode (button under the banks, or Settings > SAMPLER): **ONE-SHOT**, **HOLD** (plays while pressed), **LOOP** (tap on / tap off).
* Samples are decoded (max 30 s each) into the cache and played by the native engine, mixed after the decks, so they are
  included in REC.

## Video mixing
Tap **VID**. Each deck has a video layer; the picture is muted (all sound comes from the audio engine).
* **Video as a track**: load a video file with FILE A / FILE B (Library panel, or the + buttons). The audio is decoded as usual and
  the picture stays locked to the deck: it follows play / pause / cue / scratch position and the tempo fader.
* **Clips**: LOAD CLIP puts a separate looping video on a deck. It plays while the deck plays (or always, with PLAY WITHOUT DECK).
* **Mix**: BLEND (A * (1-x) + B * x), DIP (fade through black) or CUT, driven by the audio crossfader or a MANUAL video fader.
  With only one video loaded it simply shows that one. BRIGHT dims the output.
* **480p output** (Settings > VIDEO, on by default, made for budget phones like the Itel A80): a video bigger than 480p is converted once into a picture-only
  480p copy (cached, max 600 MB) and that copy is played. The original keeps playing while the copy is made ("Making 480p copy…" on the layer), then the picture
  switches over by itself. Sound is untouched. Uses Media3 Transformer (`VideoProxy.kt`).
* **FULLSCREEN OUTPUT** shows only the mixed picture (tap to close). The video keeps running when the panel is closed.

## Settings (saved between launches)
MIXER: tempo range, crossfader curve (smooth / sharp-cut / linear), master gain. STEMS: quality. SAMPLER: pad mode, volume.
VIDEO: transition, fader source, speed follows tempo, brightness. DISPLAY: stay awake. DEVELOPERS: contact and build info.

## Library, BPM and key (all offline)
**Choose a folder:** in the Library tap **+ FOLDER** and pick the folder with your mixes or videos (sub-folders are included). It becomes a button next to **ALL**; tap it to show only that folder. **REMOVE** forgets the selected folder. ANALYSE and PREP ALL then work on just that folder.
Tap **LIB**, allow audio access once, and the app lists the audio files on the device. **ANALYSE** works through the
tracks in the background (low priority, stop any time): it decodes ~80 s from the middle of each file and detects
**BPM** (whole-track analysis: complex-domain + spectral-flux onsets, comb-filter tempo tracking with a 120 BPM prior, 0.01 BPM fine search, whole-BPM snapping, kick-weighted beat grid; the same family of method Mixxx/QM-DSP uses, since VirtualDJ's and Serato's own detectors are closed) and **key** (chroma + Krumhansl-Schmuckler, shown as Camelot code + name, e.g. `8A Am`).
Results are cached in app storage, so each track is only analysed once (changed files are re-analysed).
Everything learned about a song (BPM, beat grid, key, waveform and the decoded audio) is saved on disk, so loading it again, even after quitting the app, needs no decoding or analysis. Sort by title, artist, BPM, key (Camelot wheel order 1A, 1B, 2A ...) or length; tap a sort button again to flip direction.
Tracks that are not analysed yet always sit at the bottom. **A / B** load a track onto a deck (refused while that deck plays).
Loading a track also shows its key under the deck name. Key detection is an estimate: relative major/minor mix-ups are
the usual error, and neighbours on the Camelot wheel mix well anyway.

## Stems
Two separators (Settings > Stem quality, applies to the next loaded track):
* **Better** (default, `HpssSeparator`): STFT percussive/harmonic split (drums), harmonic low band (bass),
  harmonic + centre-panned mid band (vocals), remainder = other. "Other" is computed as mix minus the other
  three, so stems always sum back to the original exactly. Streams the file, low RAM. Runs on a low-priority thread.
* **Fast** (`LiteSeparator`): simple filters.
* **AI** (`ScnetSeparator`, in `Scnet.kt`): SCNet neural network (int8 ONNX, MIT licence) via ONNX Runtime, **fully offline**. Two SCNet models (small ~13 MB for budget phones, large ~45 MB for 6 GB+ phones) is bundled
  in the APK: the Gradle task `fetchScnetModel` downloads it once at build time into `app/src/main/assets/` (`scnet.int8.onnx`, `scnet-large.int8.onnx`)
  (git-ignored, SHA-256 checked) and the app unpacks it on first use. The model contains only the network, so `ScnetDsp` does the STFT / inverse STFT
  (4096 FFT, hop 1024) in Kotlin. If you already have the file, copy it there with that name and no download happens.
  (It replaced HT-Demucs, whose 166 MB model ran out of memory on 4 GB phones such as the Itel A80.)
  The app only uses the internet for Settings > STORE (skins / sampler packs); stems never go online. If the model is missing from a build, it falls back to Better.
Stem mute/level changes are ramped in the engine so there are no clicks.

## Effects (engine.cpp, per deck)
* DJ filter: one knob, low-pass to the left, high-pass to the right, 24 dB/oct.
* Phaser: 6 all-pass stages, swept sine LFO, stereo offset, feedback.
* Reverb: Freeverb (8 combs + 4 all-pass per channel), wet + room size; tail keeps ringing after pause.
* Loops: sample-accurate wrap in the audio thread.

Known gaps: tempo still changes pitch (no key lock yet); video output is on the phone screen only (no external display yet).

## Prepared stems, .mxs packs and bleed
* Prepared tracks live in the app's own storage and play **without the original song** (Library > "Prepared stems (.mxs)").
* **EXPORT** writes one `.mxs` file (beat grid, key, waveform and the 4 stems). **IMPORT .mxs** brings it back, on this or another phone.
* Settings > Prepared tracks > **AI** uses the SCNet neural network in a separate low-memory process (works on weak phones, just slowly; falls back to PRO only if the phone truly cannot run it).
  BETTER and PRO are classical signal processing and always leave some bleed.
* Every prepared track also gets a vocal clean-up pass: voice left in the MELODY stem is moved to the VOCAL stem, so turning VOCAL off removes the voice.

## Custom mappings (keyboard, gamepad, USB MIDI)
Settings > **CONTROLS**. Tap **LEARN** on a row, then press the key / pad / MIDI button (or turn the MIDI knob for knob rows). Saved on the phone.
* Per deck: play / pause, cue (hold = preview), sync, key lock, hot cues 1-4, loops, stem mutes.
* Effects per deck: reverb, phaser, low-pass / high-pass (hold), echo out, loop out, backspin, all FX off, plus filter / reverb / phaser knobs.
* Mixer: crossfader (knob or A / centre / B buttons), deck volumes, record on / off.
* Sampler: pads 1-16 (both banks) and stop all samples.
* USB MIDI controllers need an OTG cable and must be class-compliant. Back, Home and the volume keys are never taken.

## Custom layout
Settings > **LAYOUT**: show / hide the waveform overview, filter and bass faders, stem buttons, performance effects, level meter and SYNC buttons, and resize
the waveform area, platter area, bottom bar, round buttons and faders. **CLEAN SCREEN** hides everything optional (good for screen recordings); **RESET LAYOUT**
restores the original. Settings, LIB, FX, SMP, VID, CUE and PLAY are never hidden.

## Waveforms at the top
By default the two waveforms are a small strip at the very top of the screen. **Drag a waveform left / right to scratch** (drag right = back in time, left = forward;
a plain tap does nothing, and the deck carries on when you let go). **Touch or drag the thin strip under each waveform to jump to any point of the song.**
Settings > LAYOUT: turn "Waveforms at the very top" off to put them back under the top bar, and resize them with the TOP WAVES slider.

## Pro-DJ look
Darker, flatter panels with a glossy jog wheel, and three new pieces you can switch in Settings > LAYOUT:
* **Deck info**: big BPM, key, pitch % and elapsed / remaining time beside each platter.
* **Hot-cue pads**: four colored pads under each platter (tap = set / jump, long-press = clear).
* **Channel strips**: HI / MID / LOW and volume faders for both decks in the centre, with the master level between them. (The BASS fader next to the filter is now off by default because LOW is in the strip; turn it back on in LAYOUT.)


## Online store: skins and sampler packs (Settings > STORE)

Users can download extra **skins** (colour themes) and **sampler packs** (16 pads of audio) without a new app version.
The only network address the app contacts is the catalog URL in `Store.kt` (`CATALOG_URL`). Everything else comes from the
URLs listed in that catalog, and a file is installed only if it is `https` and its SHA-256 matches the catalog.

* Skin = one small `.json` file (colours). Pack = a `.zip` with audio files (mp3 / ogg / wav / m4a / aac / flac, max 16) and an optional `pack.json` with pad names.
* Host it for free with GitHub Pages: see `server/README.md`. Add items, run `python3 server/build_catalog.py`, push.
* Downloaded files live in the app's private storage; REMOVE (X) deletes them, USE switches the active skin / pack, and the choice is remembered.
* The skin changes the main palette (backgrounds, panels, buttons, deck A / B colours, accent). A few small details still use fixed colours.

## Speed pass (low-end phones)
* Builds (even `assembleDebug`) are now non-debuggable and R8-optimised (`app/build.gradle.kts`, `proguard-rules.pro`): Compose is several times faster than in a debug build.
* One shared UI clock (`UiClock` in Controls.kt) replaces 7 separate frame loops; ~30 fps on LITE UI, ~20 fps while a video decodes.
* Scrolling waveform uses per-track precomputed heights and a 16-colour table (no pow()/colour maths while drawing); overview redraws only when the marker moves a pixel.
* Platter artwork is static; only the progress ring and tick redraw. REC blink runs only while recording.
* Video layers that are empty or faded out get no surface (no compositing/decoding). Phaser sweep maths runs every 8 samples.
