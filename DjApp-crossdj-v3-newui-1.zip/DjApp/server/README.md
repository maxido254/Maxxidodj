# Hosting the MAXIDO DJ store (free, GitHub Pages)

1. Create a new GitHub repo, e.g. `maxido-store`, and copy this `server/` folder into it (plus an empty `docs/`).
2. Put skins in `server/items/skins/` and packs in `server/items/packs/<id>/`.
3. Run `python3 server/build_catalog.py https://YOUR-NAME.github.io/maxido-store`. It writes `docs/catalog.json` and `docs/files/`.
4. Push, then repo Settings > Pages > Deploy from branch > `main` / `docs`.
5. In `Store.kt` set `CATALOG_URL = "https://YOUR-NAME.github.io/maxido-store/catalog.json"` and build the app again (once).

After that, adding new skins / packs never needs a new app version: add files, run the script, push.

Rules the app enforces: https only, SHA-256 must match, skins max 256 KB, packs max 60 MB and 16 audio files,
ids are `a-z 0-9 _ -`. Only use audio you own or have the licence to distribute.
