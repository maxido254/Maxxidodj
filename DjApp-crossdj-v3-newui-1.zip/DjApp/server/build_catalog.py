#!/usr/bin/env python3
"""Builds the store from server/items/ into docs/ (catalog.json + the files). Publish docs/ with GitHub Pages.

  python3 server/build_catalog.py https://YOUR-NAME.github.io/maxido-store

Skins:  server/items/skins/<id>.json            (needs "id" and "name"; colours as "#RRGGBB")
Packs:  server/items/packs/<id>/                (audio files + pack.json with "name", "pads", optional "author" / "desc" / "version")
Bump "version" in a skin / pack to make the app show UPDATE.
"""
import hashlib, json, os, re, shutil, sys, zipfile

if len(sys.argv) != 2 or not sys.argv[1].startswith("https://"):
    sys.exit(__doc__)
base = sys.argv[1].rstrip("/")
here = os.path.dirname(os.path.abspath(__file__))
src = os.path.join(here, "items")
out = os.path.join(os.path.dirname(here), "docs")
ID_OK = re.compile(r"^[a-z0-9][a-z0-9_-]{0,39}$")
AUDIO = {".mp3", ".ogg", ".wav", ".m4a", ".aac", ".flac"}
shutil.rmtree(out, ignore_errors=True)
os.makedirs(os.path.join(out, "files"))
items = []

def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 16), b""):
            h.update(b)
    return h.hexdigest()

def add(kind, meta, path):
    iid = meta["id"]
    assert ID_OK.match(iid), f"bad id: {iid}"
    items.append({"id": iid, "type": kind, "name": meta.get("name", iid), "author": meta.get("author", ""),
                  "desc": meta.get("desc", ""), "version": meta.get("version", 1),
                  "url": f"{base}/files/{os.path.basename(path)}", "sha256": sha(path), "size": os.path.getsize(path)})

sk = os.path.join(src, "skins")
for f in sorted(os.listdir(sk)) if os.path.isdir(sk) else []:
    if f.endswith(".json"):
        meta = json.load(open(os.path.join(sk, f)))
        dst = os.path.join(out, "files", f"{meta['id']}.json")
        shutil.copy(os.path.join(sk, f), dst)
        add("skin", meta, dst)

pk = os.path.join(src, "packs")
for d in sorted(os.listdir(pk)) if os.path.isdir(pk) else []:
    folder = os.path.join(pk, d)
    if not os.path.isdir(folder):
        continue
    meta = json.load(open(os.path.join(folder, "pack.json")))
    meta.setdefault("id", d)
    audio = [f for f in sorted(os.listdir(folder)) if os.path.splitext(f)[1].lower() in AUDIO]
    assert 0 < len(audio) <= 16, f"{d}: needs 1 to 16 audio files"
    dst = os.path.join(out, "files", f"{meta['id']}.zip")
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_STORED) as z:     # audio is already compressed
        z.write(os.path.join(folder, "pack.json"), "pack.json")
        for f in audio:
            z.write(os.path.join(folder, f), f)
    add("pack", meta, dst)

json.dump({"version": 1, "items": items}, open(os.path.join(out, "catalog.json"), "w"), indent=2)
print(f"{len(items)} items -> docs/catalog.json")
print(f"Set Store.CATALOG_URL = \"{base}/catalog.json\"")
