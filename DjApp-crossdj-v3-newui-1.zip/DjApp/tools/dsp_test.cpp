// Build and run on a PC:   g++ -O2 -std=c++17 -I../app/src/main/cpp dsp_test.cpp -o dsp_test && ./dsp_test
// Compares the OLD audio code (copied here unchanged) with the new dsp.h on the same signals.
#include <cstdio>
#include <cstdlib>
#include <vector>
#include "dsp.h"

static const double PI = 3.14159265358979323846;

// ---------------------------------------------------------------- OLD code, copied from the previous engine.cpp
inline float oldSoftClip(float x) {
    float a = fabsf(x);
    if (a <= 0.9f) return x;
    float y = 0.9f + 0.1f * tanhf((a - 0.9f) * 10.f);
    return x < 0 ? -y : y;
}
struct OldEq {
    struct Bq { float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1[2] = {0, 0}, z2[2] = {0, 0}; };
    Bq bq[3];
    float cur[3] = {0, 0, 0};
    float applied[3] = {1e9f, 1e9f, 1e9f};
    static void coefs(Bq &q, int band, float db, float sr) {
        const float A = powf(10.f, db / 40.f);
        const float f = band == 0 ? 110.f : band == 1 ? 1000.f : 5000.f;
        const float w0 = 2.f * 3.14159265f * f / sr, cs = cosf(w0), sn = sinf(w0);
        float b0, b1, b2, a0, a1, a2;
        if (band == 1) {
            const float al = sn / (2.f * 0.7f);
            b0 = 1 + al * A; b1 = -2 * cs; b2 = 1 - al * A; a0 = 1 + al / A; a1 = -2 * cs; a2 = 1 - al / A;
        } else {
            const float al = sn / 2.f * 1.41421356f, t = 2.f * sqrtf(A) * al;
            if (band == 0) {
                b0 = A * ((A + 1) - (A - 1) * cs + t); b1 = 2 * A * ((A - 1) - (A + 1) * cs); b2 = A * ((A + 1) - (A - 1) * cs - t);
                a0 = (A + 1) + (A - 1) * cs + t; a1 = -2 * ((A - 1) + (A + 1) * cs); a2 = (A + 1) + (A - 1) * cs - t;
            } else {
                b0 = A * ((A + 1) + (A - 1) * cs + t); b1 = -2 * A * ((A - 1) + (A + 1) * cs); b2 = A * ((A + 1) + (A - 1) * cs - t);
                a0 = (A + 1) - (A - 1) * cs + t; a1 = 2 * ((A - 1) - (A + 1) * cs); a2 = (A + 1) - (A - 1) * cs - t;
            }
        }
        q.b0 = b0 / a0; q.b1 = b1 / a0; q.b2 = b2 / a0; q.a1 = a1 / a0; q.a2 = a2 / a0;
    }
    void process(float *l, float *r, int m, const float target[3], float sr) {
        for (int b = 0; b < 3; b++) {
            cur[b] += (target[b] - cur[b]) * 0.35f;
            if (fabsf(target[b] - cur[b]) < 0.01f) cur[b] = target[b];
            if (fabsf(cur[b]) < 0.05f) { bq[b].z1[0] = bq[b].z1[1] = bq[b].z2[0] = bq[b].z2[1] = 0; applied[b] = 1e9f; continue; }
            if (fabsf(cur[b] - applied[b]) > 0.01f) { coefs(bq[b], b, cur[b], sr); applied[b] = cur[b]; }
            Bq &q = bq[b];
            for (int i = 0; i < m; i++) {
                float x = l[i], y = q.b0 * x + q.z1[0];
                q.z1[0] = q.b1 * x - q.a1 * y + q.z2[0]; q.z2[0] = q.b2 * x - q.a2 * y; l[i] = y;
                x = r[i]; y = q.b0 * x + q.z1[1];
                q.z1[1] = q.b1 * x - q.a1 * y + q.z2[1]; q.z2[1] = q.b2 * x - q.a2 * y; r[i] = y;
            }
        }
    }
};

// ---------------------------------------------------------------- helpers
static double ampAt(const std::vector<float> &x, int from, int to, double f, double fs) {   // amplitude of frequency f (correlation)
    double c = 0, s = 0; int n = to - from;
    for (int i = from; i < to; i++) { double w = 2 * PI * f * i / fs; c += x[i] * cos(w); s += x[i] * sin(w); }
    return 2.0 * sqrt(c * c + s * s) / n;
}
static double thdPct(const std::vector<float> &x, int from, int to, double f, double fs) {   // harmonic distortion in %
    double a1 = ampAt(x, from, to, f, fs), h = 0;
    for (int k = 2; k <= 12; k++) { double a = ampAt(x, from, to, f * k, fs); h += a * a; }
    return 100.0 * sqrt(h) / a1;
}
static double db(double x) { return 20 * log10(std::max(x, 1e-12)); }
static double peakOf(const std::vector<float> &x, int from = 0) { double p = 0; for (size_t i = from; i < x.size(); i++) p = std::max(p, (double)fabsf(x[i])); return p; }
static int fails = 0;
#define CHECK(cond, msg) do { if (!(cond)) { printf("   FAIL: %s\n", msg); fails++; } } while (0)

// ---------------------------------------------------------------- 1. interpolation
static void testInterpolation() {
    printf("\n[1] INTERPOLATION: playing a track at a fractional position (what every seek / tempo change / scratch does)\n");
    const double fs = 44100;
    for (double fq : {5000.0, 10000.0, 15000.0}) {
        std::vector<double> src(6000); for (int i = 0; i < 6000; i++) src[i] = sin(2 * PI * fq * i / fs);
        for (double frac : {0.25, 0.5}) {
            double rl = 0, rc = 0, ri = 0; int n = 0;
            for (int p = 100; p < 5000; p++) {
                float f = (float)frac;
                double lin = src[p] + (src[p + 1] - src[p]) * f;
                float w0, w1, w2, w3; dsp::cubicW(f, w0, w1, w2, w3);
                double cub = w0 * src[p - 1] + w1 * src[p] + w2 * src[p + 1] + w3 * src[p + 2];
                double ideal = sin(2 * PI * fq * (p + frac) / fs);
                rl += (lin - ideal) * (lin - ideal); rc += (cub - ideal) * (cub - ideal); ri += ideal * ideal; n++;
            }
            printf("   %5.0f Hz at offset %.2f: linear error %6.1f dB   cubic error %6.1f dB   (lower is better)\n", fq, frac, db(sqrt(rl / ri)), db(sqrt(rc / ri)));
            if (fq == 10000.0 && frac == 0.5) CHECK(rc < rl * 0.35, "cubic must be clearly more accurate than linear at 10 kHz");
        }
    }
    // 44.1 kHz file on a 48 kHz output, a 10 kHz hi-hat plus 1 kHz tone
    { const double fsrc = 44100, fout = 48000, step = fsrc / fout;
      std::vector<double> src(60000); for (int i = 0; i < 60000; i++) src[i] = 0.5 * sin(2 * PI * 1000 * i / fsrc) + 0.5 * sin(2 * PI * 10000 * i / fsrc);
      double el = 0, ec = 0, ei = 0;
      for (int i = 100; i < 50000; i++) {
          double pos = i * step; int p = (int)pos; float f = (float)(pos - p);
          double lin = src[p] + (src[p + 1] - src[p]) * f;
          float w0, w1, w2, w3; dsp::cubicW(f, w0, w1, w2, w3);
          double cub = w0 * src[p - 1] + w1 * src[p] + w2 * src[p + 1] + w3 * src[p + 2];
          double ideal = 0.5 * sin(2 * PI * 1000 * pos / fsrc) + 0.5 * sin(2 * PI * 10000 * pos / fsrc);
          el += (lin - ideal) * (lin - ideal); ec += (cub - ideal) * (cub - ideal); ei += ideal * ideal;
      }
      printf("   44.1k file on 48k output, 1k+10k tones: linear error %.1f dB, cubic error %.1f dB\n", db(sqrt(el / ei)), db(sqrt(ec / ei)));
      CHECK(ec < el * 0.3, "cubic must beat linear on a 44.1k -> 48k conversion"); }
}

// ---------------------------------------------------------------- 2. limiter vs old soft clip
static std::vector<float> runLimiter(const std::vector<float> &in, float sr, dsp::Limiter &lim) {
    lim.init(sr);
    std::vector<float> io(in.size() * 2), out(in.size());
    for (size_t i = 0; i < in.size(); i++) io[2 * i] = io[2 * i + 1] = in[i];
    for (size_t i = 0; i < in.size(); i += 256) lim.process(&io[2 * i], (int)std::min<size_t>(256, in.size() - i));
    for (size_t i = 0; i < in.size(); i++) out[i] = io[2 * i];
    return out;
}
static void testLimiter() {
    printf("\n[2] MASTER LIMITER vs the old soft clip (50 Hz bass note, too loud)\n");
    const float sr = 48000; const int N = 48000;
    for (double amp : {1.2, 2.0, 4.0}) {
        std::vector<float> in(N), oldOut(N);
        for (int i = 0; i < N; i++) { in[i] = (float)(amp * sin(2 * PI * 50 * i / sr)); oldOut[i] = oldSoftClip(in[i]); }
        dsp::Limiter lim; auto nw = runLimiter(in, sr, lim);
        double thdOld = thdPct(oldOut, 24000, 48000, 50, sr), thdNew = thdPct(nw, 24000, 48000, 50, sr);
        printf("   bass at %.1fx full scale: OLD distortion %5.1f %%  peak %.3f   |   NEW distortion %5.2f %%  peak %.3f\n", amp, thdOld, peakOf(oldOut), thdNew, peakOf(nw));
        CHECK(peakOf(nw) <= 0.9501, "limiter must never exceed its ceiling");
        CHECK(thdNew < thdOld * 0.25, "limiter must distort far less than the old clip");
    }
    // violent random material and a sudden burst: the ceiling must hold on every single sample
    { std::vector<float> in(N); srand(1);
      for (int i = 0; i < N; i++) { float r = ((rand() % 20001) - 10000) / 10000.f; in[i] = r * ((i / 4800) % 2 ? 5.f : 0.3f); }
      dsp::Limiter lim; auto o = runLimiter(in, sr, lim);
      printf("   random bursts up to 5x full scale: output peak %.4f (ceiling 0.95)\n", peakOf(o)); CHECK(peakOf(o) <= 0.9501, "ceiling must hold on bursts"); }
    // quiet music must pass untouched (only delayed by 47 samples)
    { std::vector<float> in(N); for (int i = 0; i < N; i++) in[i] = (float)(0.5 * sin(2 * PI * 440 * i / sr));
      dsp::Limiter lim; auto o = runLimiter(in, sr, lim); double maxd = 0;
      for (int i = 100; i < N; i++) maxd = std::max(maxd, (double)fabsf(o[i] - in[i - (lim.L - 1)]));
      printf("   quiet signal passes unchanged: max difference %.2e\n", maxd); CHECK(maxd < 1e-6, "quiet audio must pass through untouched"); }
}

// ---------------------------------------------------------------- 3. bass boost through the whole chain
static void testBassBoost() {
    printf("\n[3] BASS BOOST +12 dB through the whole chain (old: EQ -> soft clip   new: EQ with headroom -> limiter)\n");
    const float sr = 48000; const int N = 48128;      // a whole number of 256-sample blocks
    auto chainOld = [&](std::vector<float> x, float boost) {
        OldEq eq; const float tg[3] = {boost, 0, 0}; std::vector<float> r = x;
        for (int i = 0; i < N; i += 256) eq.process(&x[i], &r[i], 256, tg, sr);
        for (auto &v : x) v = oldSoftClip(v); return x; };
    auto chainNew = [&](std::vector<float> x, float boost) {
        dsp::Eq eq; const float tg[3] = {boost, 0, 0}; std::vector<float> r = x;
        for (int i = 0; i < N; i += 256) eq.process(&x[i], &r[i], 256, tg, sr);
        dsp::Limiter lim; return runLimiter(x, sr, lim); };
    // (a) a plain 50 Hz bass note at a normal level
    { std::vector<float> in(N); for (int i = 0; i < N; i++) in[i] = (float)(0.6 * sin(2 * PI * 50 * i / sr));
      auto o = chainOld(in, 12), n = chainNew(in, 12);
      printf("   50 Hz note at 0.6, bass +12 dB: OLD distortion %5.1f %%   NEW distortion %5.2f %%   (new loudness of the note: %.1f dB vs old %.1f dB)\n",
             thdPct(o, 24000, 48000, 50, sr), thdPct(n, 24000, 48000, 50, sr), db(ampAt(n, 24000, 48000, 50, sr)), db(ampAt(o, 24000, 48000, 50, sr)));
      CHECK(thdPct(n, 24000, 48000, 50, sr) < 3.0, "boosted bass must stay clean (<3% distortion)"); }
    // (b) a loud modern-style loop: kick (55 Hz thump) + bass line + hats, peaking at 0.9
    { std::vector<float> in(N, 0.f); srand(7);
      for (int i = 0; i < N; i++) {
          double t = i / sr, beat = fmod(t, 0.5), env = exp(-beat * 18);
          double kick = sin(2 * PI * (45 + 90 * exp(-beat * 30)) * beat) * env;
          double bass = 0.4 * sin(2 * PI * 55 * t) * (0.6 + 0.4 * sin(2 * PI * 2 * t));
          double hat = 0.08 * (((rand() % 2001) - 1000) / 1000.0) * exp(-fmod(t, 0.25) * 40);
          in[i] = (float)(0.7 * kick + bass + hat);
      }
      double p = peakOf(in); for (auto &v : in) v = (float)(v * 0.9 / p);
      auto o = chainOld(in, 12), n = chainNew(in, 12);
      int co = 0, cn = 0; for (int i = 0; i < N; i++) { if (fabsf(o[i]) > 0.89f) co++; if (fabsf(n[i]) > 0.945f) cn++; }
      printf("   loud kick+bass loop (peak 0.9), bass +12 dB: samples squashed against the ceiling  OLD %d   NEW %d   | peak OLD %.3f NEW %.3f\n", co, cn, peakOf(o), peakOf(n));
      CHECK(peakOf(n) <= 0.9501, "new chain must stay under the ceiling"); }
    // (c) does float vs double matter for the EQ itself? (a quiet 1 kHz tone through a +12 dB 110 Hz shelf, compare with a double reference)
    { std::vector<float> a(N), b(N); for (int i = 0; i < N; i++) a[i] = b[i] = (float)(0.01 * sin(2 * PI * 1000 * i / sr));
      OldEq oe; dsp::Eq ne; ne.headroom = 0.f; const float tg[3] = {12, 0, 0}; std::vector<float> ra = a, rb = b;
      for (int i = 0; i < N; i += 256) { oe.process(&a[i], &ra[i], 256, tg, sr); ne.process(&b[i], &rb[i], 256, tg, sr); }
      double diff = 0, ref = 0; for (int i = 8000; i < N; i++) { diff += (a[i] - b[i]) * (a[i] - b[i]); ref += b[i] * b[i]; }
      printf("   float-vs-double EQ difference on a quiet tone: %.1f dB below the signal (below -90 dB would be inaudible)\n", db(sqrt(diff / ref))); }
}

// ---------------------------------------------------------------- 4. clicks when the playhead jumps
static void testDeclick() {
    printf("\n[4] CLICKS when you seek / jump (a 100 Hz bass tone, the playhead jumps to a different phase)\n");
    const float sr = 48000; const int N = 4096, J = 2000;
    std::vector<float> raw(N), fixed;
    for (int i = 0; i < N; i++) raw[i] = (float)(0.8 * sin(2 * PI * 100 * (i < J ? i : i + 137) / sr));
    fixed = raw;
    dsp::Declick dc;
    for (int i = 0; i < N; i += 256) {
        if (i == 1792) dc.trigger();                           // the seek request lands at the start of the chunk
        std::vector<float> r(256); for (int k = 0; k < 256; k++) r[k] = raw[i + k];
        // chunk 1792..2047 contains the jump at 2000, so build the "new position" chunk from the jump on
        if (i == 1792) { for (int k = 0; k < 256; k++) r[k] = (float)(0.8 * sin(2 * PI * 100 * (i + k + 137) / sr)); }
        std::vector<float> l = r; dc.process(&l[0], &r[0], 256);
        for (int k = 0; k < 256; k++) fixed[i + k] = l[k];
    }
    auto hf = [&](const std::vector<float> &x, int a, int b) { double e = 0; for (int i = a + 2; i < b; i++) { double d = x[i] - 2 * x[i - 1] + x[i - 2]; e += d * d; } return e; };
    double stepRaw = 0, stepFix = 0;
    for (int i = 1780; i < 2200; i++) { stepRaw = std::max(stepRaw, (double)fabsf(raw[i] - raw[i - 1])); stepFix = std::max(stepFix, (double)fabsf(fixed[i] - fixed[i - 1])); }
    printf("   (the test jumps at the START of a 256-sample block, like the engine does)\n");
    // compare against a pure jump at the block start
    std::vector<float> jump(N); for (int i = 0; i < N; i++) jump[i] = (float)(0.8 * sin(2 * PI * 100 * (i < 1792 ? i : i + 137) / sr));
    double stepJ = 0; for (int i = 1780; i < 2200; i++) stepJ = std::max(stepJ, (double)fabsf(jump[i] - jump[i - 1]));
    double eJ = hf(jump, 1780, 2300), eF = hf(fixed, 1780, 2300);
    printf("   biggest sample-to-sample step: without smoothing %.3f   with smoothing %.3f   (a pure 100 Hz tone steps at most 0.013)\n", stepJ, stepFix);
    printf("   click energy (2nd difference): without %.4f   with %.6f   -> %.0fx quieter click\n", eJ, eF, eJ / std::max(eF, 1e-12));
    CHECK(eF < eJ * 0.05, "click energy must drop by at least 20x");
}

int main() {
    testInterpolation(); testLimiter(); testBassBoost(); testDeclick();
    printf("\n%s (%d failed checks)\n", fails ? "SOME CHECKS FAILED" : "ALL CHECKS PASSED", fails);
    return fails ? 1 : 0;
}
