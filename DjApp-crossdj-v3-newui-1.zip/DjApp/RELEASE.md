# Releasing MAXIDO DJ

## One-time setup (about 15 minutes)
1. **Permanent signing key.** Install Java once: `winget install EclipseAdoptium.Temurin.17.JDK`. Close and reopen the window, then
   double-click `release\make-keystore.bat`. It makes `maxido-release.jks` (BACK IT UP, never lose it) and `GITHUB-SECRETS.txt`.
2. **Give GitHub the key.** Repo > Settings > Secrets and variables > Actions > New repository secret. Make 4 secrets named
   `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD` with the values from `GITHUB-SECRETS.txt`. Then delete that file.
3. **Workflow.** Put `build.yml` from this project into your repo at `.github/workflows/build.yml` (replace the old one) and upload the
   newest `DjApp...zip` to the repo root as before.

## Every release
Actions > Build APK > Run workflow > tick **publish** > Run. When it is green, Releases (right side of the repo page) has the APK.
Share `https://github.com/<you>/<repo>/releases/latest`. The repo must be public for strangers to download it.
Customers update by installing the next APK over the old one (same signing key).

## Before customers pay you (go through every line)
- [ ] The billing server is running whenever customers might buy (a PC that is off cannot unlock anyone).
- [ ] The server uses your **LIVE** Paystack key and `ALLOW_TEST_PAYMENTS` is removed from `.env` (the server refuses to start on test keys without it).
- [ ] Paystack has approved your account for live payments and you tried one real KSh 150 payment yourself and saw PRO turn on.
- [ ] `Billing.kt` has the server address and the public key that match the server's `keys` folder (rebuild after changing either).
- [ ] The signing key is backed up in two places; the server's `keys` folder and `data` folder too.
- [ ] You have installed the signed build on a phone and a second build over it (checks that updating works).
