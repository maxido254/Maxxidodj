@echo off
title Make the permanent app signing key
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Get the LTS version from https://nodejs.org then run this again. & pause & exit /b 1)
node make-keystore.js
echo.
pause
