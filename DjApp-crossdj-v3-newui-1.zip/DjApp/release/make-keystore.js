'use strict';
// Makes your PERMANENT app-signing key and the four values GitHub needs. Run once. NEVER lose or share the .jks file.
const { execFileSync } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

function candidates() {
  const exe = process.platform === 'win32' ? 'keytool.exe' : 'keytool';
  const list = [];
  if (process.env.JAVA_HOME) list.push(path.join(process.env.JAVA_HOME, 'bin', exe));
  list.push('keytool');
  if (process.platform === 'win32') {
    list.push('C:\\Program Files\\Android\\Android Studio\\jbr\\bin\\keytool.exe');
    for (const base of ['C:\\Program Files\\Eclipse Adoptium', 'C:\\Program Files\\Java', 'C:\\Program Files\\Microsoft']) {
      try { for (const d of fs.readdirSync(base)) list.push(path.join(base, d, 'bin', 'keytool.exe')); } catch { /* folder not there */ }
    }
  }
  return list;
}
function findKeytool() {
  for (const c of candidates()) { try { execFileSync(c, ['-help'], { stdio: 'ignore' }); return c; } catch { /* try next */ } }
  return null;
}

const kt = findKeytool();
if (!kt) {
  console.log('Java is not installed, so the key cannot be made yet.\nInstall it (one command), close this window, then run this again:\n\n  winget install EclipseAdoptium.Temurin.17.JDK\n');
  process.exit(1);
}
const jks = path.join(__dirname, 'maxido-release.jks');
if (fs.existsSync(jks)) { console.log('A key already exists here (maxido-release.jks). Not touching it: replacing it would stop every customer from updating.'); process.exit(1); }

const pw = crypto.randomBytes(18).toString('base64url');
execFileSync(kt, ['-genkeypair', '-keystore', jks, '-alias', 'maxido', '-keyalg', 'RSA', '-keysize', '2048', '-validity', '10000',
  '-storepass', pw, '-keypass', pw, '-dname', 'CN=Maxido Entertainment, O=Maxido, C=KE'], { stdio: 'ignore' });
fs.writeFileSync(path.join(__dirname, 'GITHUB-SECRETS.txt'),
  `Add these 4 as "Repository secrets" in GitHub (Settings > Secrets and variables > Actions > New repository secret).\n` +
  `Name on the first line, value on the next.\n\nKEYSTORE_BASE64\n${fs.readFileSync(jks).toString('base64')}\n\nKEYSTORE_PASSWORD\n${pw}\n\nKEY_ALIAS\nmaxido\n\nKEY_PASSWORD\n${pw}\n`);
console.log('\nDone. Two files were created in this folder:\n  maxido-release.jks     your permanent signing key: BACK IT UP (USB stick + a second place). If lost, no customer can ever update.\n  GITHUB-SECRETS.txt     the 4 values to paste into GitHub. Delete it afterwards.\nNever upload either file to GitHub or send them to anyone.\n');
