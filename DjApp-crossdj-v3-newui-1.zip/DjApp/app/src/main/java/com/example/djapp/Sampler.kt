package com.example.djapp

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File

/**
 * Sampler: 2 banks x 8 pads. It plays the built-in free samples (res/raw) or a sampler pack the user downloaded from the Store
 * (files/packs/<id>/). Samples are decoded (max 30 s) into the cache and memory-mapped by the engine.
 */
object Sampler {
    const val BANKS = 2
    const val PER_BANK = 8

    class Pad {
        var name by mutableStateOf("")
        var loaded by mutableStateOf(false)
        var playing by mutableStateOf(false)
        var file: File? = null
    }

    val pads = List(BANKS * PER_BANK) { Pad() }
    var bank by mutableIntStateOf(0)
    /** "" = the built-in samples, otherwise the id of the installed pack that is on the pads. */
    var activePack by mutableStateOf("")
    @Volatile private var generation = 0

    private lateinit var app: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var started = false

    /** The samples that ship inside the app (res/raw), in pad order. */
    private val FREE = listOf(
        "Glass Break" to "glass_break", "Pull Up" to "pull_up", "Dangerous DJ" to "dangerous_dj",
        "Your Sister Is Dating Him" to "your_sister_is_dating_him", "Ashindwe" to "ashindwe", "Fever DJ" to "fever_dj",
        "Now Hear This" to "now_hear_this", "Wolande" to "wolande", "Faya Faya" to "faya_faya", "Best DJ In The City" to "best_dj_in_the_city"
    )

    fun init(ctx: Context) {
        if (started) return
        started = true
        app = ctx.applicationContext
        val saved = app.getSharedPreferences("djstore", Context.MODE_PRIVATE).getString("pack", "") ?: ""
        if (saved.isNotEmpty() && File(Store.packsDir, saved).isDirectory) usePack(saved) else useBuiltIn()
    }

    /** Puts the built-in free samples on the pads. */
    fun useBuiltIn() {
        activePack = ""; savePack("")
        val gen = ++generation
        resetPads()
        // Pad names show immediately; audio is decoded in the background.
        FREE.forEachIndexed { i, (n, _) -> if (i < pads.size) pads[i].name = n }
        scope.launch {
            FREE.forEachIndexed { i, (n, r) ->
                if (gen == generation && i < pads.size) loadPad(i, Uri.parse("android.resource://${app.packageName}/raw/$r"), n)
            }
        }
    }

    /** Puts a downloaded sampler pack on the pads. A pack folder holds audio files and an optional pack.json with the pad names. */
    fun usePack(id: String) {
        val dir = File(Store.packsDir, id)
        if (!dir.isDirectory) { useBuiltIn(); return }
        val entries = packEntries(dir)
        if (entries.isEmpty()) { useBuiltIn(); return }
        activePack = id; savePack(id)
        val gen = ++generation
        resetPads()
        entries.forEachIndexed { i, (n, _) -> pads[i].name = n }
        scope.launch {
            entries.forEachIndexed { i, (n, f) -> if (gen == generation) loadPad(i, Uri.fromFile(f), n) }
        }
    }

    private fun packEntries(dir: File): List<Pair<String, File>> {
        val out = ArrayList<Pair<String, File>>()
        try {
            val arr = JSONObject(File(dir, "pack.json").readText()).getJSONArray("pads")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val f = File(dir, o.getString("file").substringAfterLast('/'))
                if (f.isFile) out += o.optString("name", f.nameWithoutExtension) to f
            }
        } catch (_: Exception) { }
        if (out.isEmpty()) {          // no / broken pack.json: use the audio files in alphabetical order
            dir.listFiles { f -> f.isFile && f.name != "pack.json" }?.sortedBy { it.name }?.forEach { out += it.nameWithoutExtension to it }
        }
        return out.take(pads.size)
    }

    private fun resetPads() {
        stopAll()
        for (i in pads.indices) {
            NativeEngine.clearSample(i)
            val p = pads[i]
            p.file?.delete(); p.file = null
            p.loaded = false; p.playing = false; p.name = ""
        }
    }

    private fun savePack(pack: String) {
        app.getSharedPreferences("djstore", Context.MODE_PRIVATE).edit().putString("pack", pack).apply()
    }

    // ------------------------------------------------------------------ pads
    private fun loadPad(slot: Int, uri: Uri, name: String) {
        val p = pads[slot]
        val f = File(app.cacheDir, "smp${slot}_${System.nanoTime()}.pcm")
        try {
            val rate = Decoder.decode(app, uri, f, 0.0, 30.0)
            if (NativeEngine.loadSample(slot, f.absolutePath, rate)) {
                p.file?.delete(); p.file = f
                p.name = name; p.loaded = true; p.playing = false
            } else { f.delete() }
        } catch (_: Exception) { f.delete() }
    }

    // ------------------------------------------------------------------ playing
    fun down(slot: Int) {
        val p = pads[slot]
        if (!p.loaded) return
        if (AppSettings.padMode == 2) {
            if (p.playing) { NativeEngine.stopSample(slot); p.playing = false }
            else { NativeEngine.triggerSample(slot, true); p.playing = true }
        } else { NativeEngine.triggerSample(slot, false); p.playing = true }
    }

    fun up(slot: Int) {
        if (AppSettings.padMode == 1 && pads[slot].loaded) NativeEngine.stopSample(slot)
    }

    fun stopAll() { for (i in pads.indices) if (pads[i].loaded) { NativeEngine.stopSample(i); pads[i].playing = false } }

    fun poll() {
        for (i in pads.indices) {
            val p = pads[i]
            if (!p.loaded) continue
            val pl = NativeEngine.isSamplePlaying(i)
            if (p.playing != pl) p.playing = pl
        }
    }
}
