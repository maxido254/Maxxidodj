package com.example.djapp

import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Binder
import android.os.IBinder
import android.os.Process
import java.io.File

/**
 * Runs the AI (HT-Demucs) separation in a separate process (":sep"). The main app talks to it only through small
 * files in a control folder: progress / pause / cancel in, done / fail out. If this process is killed because the
 * phone ran out of memory, the DJ app is unaffected.
 */
class SepService : Service() {
    override fun onBind(intent: Intent?): IBinder? {
        val mix = intent?.getStringExtra("mix"); val out = intent?.getStringExtra("out"); val ctlPath = intent?.getStringExtra("ctl")
        val rate = intent?.getIntExtra("rate", 44100) ?: 44100
        if (mix == null || out == null || ctlPath == null) return null
        val ctl = File(ctlPath)
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            var last = -1f
            val ok = try {
                DemucsSeparator(applicationContext, lowMem = true).separate(File(mix), rate, File(out), { p ->
                    if (p - last >= 0.005f || p >= 1f) { last = p; try { File(ctl, "progress").writeText("$p") } catch (_: Exception) {} }
                }, {
                    while (File(ctl, "pause").exists() && !File(ctl, "cancel").exists()) Thread.sleep(300)
                    File(ctl, "cancel").exists()
                })
            } catch (_: Throwable) { false }
            try { File(ctl, if (ok) "done" else "fail").writeText("1") } catch (_: Exception) {}
        }.start()
        return Binder()
    }
}

/**
 * AI separation (HT-Demucs) executed in the ":sep" process. Used both for live stems (strong phones) and for
 * prepared tracks (weak phones). If that process dies (out of memory) this simply returns false.
 * [pauseWhen] holds the job while it is true (e.g. a deck is playing during background preparing).
 */
class AiSeparator(
    private val ctx: Context,
    private val pauseWhen: () -> Boolean = { false },
    private val onPaused: (Boolean) -> Unit = {}
) : StemSeparator {
    override val id = "demucs"

    override fun separate(mix: File, rate: Int, outDir: File, progress: (Float) -> Unit, cancelled: () -> Boolean): Boolean {
        val app = ctx.applicationContext
        val ctl = File(app.cacheDir, "sepctl_${System.nanoTime()}").also { it.mkdirs() }
        val dead = java.util.concurrent.atomic.AtomicBoolean(false)
        val conn = object : ServiceConnection {
            override fun onServiceConnected(n: ComponentName?, b: android.os.IBinder?) {}
            override fun onServiceDisconnected(n: ComponentName?) { dead.set(true) }
        }
        val intent = Intent(app, SepService::class.java).apply {
            action = "job" + System.nanoTime()      // a distinct action makes every job its own bind (own onBind call)
            putExtra("mix", mix.absolutePath); putExtra("out", outDir.absolutePath)
            putExtra("rate", rate); putExtra("ctl", ctl.absolutePath)
        }
        if (!app.bindService(intent, conn, Context.BIND_AUTO_CREATE)) { ctl.deleteRecursively(); return false }
        try {
            while (true) {
                if (File(ctl, "done").exists()) return true
                if (File(ctl, "fail").exists() || dead.get()) return false
                if (cancelled()) {
                    File(ctl, "cancel").writeText("1")
                    var w = 0
                    while (w++ < 20 && !File(ctl, "done").exists() && !File(ctl, "fail").exists() && !dead.get()) Thread.sleep(250)
                    return false
                }
                val pausing = pauseWhen()
                onPaused(pausing)
                val pf = File(ctl, "pause")
                if (pausing) { if (!pf.exists()) pf.writeText("1") } else pf.delete()
                try { progress(File(ctl, "progress").readText().trim().toFloat()) } catch (_: Exception) {}
                Thread.sleep(300)
            }
        } finally {
            onPaused(false)
            try { app.unbindService(conn) } catch (_: Exception) {}
            ctl.deleteRecursively()
        }
    }
}
