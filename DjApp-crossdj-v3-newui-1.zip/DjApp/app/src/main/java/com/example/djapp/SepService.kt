package com.example.djapp

import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Binder
import android.os.IBinder
import android.os.Process
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/** What the AI process is doing right now (shown next to the PREP progress), so a stall can be diagnosed from a screenshot. */
object AiStatus {
    var text by mutableStateOf("")
}

/**
 * Runs the AI (SCNet) separation in a separate process (":sep"). The main app talks to it only through small
 * files in a control folder: progress / pause / cancel in, done / fail out. If this process is killed because the
 * phone ran out of memory, the DJ app is unaffected.
 */
class SepService : Service() {
    override fun onBind(intent: Intent?): IBinder? {
        val mix = intent?.getStringExtra("mix"); val out = intent?.getStringExtra("out"); val ctlPath = intent?.getStringExtra("ctl")
        val rate = intent?.getIntExtra("rate", 44100) ?: 44100
        val ovl = intent?.getIntExtra("ovl", 4) ?: 4
        val prof = intent?.getIntExtra("prof", 0) ?: 0
        if (mix == null || out == null || ctlPath == null) return null
        val ctl = File(ctlPath)
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            var last = -1f
            val ok = try {
                ScnetSeparator(applicationContext, lowMem = true, overlapDiv = ovl, minimal = prof >= 1, status = { s -> try { File(ctl, "status").writeText(s) } catch (_: Exception) {} }).separate(File(mix), rate, File(out), { p ->
                    if (p - last >= 0.005f || p >= 1f) { last = p; try { File(ctl, "progress").writeText("$p") } catch (_: Exception) {} }
                }, {
                    while (File(ctl, "pause").exists() && !File(ctl, "cancel").exists()) Thread.sleep(300)
                    File(ctl, "cancel").exists()
                })
            } catch (t: Throwable) { try { File(ctl, "status").writeText("ERROR " + t.javaClass.simpleName + ": " + (t.message ?: "").take(160)) } catch (_: Exception) {}; false }
            try { File(ctl, if (ok) "done" else "fail").writeText("1") } catch (_: Exception) {}
        }.start()
        return Binder()
    }
}

/**
 * AI separation (SCNet) executed in the ":sep" process. Used both for live stems (strong phones) and for
 * prepared tracks (weak phones). If that process dies (out of memory) this simply returns false.
 * [pauseWhen] holds the job while it is true (e.g. a deck is playing during background preparing).
 */
class AiSeparator(
    private val ctx: Context,
    private val pauseWhen: () -> Boolean = { false },
    private val onPaused: (Boolean) -> Unit = {},
    private val overlapDiv: Int = 4,
    private val persistent: Boolean = false      // true for prepared tracks: if the AI process dies, retry with less memory
) : StemSeparator {
    override val id = "scnet"

    override fun separate(mix: File, rate: Int, outDir: File, progress: (Float) -> Unit, cancelled: () -> Boolean): Boolean {
        if (runOnce(mix, rate, outDir, progress, cancelled, 0)) return true
        if (!persistent) return false
        // Attempts 2 and 3: minimal profile (1 thread, light graph). Slower, but it fits on weak phones.
        for (attempt in 1..2) {
            if (cancelled()) return false
            try { Thread.sleep(3000) } catch (_: InterruptedException) {}      // let the dead process go away fully
            outDir.listFiles()?.forEach { it.delete() }
            if (runOnce(mix, rate, outDir, progress, cancelled, 1)) return true
        }
        return false
    }

    private fun runOnce(mix: File, rate: Int, outDir: File, progress: (Float) -> Unit, cancelled: () -> Boolean, profile: Int): Boolean {
        val app = ctx.applicationContext
        val ctl = File(app.cacheDir, "sepctl_${System.nanoTime()}").also { it.mkdirs() }
        val dead = java.util.concurrent.atomic.AtomicBoolean(false)
        val conn = object : ServiceConnection {
            override fun onServiceConnected(n: ComponentName?, b: android.os.IBinder?) {}
            override fun onServiceDisconnected(n: ComponentName?) { dead.set(true) }
        }
        val intent = Intent(app, SepService::class.java).apply {
            action = "job" + System.nanoTime()      // a distinct action makes every job its own bind (own onBind call)
            putExtra("mix", mix.absolutePath); putExtra("out", outDir.absolutePath)
            putExtra("rate", rate); putExtra("ctl", ctl.absolutePath); putExtra("ovl", overlapDiv); putExtra("prof", profile)
        }
        if (!app.bindService(intent, conn, Context.BIND_AUTO_CREATE)) { ctl.deleteRecursively(); return false }
        try {
            while (true) {
                if (File(ctl, "done").exists()) return true
                if (File(ctl, "fail").exists()) return false
                if (dead.get()) { AiStatus.text = "AI process was KILLED by Android (out of memory) - try " + (profile + 1); return false }
                if (cancelled()) {
                    File(ctl, "cancel").writeText("1")
                    var w = 0
                    while (w++ < 20 && !File(ctl, "done").exists() && !File(ctl, "fail").exists() && !dead.get()) Thread.sleep(250)
                    return false
                }
                val pausing = pauseWhen()
                onPaused(pausing)
                val pf = File(ctl, "pause")
                if (pausing) { if (!pf.exists()) pf.writeText("1") } else pf.delete()
                try { progress(File(ctl, "progress").readText().trim().toFloat()) } catch (_: Exception) {}
                try { AiStatus.text = File(ctl, "status").readText().take(200) } catch (_: Exception) {}
                Thread.sleep(300)
            }
        } finally {
            onPaused(false)
            try { app.unbindService(conn) } catch (_: Exception) {}
            ctl.deleteRecursively()
        }
    }
}

/**
 * "AI MAX": the neural network runs several times on the same song, each time with the start moved by a different
 * amount, so the model's segment borders fall in different places. The results are lined up again and averaged,
 * which cancels most of the leftovers and joins artefacts that a single pass leaves (the "shifts" idea from Demucs).
 * Very slow (passes x the time of one AI pass), but it is meant to run once, ahead of time.
 * If a later pass fails (e.g. out of memory), the passes already finished are kept.
 */
class ShiftedAiSeparator(
    private val ctx: Context,
    private val passes: Int,
    private val overlapDiv: Int,
    private val pauseWhen: () -> Boolean = { false },
    private val onPaused: (Boolean) -> Unit = {}
) : StemSeparator {
    override val id = "scnet-max"

    override fun separate(mix: File, rate: Int, outDir: File, progress: (Float) -> Unit, cancelled: () -> Boolean): Boolean {
        for (k in 0 until passes) {
            val shift = k * (rate * 5.5 / passes).toLong()     // spread evenly over one segment stride (~5.5 s at overlap 1/2 of an 11 s segment)
            val src = if (k == 0) mix else File(mix.path + ".s$k").also { writeShifted(mix, it, shift) }
            val dir = if (k == 0) outDir else File(outDir.path + ".pass").also { it.deleteRecursively(); it.mkdirs() }
            val ok = try {
                AiSeparator(ctx, pauseWhen, onPaused, overlapDiv, persistent = true)
                    .separate(src, rate, dir, { p -> progress((k + p.coerceIn(0f, 1f)) / passes) }, cancelled)
            } finally { if (k > 0) src.delete() }
            if (k == 0) { if (!ok) return false; continue }
            if (!ok) { dir.deleteRecursively(); return !cancelled() }       // keep the finished passes
            try { for (n in STEM_NAMES) blend(File(outDir, "$n.pcm"), File(dir, "$n.pcm"), shift, k) }
            finally { dir.deleteRecursively() }
        }
        return true
    }

    private fun writeShifted(mix: File, out: File, shiftFrames: Long) {
        java.io.BufferedOutputStream(out.outputStream(), 256 * 1024).use { o ->
            val z = ByteArray(64 * 1024); var left = shiftFrames * 4
            while (left > 0) { val n = minOf(z.size.toLong(), left).toInt(); o.write(z, 0, n); left -= n }
            mix.inputStream().use { it.copyTo(o, 256 * 1024) }
        }
    }

    /** acc = (acc * done + add shifted back) / (done + 1), sample by sample. */
    private fun blend(acc: File, add: File, shift: Long, done: Int) {
        val tmp = File(acc.path + ".tmp")
        val total = acc.length() / 4
        val addFrames = add.length() / 4
        java.io.RandomAccessFile(acc, "r").use { a ->
            java.io.RandomAccessFile(add, "r").use { b ->
                java.io.BufferedOutputStream(tmp.outputStream(), 256 * 1024).use { o ->
                    val frames = 16384
                    val ab = ByteArray(frames * 4); val bb = ByteArray(frames * 4); val ob = ByteArray(frames * 4)
                    var pos = 0L
                    while (pos < total) {
                        val n = minOf(frames.toLong(), total - pos).toInt()
                        a.seek(pos * 4); a.readFully(ab, 0, n * 4)
                        java.util.Arrays.fill(bb, 0, n * 4, 0)
                        val src = pos + shift
                        if (src < addFrames) { val m = minOf(n.toLong(), addFrames - src).toInt(); b.seek(src * 4); b.readFully(bb, 0, m * 4) }
                        val sa = java.nio.ByteBuffer.wrap(ab, 0, n * 4).order(java.nio.ByteOrder.nativeOrder()).asShortBuffer()
                        val sb = java.nio.ByteBuffer.wrap(bb, 0, n * 4).order(java.nio.ByteOrder.nativeOrder()).asShortBuffer()
                        val so = java.nio.ByteBuffer.wrap(ob, 0, n * 4).order(java.nio.ByteOrder.nativeOrder()).asShortBuffer()
                        for (i in 0 until n * 2) {
                            val v = Math.round((sa.get(i).toFloat() * done + sb.get(i).toFloat()) / (done + 1))
                            so.put(i, v.coerceIn(-32768, 32767).toShort())
                        }
                        o.write(ob, 0, n * 4)
                        pos += n
                    }
                }
            }
        }
        acc.delete(); tmp.renameTo(acc)
    }
}
