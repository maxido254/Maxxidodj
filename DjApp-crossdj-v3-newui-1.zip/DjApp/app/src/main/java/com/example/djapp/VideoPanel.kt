package com.example.djapp

import android.graphics.SurfaceTexture
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.TextureView
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/** The mixed picture: layer A underneath, layer B on top, opacity from [VideoMixer.alphas]. */
@Composable
fun VideoOutput(modifier: Modifier) {
    val (aA, aB) = VideoMixer.alphas()
    Box(modifier.background(Color.Black), contentAlignment = Alignment.Center) {
        // A layer that is not loaded, or fully faded out, gets no surface at all: no compositing, no decoding.
        // A is also skipped while B fully covers it (nothing of A can be seen, so it needs no surface).
        val bCovers = VideoMixer.layers[1].ready && aB > 0.99f
        if (VideoMixer.layers[0].ready && aA > 0.01f && !bCovers) VideoSurface(VideoMixer.layers[0], aA)
        if (VideoMixer.layers[1].ready && aB > 0.01f) VideoSurface(VideoMixer.layers[1], aB)
        val dark = 1f - AppSettings.videoBright
        if (dark > 0.01f) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dark)))
        // app name, top right of the picture (also in the floating window and fullscreen)
        Row(Modifier.align(Alignment.TopEnd).padding(6.dp)) {
            Text("MAXIDO", color = Color.White.copy(alpha = 0.85f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, maxLines = 1)
            Text(" DJ", color = DeckA.copy(alpha = 0.9f), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
private fun VideoSurface(layer: VideoLayer, alpha: Float) {
    val owner = remember { Any() }
    // One picture at full strength (the normal case): a SurfaceView. The video goes straight to the screen compositor,
    // so it keeps its own pace even when the app's UI thread is busy drawing waveforms and platters, and it needs no
    // GPU copy. Only while two pictures are really being blended (alpha in between) a TextureView is needed.
    if (alpha >= 0.99f && AppSettings.videoOverlay) {
        AndroidView(
            factory = { c ->
                SurfaceView(c).apply {
                    holder.addCallback(object : SurfaceHolder.Callback {
                        override fun surfaceCreated(h: SurfaceHolder) { layer.setSurface(owner, h.surface) }
                        override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, hgt: Int) {}
                        override fun surfaceDestroyed(h: SurfaceHolder) { layer.clearSurface(owner) }
                    })
                }
            },
            modifier = Modifier.aspectRatio(layer.aspect)
        )
    } else {
        AndroidView(
            factory = { c ->
                TextureView(c).apply {
                    surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                        var s: Surface? = null
                        override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                            val sf = Surface(st); s = sf; layer.setSurface(owner, sf)
                        }
                        override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
                        override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                            layer.clearSurface(owner); s?.release(); s = null; return true
                        }
                        override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                    }
                }
            },
            update = { it.alpha = alpha },
            modifier = Modifier.aspectRatio(layer.aspect)
        )
    }
}

@Composable
fun VideoPanel(onPick: (Int) -> Unit, onTrack: (Int) -> Unit) {
    val floating = VideoWindow.floating
    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        // preview
        Column(Modifier.weight(1.25f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Box(Modifier.weight(1f).fillMaxWidth().clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp)).background(Color.Black)) {
                if (VideoWindow.full) Text("Output is fullscreen", color = TextGray, fontSize = 10.sp, modifier = Modifier.align(Alignment.Center))
                else if (floating) Text("Video is in the floating window.\nDrag it anywhere on screen.", color = TextGray, fontSize = 10.sp, modifier = Modifier.align(Alignment.Center))
                else VideoOutput(Modifier.fillMaxSize())
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                PadButton(if (floating) "DOCK HERE" else "FLOAT WINDOW", Modifier.weight(1f).height(28.dp), active = floating, color = Accent, fontSize = 10) { VideoWindow.visible = !floating }
                PadButton("FULLSCREEN", Modifier.weight(1f).height(28.dp), active = VideoWindow.full, color = Accent, fontSize = 10) { VideoWindow.full = true }
            }
        }
        // layers
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LayerCard(0, DeckALight, onPick, onTrack)
            LayerCard(1, DeckB, onPick, onTrack)
        }
        // mix
        Column(Modifier.weight(1.05f).fillMaxHeight().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("TRANSITION", color = TextGray, fontSize = 9.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("BLEND", "DIP", "CUT").forEachIndexed { i, t ->
                    PadButton(t, Modifier.weight(1f).height(28.dp), active = AppSettings.videoBlend == i, fontSize = 10) { AppSettings.videoBlend = i; AppSettings.save() }
                }
            }
            Text("VIDEO FADER", color = TextGray, fontSize = 9.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                PadButton("XFADER", Modifier.weight(1f).height(28.dp), active = AppSettings.videoFollowCross, color = Accent, fontSize = 10) { AppSettings.videoFollowCross = true; AppSettings.save() }
                PadButton("MANUAL", Modifier.weight(1f).height(28.dp), active = !AppSettings.videoFollowCross, color = Accent, fontSize = 10) {
                    VideoMixer.manualCross = VideoMixer.audioCross
                    AppSettings.videoFollowCross = false; AppSettings.save()
                }
            }
            val x = VideoMixer.cross
            FxSlider("MIX", x, 0f..1f, Accent, if (x < 0.02f) "A" else if (x > 0.98f) "B" else "${(x * 100).toInt()}") {
                if (!AppSettings.videoFollowCross) VideoMixer.manualCross = it
            }
            FxSlider("BRIGHT", AppSettings.videoBright, 0f..1f, Accent, "${(AppSettings.videoBright * 100).toInt()}%") {
                AppSettings.videoBright = it; AppSettings.save()
            }
            PadButton(if (AppSettings.videoFollowTempo) "SPEED FOLLOWS TEMPO" else "SPEED FIXED 1x", Modifier.fillMaxWidth().height(28.dp), active = AppSettings.videoFollowTempo, fontSize = 9) {
                AppSettings.videoFollowTempo = !AppSettings.videoFollowTempo; AppSettings.save()
            }
            PadButton(if (AppSettings.videoOverlay) "SMOOTH VIDEO: ON" else "SMOOTH VIDEO: OFF", Modifier.fillMaxWidth().height(28.dp), active = AppSettings.videoOverlay, fontSize = 9) {
                AppSettings.videoOverlay = !AppSettings.videoOverlay; AppSettings.save()
            }
            Text("Turn SMOOTH VIDEO off if the picture ever shows black.", color = TextGray, fontSize = 8.sp)
        }
    }
}

@Composable
private fun ColumnScope.LayerCard(i: Int, color: Color, onPick: (Int) -> Unit, onTrack: (Int) -> Unit) {
    val l = VideoMixer.layers[i]
    Column(
        Modifier.fillMaxWidth().weight(1f).clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp)).background(Color(0xFF262930)).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text("DECK ${if (i == 0) "A" else "B"} VIDEO", color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(
            when { l.name.isEmpty() -> "no video"; !l.ready && !l.name.startsWith("Error") -> "loading…  ${l.name}"; else -> l.name },
            color = TextGray, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            PadButton("VIDEO + SOUND", Modifier.weight(1.4f).height(26.dp), active = true, color = color, fontSize = 8) { onTrack(i) }
            PadButton("CLEAR", Modifier.weight(1f).height(26.dp), enabled = l.name.isNotEmpty(), fontSize = 9) { l.clear() }
        }
        PadButton("SILENT LOOP", Modifier.fillMaxWidth().height(24.dp), fontSize = 9) { onPick(i) }
        Text(
            if (l.proxyInfo.isNotEmpty()) l.proxyInfo else if (l.locked) "Plays with the deck's sound, in sync" else if (l.name.isNotEmpty()) "Silent loop, plays while the deck plays" else "VIDEO + SOUND loads a video as the track",
            color = TextGray, fontSize = 8.sp, maxLines = 1
        )
        if (l.name.isNotEmpty() && !l.locked)
            PadButton(if (l.forcePlay) "PLAYING ALWAYS" else "PLAY WITHOUT DECK", Modifier.fillMaxWidth().height(24.dp), active = l.forcePlay, color = color, fontSize = 9) { l.forcePlay = !l.forcePlay }
    }
}

object VideoWindow {
    var visible by mutableStateOf(true)
    var full by mutableStateOf(false)
    var x by mutableFloatStateOf(-1f)      // px, top-left of the window; negative = not placed yet
    var y by mutableFloatStateOf(-1f)
    var widthDp by mutableFloatStateOf(240f)
    val anyReady: Boolean get() = VideoMixer.layers.any { it.ready }
    /** True while the draggable window (not the panel preview) owns the video surfaces. */
    val floating: Boolean get() = visible && anyReady && !full
}

/** Draggable, resizable video window that pops up over the whole app as soon as a video is loaded. */
@Composable
fun FloatingVideo() {
    val a = VideoMixer.layers[0].ready; val b = VideoMixer.layers[1].ready
    LaunchedEffect(a, b) { if (a || b) VideoWindow.visible = true }

    if (VideoWindow.full) Dialog(onDismissRequest = { VideoWindow.full = false }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black).clickable { VideoWindow.full = false }) {
            VideoOutput(Modifier.fillMaxSize())
            Text("tap to close", color = Color.White.copy(alpha = 0.35f), fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(6.dp))
        }
    }
    if (!VideoWindow.floating) return

    val density = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val maxW = constraints.maxWidth.toFloat(); val maxH = constraints.maxHeight.toFloat()
        val aspect = (VideoMixer.layers.firstOrNull { it.ready } ?: VideoMixer.layers[0]).aspect.coerceIn(0.4f, 3f)
        val headerDp = 22f
        val wPx = with(density) { VideoWindow.widthDp.dp.toPx() }
        val hPx = with(density) { (VideoWindow.widthDp / aspect + headerDp).dp.toPx() }
        if (VideoWindow.x < 0f) { VideoWindow.x = maxW - wPx - 16f; VideoWindow.y = 16f }
        val px = VideoWindow.x.coerceIn(0f, (maxW - wPx).coerceAtLeast(0f))
        val py = VideoWindow.y.coerceIn(0f, (maxH - hPx).coerceAtLeast(0f))
        Column(
            Modifier.offset { IntOffset(px.roundToInt(), py.roundToInt()) }
                .width(VideoWindow.widthDp.dp)
                .clip(RoundedCornerShape(8.dp)).background(Color.Black)
                .border(1.dp, Accent, RoundedCornerShape(8.dp))
        ) {
            // title bar: drag here
            Row(
                Modifier.fillMaxWidth().height(headerDp.dp).background(Color(0xFF262930))
                    .pointerInput(Unit) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            VideoWindow.x = (VideoWindow.x.coerceAtLeast(0f) + drag.x).coerceIn(0f, (maxW - wPx).coerceAtLeast(0f))
                            VideoWindow.y = (VideoWindow.y.coerceAtLeast(0f) + drag.y).coerceIn(0f, (maxH - hPx).coerceAtLeast(0f))
                        }
                    }.padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("⠿ VIDEO", color = TextGray, fontSize = 9.sp, modifier = Modifier.weight(1f))
                Text("⛶", color = Color.White, fontSize = 13.sp, modifier = Modifier.clickable { VideoWindow.full = true }.padding(horizontal = 8.dp))
                Text("✕", color = Color.White, fontSize = 12.sp, modifier = Modifier.clickable { VideoWindow.visible = false }.padding(horizontal = 6.dp))
            }
            Box(Modifier.fillMaxWidth().aspectRatio(aspect)) {
                VideoOutput(Modifier.fillMaxSize())
                // resize handle, bottom-right
                Box(
                    Modifier.align(Alignment.BottomEnd).size(28.dp)
                        .pointerInput(Unit) {
                            detectDragGestures { change, drag ->
                                change.consume()
                                val maxDp = with(density) { (maxW - VideoWindow.x.coerceAtLeast(0f)).toDp().value }
                                VideoWindow.widthDp = (VideoWindow.widthDp + with(density) { drag.x.toDp().value }).coerceIn(120f, maxDp.coerceAtLeast(120f))
                            }
                        },
                    contentAlignment = Alignment.BottomEnd
                ) { Text("◢", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp, modifier = Modifier.padding(3.dp)) }
            }
        }
    }
}
