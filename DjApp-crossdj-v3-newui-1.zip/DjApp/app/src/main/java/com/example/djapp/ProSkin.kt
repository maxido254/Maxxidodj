package com.example.djapp

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

/*
 * Pro-DJ style pieces (original artwork): a deck info panel with a big BPM / key / time readout, a row of colored hot-cue pads
 * under each platter, and channel strips (HI / MID / LOW + volume faders) in the centre mixer.
 * They can be switched on / off in Settings > LAYOUT.
 */

private val HotColors = listOf(Color(0xFFFF5C7A), Color(0xFFFFB74D), Color(0xFF64B5F6), Color(0xFFBA68C8))

private fun clock(t: Double): String {
    val s = maxOf(0, t.toInt())
    return "%d:%02d".format(s / 60, s % 60)
}

/** Big readout beside the platter: deck letter, live BPM, key, pitch and elapsed / remaining time. */
@Composable
fun ProDeckInfo(d: DeckState, modifier: Modifier = Modifier) {
    Column(modifier.padding(horizontal = 4.dp, vertical = 8.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Column {
            Box(Modifier.size(18.dp).clip(RoundedCornerShape(4.dp)).background(d.accent), contentAlignment = Alignment.Center) {
                Text(if (d.id == 0) "A" else "B", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Text(
                if (d.loaded && d.bpm > 0f) "%.1f".format(d.effectiveBpm) else "---",
                color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, maxLines = 1,
                modifier = Modifier.padding(top = 4.dp)
            )
            Text("BPM", color = TextGray, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Text(
                if (d.loaded && d.key.isNotEmpty()) d.key else "--", color = d.accent, fontSize = 10.sp,
                fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(top = 4.dp)
            )
        }
        Column {
            Text("%+.1f%%".format(d.tempoPct * 100f), color = TextGray, fontSize = 9.sp, fontFamily = FontFamily.Monospace, maxLines = 1)
            Text(
                if (d.loaded) clock(d.posSec) else "0:00", color = Color.White, fontSize = 13.sp,
                fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, maxLines = 1
            )
            Text(
                if (d.loaded) "-" + clock(d.duration - d.posSec) else "-0:00", color = TextGray, fontSize = 10.sp,
                fontFamily = FontFamily.Monospace, maxLines = 1
            )
        }
    }
}

/** Four colored hot-cue pads. Tap = set / jump, long-press = clear. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ProPadRow(d: DeckState, modifier: Modifier = Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        for (i in 0..3) {
            val set = d.hotcues[i] >= 0.0
            Box(
                Modifier.weight(1f).height(22.dp).clip(RoundedCornerShape(5.dp))
                    .background(if (set) HotColors[i] else HotColors[i].copy(alpha = 0.16f))
                    .combinedClickable(enabled = d.loaded, onClick = { d.hotcue(i) }, onLongClick = { d.clearHotcue(i) }),
                contentAlignment = Alignment.Center
            ) {
                Text("${i + 1}", color = if (set) Color.Black else HotColors[i], fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** HI / MID / LOW and volume for one channel, side by side as vertical faders. */
@Composable
fun ChannelStrip(d: DeckState, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF0B0F17)).padding(horizontal = 3.dp, vertical = 4.dp)) {
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            for ((label, band) in listOf("HI" to 2, "MID" to 1, "LOW" to 0)) {
                StripFader(
                    label, eqToFrac(d.eq[band]), true, d.accent, Modifier.weight(1f).fillMaxHeight(),
                    { f -> d.setEq(band, eqFromFrac(f)) }, { d.setEq(band, 0f) }
                )
            }
            StripFader(
                "VOL", d.vol.coerceIn(0f, 1f), false, d.accent, Modifier.weight(1.25f).fillMaxHeight(),
                { f -> d.vol = f; d.pushVolume() }, { d.vol = 1f; d.pushVolume() }
            )
        }
    }
}

@Composable
private fun StripFader(
    label: String, frac: Float, center: Boolean, accent: Color, modifier: Modifier,
    onFrac: (Float) -> Unit, onReset: () -> Unit
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            label, color = TextGray, fontSize = 7.sp, fontWeight = FontWeight.Bold, maxLines = 1,
            modifier = Modifier.clickable { onReset() }.padding(bottom = 2.dp)
        )
        Box(Modifier.weight(1f).fillMaxWidth().faderTouch(true) { f -> onFrac(if (center && abs(f - 0.5f) < 0.04f) 0.5f else f.coerceIn(0f, 1f)) }) {
            Canvas(Modifier.fillMaxSize()) {
                val th = 9.dp.toPx(); val top = th / 2f; val bot = size.height - th / 2f
                val mid = (top + bot) / 2f
                val y = bot - (bot - top) * frac.coerceIn(0f, 1f)
                val tx = size.width / 2f; val tw = 4.dp.toPx()
                drawRoundRect(Color(0xFF05070B), Offset(tx - tw / 2f, top), Size(tw, bot - top), CornerRadius(tw / 2f))
                val base = if (center) mid else bot
                drawRect(accent, Offset(tx - tw / 2f, minOf(y, base)), Size(tw, abs(y - base)))
                if (center) drawLine(Color(0xFF6A6D75), Offset(tx - size.width * 0.4f, mid), Offset(tx + size.width * 0.4f, mid), 1.dp.toPx())
                drawRoundRect(Color(0xFFD9DCE3), Offset(tx - size.width * 0.42f, y - th / 2f), Size(size.width * 0.84f, th), CornerRadius(2.dp.toPx()))
                drawLine(Color(0xFF30333A), Offset(tx - size.width * 0.3f, y), Offset(tx + size.width * 0.3f, y), 1.dp.toPx())
            }
        }
    }
}
