package com.example.djapp

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import org.json.JSONObject
import java.io.File

/** All the colours a skin can change. Anything a skin file leaves out keeps the default value. */
data class SkinColors(
    val bg: Color = Color(0xFF05070B),
    val panel: Color = Color(0xFF0B0F17),
    val btnTop: Color = Color(0xFF1D222C),
    val btnBottom: Color = Color(0xFF131720),
    val line: Color = Color(0xFF2A303C),
    val text: Color = Color(0xFF8FA0BD),
    val card: Color = Color(0xFF1B212C),
    val deckA: Color = Color(0xFF1AA3FF),
    val deckADark: Color = Color(0xFF0F2C4A),
    val deckALight: Color = Color(0xFF66C2FF),
    val deckB: Color = Color(0xFF9B4DFF),
    val deckBDark: Color = Color(0xFF2A1A4A),
    val deckBLight: Color = Color(0xFFC08BFF)
)

/**
 * Colour skins. A skin is a small JSON file, for example:
 *   { "id": "neon-red", "name": "Neon Red", "bg": "#0A0505", "deckA": "#FF3B3B", "deckALight": "#FF8A8A" }
 * Skins that the user downloaded from the Store live in files/skins/<id>.json. The chosen skin is remembered.
 */
object Skin {
    val DEFAULT = SkinColors()
    var current by mutableStateOf(DEFAULT)
    var activeId by mutableStateOf("")            // "" = the built-in look

    private lateinit var app: Context
    private val prefs get() = app.getSharedPreferences("djstore", Context.MODE_PRIVATE)
    val dir: File get() = File(app.filesDir, "skins").apply { mkdirs() }

    fun init(ctx: Context) {
        app = ctx.applicationContext
        val id = prefs.getString("skin", "") ?: ""
        if (id.isNotEmpty() && !apply(id)) apply("")
    }

    /** Installed skins as id to display name. */
    fun installed(): List<Pair<String, String>> =
        (dir.listFiles { f -> f.extension == "json" } ?: emptyArray()).mapNotNull { f ->
            try { f.nameWithoutExtension to JSONObject(f.readText()).optString("name", f.nameWithoutExtension) } catch (_: Exception) { null }
        }.sortedBy { it.second.lowercase() }

    /** Switches to skin [id]; "" returns to the built-in look. Returns false if the skin file is missing or broken. */
    fun apply(id: String): Boolean {
        if (id.isEmpty()) { current = DEFAULT; activeId = ""; prefs.edit().putString("skin", "").apply(); return true }
        return try {
            current = parse(JSONObject(File(dir, "$id.json").readText()))
            activeId = id
            prefs.edit().putString("skin", id).apply()
            true
        } catch (_: Exception) { false }
    }

    fun delete(id: String) {
        File(dir, "$id.json").delete()
        if (activeId == id) apply("")
    }

    /** Throws if the JSON is not a usable skin; the Store calls this before it installs a download. */
    fun parse(j: JSONObject): SkinColors {
        val d = DEFAULT
        fun c(key: String, def: Color): Color =
            if (j.has(key)) Color(android.graphics.Color.parseColor(j.getString(key))) else def
        return SkinColors(
            bg = c("bg", d.bg), panel = c("panel", d.panel), btnTop = c("btnTop", d.btnTop), btnBottom = c("btnBottom", d.btnBottom),
            line = c("line", d.line), text = c("text", d.text), card = c("card", d.card),
            deckA = c("deckA", d.deckA), deckADark = c("deckADark", d.deckADark), deckALight = c("deckALight", d.deckALight),
            deckB = c("deckB", d.deckB), deckBDark = c("deckBDark", d.deckBDark), deckBLight = c("deckBLight", d.deckBLight)
        )
    }
}
