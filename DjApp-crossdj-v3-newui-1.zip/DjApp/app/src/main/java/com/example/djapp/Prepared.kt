package com.example.djapp

import android.content.Context
import android.net.Uri
import android.os.Process
import androidx.compose.runtime.*
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.Executors

/** Its own low-priority thread, so preparing a library never competes with live stem work or the audio thread. */
private val prepQueueDispatcher = Executors.newSingleThreadExecutor { r ->
    Thread({ Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND); r.run() }, "prep-queue")
}.asCoroutineDispatcher()

class PrepInfo(
    val dir: File, val rate: Int, val bpm: Float, val offset: Double, val key: String, val title: String, val wave: WaveData?
) {
    val stemPaths: Array<String> get() = STEM_NAMES.map { File(dir, "$it.pcm").absolutePath }.toTypedArray()
}

/**
 * A "prepared" track = one folder in the app's own storage holding the 4 finished stems, the beat grid, the key
 * and the waveform. Loading one needs no decoding, no analysis and no separation: it is instant even on a weak phone,
 * and uses no CPU while you play. (Same idea as VirtualDJ's pre-made stem files.)
 */
object Prepared {
    /** key (hash of the track's uri) -> folder name inside "Prepared stems". */
    private val keys = mutableStateMapOf<String, String>()
    private var inited = false
    val count: Int get() = keys.size

    /** The permanent "Prepared stems" folder. Nothing in it is ever deleted by the app on its own: only the user deletes. */
    fun root(ctx: Context): File {
        val base = try { ctx.getExternalFilesDir(null) } catch (_: Exception) { null } ?: ctx.filesDir
        return File(base, "Prepared stems").apply { mkdirs() }
    }

    private fun safeName(title: String): String =
        title.replace(Regex("[^\\p{L}\\p{N} ._()-]"), "_").trim().take(60).ifEmpty { "track" }

    private val keyRe = Regex(" \\[([0-9a-f]{16})\\]$")
    private fun keyOfDir(name: String): String? = keyRe.find(name)?.groupValues?.get(1) ?: name.takeIf { it.matches(Regex("[0-9a-f]{16}")) }

    private val keyCache = java.util.concurrent.ConcurrentHashMap<String, String>()
    fun keyOf(uri: Uri): String = keyCache.getOrPut(uri.toString()) {
        MessageDigest.getInstance("SHA-1").digest(uri.toString().toByteArray()).take(8).joinToString("") { "%02x".format(it) }
    }

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        // Older versions kept prepared tracks (and could delete them) in the app's private "prep" folder: move them over.
        try {
            val old = File(ctx.filesDir, "prep")
            val rootDir = root(ctx)
            old.listFiles()?.forEach { d ->
                if (d.isDirectory && !d.name.endsWith(".tmp") && File(d, "meta.json").exists()) {
                    val dest = File(rootDir, d.name)
                    if (!dest.exists() && !d.renameTo(dest)) { d.copyRecursively(dest, overwrite = true) }
                    d.deleteRecursively()
                }
            }
            old.deleteRecursively()
        } catch (_: Exception) { }
        root(ctx).listFiles()?.forEach { d ->
            if (d.isDirectory && !d.name.endsWith(".tmp")) {
                val k = keyOfDir(d.name)
                if (k != null && File(d, "meta.json").exists()) keys[k] = d.name
                // a folder without meta.json is left alone: it may be something the user put there
            } else if (d.isDirectory && d.name.endsWith(".tmp")) d.deleteRecursively()    // interrupted job
        }
    }

    fun has(uri: Uri): Boolean = keys.containsKey(keyOf(uri))

    /** The user deletes one prepared track. */
    fun delete(ctx: Context, uri: Uri) {
        val k = keyOf(uri)
        val name = keys[k] ?: return
        File(root(ctx), name).deleteRecursively(); keys.remove(k)
    }

    fun find(ctx: Context, uri: Uri): PrepInfo? = try {
        val dir = File(root(ctx), keys[keyOf(uri)] ?: "-")
        val meta = File(dir, "meta.json")
        if (!meta.exists() || !STEM_NAMES.all { File(dir, "$it.pcm").length() > 0 }) null
        else {
            val j = JSONObject(meta.readText())
            dir.setLastModified(System.currentTimeMillis())
            PrepInfo(dir, j.getInt("rate"), j.optDouble("bpm", 0.0).toFloat(), j.optDouble("offset", 0.0), j.optString("key", ""), j.optString("title", ""), readWave(File(dir, "wave.bin")))
        }
    } catch (_: Exception) { null }

    private fun readWave(f: File): WaveData? = try {
        DataInputStream(f.inputStream().buffered()).use { s ->
            val n = s.readInt(); val per = s.readInt(); val mx = s.readFloat()
            val pk = FloatArray(n) { s.readFloat() }; val lw = FloatArray(n) { s.readFloat() }
            WaveData(pk, lw, per, mx)
        }
    } catch (_: Exception) { null }

    private fun writeWave(f: File, w: WaveData) {
        DataOutputStream(f.outputStream().buffered()).use { s ->
            s.writeInt(w.peak.size); s.writeInt(w.perSec); s.writeFloat(w.maxPeak)
            for (v in w.peak) s.writeFloat(v); for (v in w.low) s.writeFloat(v)
        }
    }

    fun usageBytes(ctx: Context): Long = root(ctx).walkTopDown().filter { it.isFile }.sumOf { it.length() }

    /** Only called when the user asks (Settings > Stems > DELETE ALL). Deletes the prepared tracks, never other files. */
    fun deleteAll(ctx: Context) {
        keys.values.toList().forEach { File(root(ctx), it).deleteRecursively() }
        keys.clear()
    }

    fun commit(ctx: Context, tmp: File, uri: Uri, title: String): Boolean {
        val k = keyOf(uri)
        keys[k]?.let { File(root(ctx), it).deleteRecursively() }
        val name = "${safeName(title)} [$k]"
        val dir = File(root(ctx), name)
        dir.deleteRecursively()
        if (!tmp.renameTo(dir)) return false
        keys[k] = name
        return true
    }

    fun writeMeta(dir: File, rate: Int, frames: Long, grid: BeatGrid?, key: String, title: String, wave: WaveData?) {
        File(dir, "meta.json").writeText(
            JSONObject().put("v", 1).put("rate", rate).put("frames", frames)
                .put("bpm", (grid?.bpm ?: 0f).toDouble()).put("offset", grid?.offsetSec ?: 0.0)
                .put("key", key).put("title", title).toString()
        )
        if (wave != null) writeWave(File(dir, "wave.bin"), wave)
    }
}

/**
 * Prepares tracks one after another in the background (decode -> beat grid + key -> stems -> waveform) and stores
 * them with [Prepared]. Runs at the lowest priority and, by default, pauses while a deck is playing.
 */
object PrepQueue {
    class Item(val uri: Uri, val title: String)

    val queue = mutableStateListOf<Item>()
    var current by mutableStateOf("")
    var progress by mutableFloatStateOf(0f)
    var running by mutableStateOf(false)
        private set
    var paused by mutableStateOf(false)
        private set
    private var stopFlag = false
    private val scope = CoroutineScope(SupervisorJob() + prepQueueDispatcher)

    fun add(ctx: Context, uri: Uri, title: String) {
        if (Prepared.has(uri) || queue.any { it.uri == uri } || current == title && running) return
        queue.add(Item(uri, title))
        start(ctx.applicationContext)
    }

    fun stop() { stopFlag = true; queue.clear() }

    private fun anyDeckPlaying() = NativeEngine.isPlaying(0) || NativeEngine.isPlaying(1)

    private fun start(app: Context) {
        if (running) return
        running = true; stopFlag = false
        scope.launch {
            try {
                while (!stopFlag) {
                    val item = queue.firstOrNull() ?: break
                    current = item.title; progress = 0f
                    try { prepareOne(app, item) } catch (_: Exception) {} catch (_: OutOfMemoryError) {}   // out of memory: skip this track, never crash
                    queue.remove(item)
                }
            } finally { running = false; current = ""; progress = 0f; paused = false }
        }
    }

    private fun checkpoint(): Boolean {
        // Called very often by the separator: wait here while music is playing so the audio thread keeps the CPU.
        while (!stopFlag && AppSettings.prepPause && anyDeckPlaying()) { paused = true; Thread.sleep(300) }
        paused = false
        return stopFlag
    }

    private fun prepareOne(app: Context, item: Item) {
        val root = Prepared.root(app)
        val tmpDir = File(root, Prepared.keyOf(item.uri) + ".tmp").also { it.deleteRecursively(); it.mkdirs() }
        val mix = File(app.cacheDir, "prep_mix.pcm")
        try {
            if (checkpoint()) return
            val rate = Decoder.decode(app, item.uri, mix)
            progress = 0.05f
            if (checkpoint()) return
            val grid = BpmDetector.grid(mix, rate)
            val k = KeyDetector.detect(mix, rate)
            progress = 0.1f
            val sep: StemSeparator = if (AppSettings.prepQuality == 0) HpssSeparator() else ProSeparator()
            val ok = sep.separate(mix, rate, tmpDir, { progress = 0.1f + 0.85f * it.coerceIn(0f, 1f) }, { checkpoint() })
            if (!ok || stopFlag) return
            val wave = WaveAnalyzer.analyze(mix, rate)
            Prepared.writeMeta(tmpDir, rate, mix.length() / 4, grid, if (k != null) "${k.camelot} ${k.name}" else "", item.title, wave)
            Prepared.commit(app, tmpDir, item.uri, item.title)
            progress = 1f
        } finally {
            mix.delete()
            if (tmpDir.exists()) tmpDir.deleteRecursively()
        }
    }
}
