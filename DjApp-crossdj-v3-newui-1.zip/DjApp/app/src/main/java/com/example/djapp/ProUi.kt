package com.example.djapp

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay

/** The "unlock PRO" dialog. Shown by Pro.gate() / Pro.nudge(); closes itself a moment after PRO switches on. */
@Composable
fun PaywallHost() {
    val feature = Pro.paywallFor ?: return
    val ctx = LocalContext.current
    LaunchedEffect(feature) { Pro.loadQuote(ctx) }
    LaunchedEffect(Pro.active) { if (Pro.active) { delay(1500); Pro.closePaywall() } }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = { Pro.closePaywall() },
        title = { Text("MAXIDO DJ PRO", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
        text = { PaywallBody(feature) },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = { Pro.closePaywall() }) { Text(if (Pro.active) "DONE" else "NOT NOW") }
        }
    )
}

@Composable
private fun PaywallBody(feature: String) {
    var restoring by remember { mutableStateOf(false) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            when (feature) { Pro.VIDEO -> "Video mixing is a PRO feature."; Pro.STEMS -> "Stem separation is a PRO feature."; else -> "Unlock MAXIDO DJ PRO." },
            fontSize = 13.sp, fontWeight = FontWeight.Medium
        )
        Text(
            "One payment unlocks video mixing and stem separation (acapella, instrumental, beatless). Everything else stays free.",
            fontSize = 12.sp, color = TextGray
        )
        if (Pro.active) {
            Text("PRO is ON. Thank you!", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Accent)
        } else if (!restoring) {
            PayForms()
        } else {
            RestoreForm()
        }
        if (Pro.message.isNotEmpty()) Text(Pro.message, fontSize = 12.sp, color = Accent)
        if (!Pro.active) ManualPay()
        if (Pro.busy) {
            androidx.compose.material3.TextButton(onClick = { Pro.cancelWaiting() }) { Text("STOP WAITING", fontSize = 11.sp) }
        } else if (!Pro.active) {
            androidx.compose.material3.TextButton(onClick = { restoring = !restoring; Pro.message = "" }) {
                Text(if (restoring) "BACK TO PAYING" else "ALREADY PAID? RESTORE PRO", fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun PayForms() {
    val ctx = LocalContext.current
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    val mpesa = Pro.offers.firstOrNull { it.method == "mpesa" } ?: if (Pro.offers.isEmpty()) Pro.Offer("mpesa", 150.0, "KES") else null
    val card = Pro.offers.firstOrNull { it.method == "card" }
    if (!Pro.configured) {
        Text("Payments are not switched on in this build yet.", fontSize = 12.sp, color = TextGray)
        return
    }
    if (mpesa != null) {
        Text("M-Pesa (Kenya)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        androidx.compose.material3.OutlinedTextField(
            value = phone, onValueChange = { phone = it.take(16) }, singleLine = true,
            label = { Text("M-Pesa number, e.g. 0712 345 678", fontSize = 11.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth()
        )
        PadButton("PAY ${mpesa.label} WITH M-PESA", Modifier.fillMaxWidth(), active = true, color = Accent,
            enabled = !Pro.busy && phone.filter { it.isDigit() }.length >= 9, fontSize = 12) { Pro.payMpesa(ctx, phone) }
    }
    if (card != null) {
        Text("Card or mobile money (other countries)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        androidx.compose.material3.OutlinedTextField(
            value = email, onValueChange = { email = it.take(80) }, singleLine = true,
            label = { Text("E-mail for your receipt", fontSize = 11.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth()
        )
        PadButton("PAY ${card.label} BY CARD", Modifier.fillMaxWidth(), active = true, color = Accent,
            enabled = !Pro.busy && email.contains('@'), fontSize = 12) { Pro.payCard(ctx, email) }
    }
}

/** No payment prompt available (or no M-Pesa business number yet): pay by normal Send Money, the owner switches PRO on. */
@Composable
private fun ManualPay() {
    val ctx = LocalContext.current
    Text("Prefer to pay by Send Money? Message us, pay, then tap CHECK PRO.", fontSize = 11.sp, color = TextGray)
    PadButton("WHATSAPP US MY PHONE ID", Modifier.fillMaxWidth(), fontSize = 11) {
        Pro.refreshNow(true)
        openWhatsApp(ctx, "Hi, I want MAXIDO DJ PRO. My Phone ID is ${Pro.deviceIdFull()}")
    }
    PadButton("CHECK PRO NOW", Modifier.fillMaxWidth(), enabled = !Pro.busy, fontSize = 11) { Pro.refreshNow(true) }
}

@Composable
private fun RestoreForm() {
    var receipt by remember { mutableStateOf("") }
    var proof by remember { mutableStateOf("") }
    Text(
        "New phone or reinstalled? Enter the M-Pesa receipt code from your payment SMS (like SJK1ABC234) and the number you paid with. Card payers: the receipt number and e-mail.",
        fontSize = 12.sp, color = TextGray
    )
    androidx.compose.material3.OutlinedTextField(
        value = receipt, onValueChange = { receipt = it.take(40) }, singleLine = true,
        label = { Text("Receipt code", fontSize = 11.sp) }, modifier = Modifier.fillMaxWidth()
    )
    androidx.compose.material3.OutlinedTextField(
        value = proof, onValueChange = { proof = it.take(80) }, singleLine = true,
        label = { Text("Phone number or e-mail used to pay", fontSize = 11.sp) }, modifier = Modifier.fillMaxWidth()
    )
    PadButton("RESTORE PRO", Modifier.fillMaxWidth(), active = true, color = Accent,
        enabled = !Pro.busy && receipt.length >= 6 && proof.length >= 5, fontSize = 12) { Pro.restore(receipt, proof) }
}

/** Settings > PRO tab. */
@Composable
fun ProSettingsPage() {
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (Pro.active) "PRO is ON" else "PRO is OFF", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = if (Pro.active) Accent else TextGray)
        Text("PRO unlocks video mixing and stem separation. One payment (KSh 150, or the same value in your currency).", fontSize = 12.sp, color = TextGray)
        Text("Phone ID (give this to support if something goes wrong): ${Pro.deviceIdShort()}", fontSize = 11.sp, color = TextGray)
        if (!Pro.active) PadButton("UNLOCK PRO", Modifier.fillMaxWidth(), active = true, color = Accent) { Pro.show() }
        PadButton("CHECK PRO STATUS NOW", Modifier.fillMaxWidth(), enabled = !Pro.busy) { Pro.refreshNow(true) }
        if (Pro.message.isNotEmpty()) Text(Pro.message, fontSize = 12.sp, color = Accent)
    }
}
