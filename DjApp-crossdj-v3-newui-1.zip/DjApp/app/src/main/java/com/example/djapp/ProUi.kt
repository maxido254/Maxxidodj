package com.example.djapp

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay

/** The "unlock PRO" dialog. Shown by Pro.gate() / Pro.nudge(); closes itself a moment after PRO switches on. */
@Composable
fun PaywallHost() {
    val feature = Pro.paywallFor ?: return
    val ctx = LocalContext.current
    LaunchedEffect(feature) { Pro.loadQuote(ctx) }
    LaunchedEffect(Pro.active) { if (Pro.active) { delay(1500); Pro.closePaywall() } }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = { Pro.closePaywall() },
        title = { Text("MAXIDO DJ PRO", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
        text = { PaywallBody(feature) },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = { Pro.closePaywall() }) { Text(if (Pro.active) "DONE" else "NOT NOW") }
        }
    )
}

@Composable
private fun PaywallBody(feature: String) {
    var restoring by remember { mutableStateOf(false) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            when (feature) { Pro.VIDEO -> "Video mixing is a PRO feature."; Pro.STEMS -> "Stem separation is a PRO feature."; else -> "Unlock MAXIDO DJ PRO." },
            fontSize = 13.sp, fontWeight = FontWeight.Medium
        )
        Text(
            "One payment unlocks video mixing and stem separation (acapella, instrumental, beatless). Everything else stays free.",
            fontSize = 12.sp, color = TextGray
        )
        if (Pro.active) {
            Text("PRO is ON. Thank you!", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Accent)
        } else if (!restoring) {
            PayForms()
        } else {
            RestoreForm()
        }
        if (Pro.message.isNotEmpty()) Text(Pro.message, fontSize = 12.sp, color = Accent)
        if (!Pro.active && Pro.serverMode) ManualPay()
        if (Pro.busy) {
            androidx.compose.material3.TextButton(onClick = { Pro.cancelWaiting() }) { Text("STOP WAITING", fontSize = 11.sp) }
        } else if (!Pro.active && Pro.serverMode) {
            androidx.compose.material3.TextButton(onClick = { restoring = !restoring; Pro.message = "" }) {
                Text(if (restoring) "BACK TO PAYING" else "ALREADY PAID? RESTORE PRO", fontSize = 11.sp)
            }
        }
    }
}

/** No-server mode: pay on the Paystack website, then either type the payment reference (instant) or paste an activation code. */
@Composable
private fun LicencePay() {
    val ctx = LocalContext.current
    var ref by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var useCode by remember { mutableStateOf(false) }
    Text("1. Pay online (M-Pesa or card)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
    PadButton("OPEN THE PAYMENT PAGE", Modifier.fillMaxWidth(), active = true, color = Accent, fontSize = 12) { Pro.openPaymentPage(ctx) }
    if (Pro.claimsEnabled && !useCode) {
        Text("2. When you have paid, type the payment reference from your Paystack receipt (e-mail or SMS):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        androidx.compose.material3.OutlinedTextField(
            value = ref, onValueChange = { ref = it.filter { c -> !c.isWhitespace() }.take(40) }, singleLine = true,
            label = { Text("Payment reference", fontSize = 11.sp) }, modifier = Modifier.fillMaxWidth()
        )
        PadButton("UNLOCK PRO NOW", Modifier.fillMaxWidth(), active = true, color = Accent, enabled = ref.length >= 8, fontSize = 12) {
            Pro.claim(ref)
            if (Pro.active) openWhatsApp(ctx, Pro.paymentDetailsMessage())
        }
        Text("PRO switches on right away. We match your payment in Paystack afterwards; tap SEND in the WhatsApp message that opens to help us do that.", fontSize = 11.sp, color = TextGray)
    } else {
        Text("2. Send us your Phone ID and payment reference. We reply with an activation code:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        PadButton("SEND MY PHONE ID ON WHATSAPP", Modifier.fillMaxWidth(), fontSize = 11) {
            openWhatsApp(ctx, "Hi, I paid for MAXIDO DJ PRO.\nMy Phone ID: ${Pro.deviceIdFull()}\nPayment reference: ")
        }
        androidx.compose.material3.OutlinedTextField(
            value = code, onValueChange = { code = it.take(1200) }, maxLines = 3,
            label = { Text("Activation code", fontSize = 11.sp) }, modifier = Modifier.fillMaxWidth()
        )
        PadButton("ACTIVATE PRO", Modifier.fillMaxWidth(), active = true, color = Accent, enabled = code.length > 40, fontSize = 12) { Pro.redeem(code) }
    }
    if (Pro.claimsEnabled) {
        androidx.compose.material3.TextButton(onClick = { useCode = !useCode; Pro.message = "" }) {
            Text(if (useCode) "BACK TO: I HAVE PAID" else "HAVE AN ACTIVATION CODE INSTEAD?", fontSize = 11.sp)
        }
    }
}

@Composable
private fun PayForms() {
    val ctx = LocalContext.current
    if (!Pro.serverMode) { LicencePay(); return }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    val mpesa = Pro.offers.firstOrNull { it.method == "mpesa" }
    val card = Pro.offers.firstOrNull { it.method == "card" }
    val online = Pro.offers.firstOrNull { it.method == "online" }
    if (!Pro.configured) {
        Text("Payments are not switched on in this build yet.", fontSize = 12.sp, color = TextGray)
        return
    }
    if (!Pro.offersLoaded) {
        Text("Checking payment options…", fontSize = 12.sp, color = TextGray)
        return
    }
    if (mpesa == null && card == null && online == null) {
        Text("Automatic payment is not open yet. Pay by Send Money below and we switch PRO on for you.", fontSize = 12.sp, color = TextGray)
        return
    }
    if (online != null) {
        Text("Pay online (M-Pesa or card)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text("You will be taken to Paystack's secure website to pay. PRO switches on by itself when you come back.", fontSize = 11.sp, color = TextGray)
        androidx.compose.material3.OutlinedTextField(
            value = email, onValueChange = { email = it.take(80) }, singleLine = true,
            label = { Text("Your e-mail (for the receipt)", fontSize = 11.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth()
        )
        PadButton("PAY ${online.label} ONLINE", Modifier.fillMaxWidth(), active = true, color = Accent,
            enabled = !Pro.busy && email.contains('@') && email.contains('.'), fontSize = 12) { Pro.payOnline(ctx, email) }
        if (Pro.payLink.isNotEmpty()) PadButton("OPEN THE PAYMENT PAGE AGAIN", Modifier.fillMaxWidth(), fontSize = 11) { Pro.reopenLink(ctx) }
    }
    if (mpesa != null) {
        Text("M-Pesa (Kenya)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        androidx.compose.material3.OutlinedTextField(
            value = phone, onValueChange = { phone = it.take(16) }, singleLine = true,
            label = { Text("M-Pesa number (also used to restore PRO later)", fontSize = 11.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth()
        )
        PadButton("PAY ${mpesa.label} WITH M-PESA", Modifier.fillMaxWidth(), active = true, color = Accent,
            enabled = !Pro.busy && phone.filter { it.isDigit() }.length >= 9, fontSize = 12) { Pro.payMpesa(ctx, phone) }
    }
    if (card != null) {
        Text("Card or mobile money (other countries)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        androidx.compose.material3.OutlinedTextField(
            value = email, onValueChange = { email = it.take(80) }, singleLine = true,
            label = { Text("E-mail for your receipt", fontSize = 11.sp) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth()
        )
        PadButton("PAY ${card.label} BY CARD", Modifier.fillMaxWidth(), active = true, color = Accent,
            enabled = !Pro.busy && email.contains('@'), fontSize = 12) { Pro.payCard(ctx, email) }
    }
}

/** No payment prompt available (or no M-Pesa business number yet): pay by normal Send Money, the owner switches PRO on. */
@Composable
private fun ManualPay() {
    val ctx = LocalContext.current
    Text("Prefer to pay by Send Money? Message us, pay, then tap CHECK PRO.", fontSize = 11.sp, color = TextGray)
    PadButton("WHATSAPP US MY PHONE ID", Modifier.fillMaxWidth(), fontSize = 11) {
        Pro.refreshNow(true)
        openWhatsApp(ctx, "Hi, I want MAXIDO DJ PRO. My Phone ID is ${Pro.deviceIdFull()}")
    }
    PadButton("CHECK PRO NOW", Modifier.fillMaxWidth(), enabled = !Pro.busy, fontSize = 11) { Pro.refreshNow(true) }
}

@Composable
private fun RestoreForm() {
    var receipt by remember { mutableStateOf("") }
    var proof by remember { mutableStateOf("") }
    Text(
        "New phone or reinstalled? Enter your payment reference (Settings > PRO on your old phone, or in your payment e-mail; or the M-Pesa receipt code like SJK1ABC234) and the number you paid with. Card payers: the e-mail you used.",
        fontSize = 12.sp, color = TextGray
    )
    androidx.compose.material3.OutlinedTextField(
        value = receipt, onValueChange = { receipt = it.take(40) }, singleLine = true,
        label = { Text("Receipt code", fontSize = 11.sp) }, modifier = Modifier.fillMaxWidth()
    )
    androidx.compose.material3.OutlinedTextField(
        value = proof, onValueChange = { proof = it.take(80) }, singleLine = true,
        label = { Text("Phone number or e-mail used to pay", fontSize = 11.sp) }, modifier = Modifier.fillMaxWidth()
    )
    PadButton("RESTORE PRO", Modifier.fillMaxWidth(), active = true, color = Accent,
        enabled = !Pro.busy && receipt.length >= 6 && proof.length >= 5, fontSize = 12) { Pro.restore(receipt, proof) }
}

/** Settings > PRO tab. */
@Composable
fun ProSettingsPage() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (Pro.active) "PRO is ON" else "PRO is OFF", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = if (Pro.active) Accent else TextGray)
        Text("PRO unlocks video mixing and stem separation. One payment (KSh 150, or the same value in your currency).", fontSize = 12.sp, color = TextGray)
        Text("Phone ID (give this to support if something goes wrong): ${Pro.deviceIdShort()}", fontSize = 11.sp, color = TextGray)
        if (Pro.paidReference().isNotEmpty()) Text("Payment reference (keep this, it restores PRO on a new phone): ${Pro.paidReference()}", fontSize = 11.sp, color = Accent)
        if (Pro.claimReference().isNotEmpty()) {
            Text("Payment reference: ${Pro.claimReference()}", fontSize = 11.sp, color = Accent)
            PadButton("SEND PAYMENT DETAILS ON WHATSAPP", Modifier.fillMaxWidth(), fontSize = 11) { openWhatsApp(ctx, Pro.paymentDetailsMessage()) }
        }
        if (!Pro.active) PadButton("UNLOCK PRO", Modifier.fillMaxWidth(), active = true, color = Accent) { Pro.show() }
        if (Pro.serverMode) PadButton("CHECK PRO STATUS NOW", Modifier.fillMaxWidth(), enabled = !Pro.busy) { Pro.refreshNow(true) }
        if (Pro.message.isNotEmpty()) Text(Pro.message, fontSize = 12.sp, color = Accent)
    }
}
