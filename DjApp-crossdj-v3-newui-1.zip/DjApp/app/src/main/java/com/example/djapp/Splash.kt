package com.example.djapp

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

private val LogoTeal = Color(0xFF1DE9B6)

/**
 * Start-up animation: the app logo (headphones + waveform) draws itself, then the name, the handle
 * and the tagline fade in. Taps are ignored; it always plays to the end. [onDone] is called when it has faded out.
 */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val draw = remember { Animatable(0f) }      // 0..1: headband, ear cups, waveform
    val text = remember { Animatable(0f) }      // 0..1: texts
    val pulse = remember { Animatable(0f) }     // glow after drawing
    val out = remember { Animatable(1f) }       // 1..0: whole splash fades away

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { draw.animateTo(1f, tween(1500, easing = LinearEasing)) }
            launch { kotlinx.coroutines.delay(1100); text.animateTo(1f, tween(700, easing = FastOutSlowInEasing)) }
            launch { kotlinx.coroutines.delay(1500); pulse.animateTo(1f, tween(900)) }
        }
        kotlinx.coroutines.delay(900)
        out.animateTo(0f, tween(350))
        onDone()
    }

    Column(
        Modifier.fillMaxSize().alpha(out.value).background(BgDark)
            // Taps do nothing: the animation always plays to the end. They are swallowed so they never reach the app underneath.
            .pointerInput(Unit) { awaitPointerEventScope { while (true) awaitPointerEvent().changes.forEach { it.consume() } } },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Canvas(Modifier.size(150.dp)) {
            val p = draw.value
            fun seg(from: Float, to: Float) = ((p - from) / (to - from)).coerceIn(0f, 1f)
            val k = size.minDimension / 108f
            withTransform({ scale(k, k, Offset.Zero) }) {
                // soft glow behind the logo, grows with the pulse
                val g = pulse.value
                if (g > 0f) drawCircle(LogoTeal.copy(alpha = 0.16f * (1f - kotlin.math.abs(g - 0.5f) * 1.2f)), 60f * (0.7f + g * 0.5f), Offset(54f, 62f))

                // headband
                val band = Path().apply { moveTo(30f, 62f); cubicTo(30f, 32f, 78f, 32f, 78f, 62f) }
                val bandPart = Path()
                PathMeasure().apply { setPath(band, false); getSegment(0f, length * seg(0f, 0.35f), bandPart, true) }
                drawPath(bandPart, Color.White, style = Stroke(5f, cap = StrokeCap.Round))

                // ear cups pop in
                val c = seg(0.25f, 0.5f)
                if (c > 0f) for (x in floatArrayOf(24f, 71f)) {
                    val cy = 69f
                    withTransform({ scale(c, c, Offset(x + 6.5f, cy)) }) {
                        drawRoundRect(Color.White.copy(alpha = c), Offset(x, 56f), Size(13f, 26f), CornerRadius(3f))
                    }
                }

                // waveform draws left to right (dark outline, then teal)
                val w = Path().apply {
                    moveTo(20f, 69f); lineTo(34f, 69f); lineTo(38f, 63f); lineTo(42f, 76f); lineTo(46f, 52f); lineTo(50f, 84f)
                    lineTo(54f, 48f); lineTo(58f, 80f); lineTo(62f, 58f); lineTo(66f, 72f); lineTo(70f, 66f); lineTo(74f, 69f); lineTo(88f, 69f)
                }
                val wp = Path()
                PathMeasure().apply { setPath(w, false); getSegment(0f, length * seg(0.45f, 1f), wp, true) }
                drawPath(wp, Color(0xFF14151A), style = Stroke(6.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(wp, LogoTeal, style = Stroke(3.5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
        Spacer(Modifier.height(14.dp))
        Column(Modifier.alpha(text.value), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("MAXIDO DJ", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Spacer(Modifier.height(4.dp))
            Text("Maxtech_058", color = LogoTeal, fontSize = 14.sp, fontWeight = FontWeight.Medium, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            Text("Built by a DJ for music lovers", color = TextGray, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
    }
}
