package com.example.djapp

import android.content.Context
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import kotlin.math.ceil
import kotlin.math.floor

/**
 * Stem swap pads: grab the VOCAL of a prepared song (exactly one deck loop long) onto a pad, then press that pad on any deck:
 * the deck's own vocal stops and the saved vocal takes over, locked to the deck's beat grid and tempo, so mashups take one tap.
 * 8 pages x 4 pads. Pads you store stay for good (files/stemswap/): they survive restarts and updates and only go when
 * the app is deleted unless you long-press a pad to erase it. A pad is never overwritten or renamed; only the pages carry names.
 * The saved vocal always keeps its ORIGINAL key: only its speed follows the deck (see renderSwapClip in engine.cpp). It also sounds
 * while the deck is stopped.
 */
object StemSwap {
    const val PAGES = 8
    const val PER_PAGE = 4
    const val SLOTS = PAGES * PER_PAGE
    val LENGTHS = listOf(1f, 2f, 4f, 8f, 16f, 32f, 64f)

    class Clip {
        var filled by mutableStateOf(false)
        var name by mutableStateOf("")            // song the vocal came from
        var beats = 0f
        var srcBpm = 0f
    }

    val clips = List(SLOTS) { Clip() }
    var page by mutableIntStateOf(0)
    val pageNames = androidx.compose.runtime.mutableStateListOf<String>().apply { repeat(PAGES) { add("") } }
    var pagesOpen by mutableStateOf(false)         // the pages dialog (jump to a page, name pages)
    var lenBeats by mutableStateOf(4f)            // used when the deck has no loop

    private lateinit var app: Context
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val dir get() = File(app.filesDir, "stemswap").apply { mkdirs() }

    fun init(ctx: Context) {
        app = ctx.applicationContext
        try {
            val ja = org.json.JSONArray(app.getSharedPreferences("stemswap", Context.MODE_PRIVATE).getString("pageNames", "[]"))
            for (i in 0 until minOf(PAGES, ja.length())) pageNames[i] = ja.optString(i)
        } catch (_: Exception) {}
        io.launch {
            for (i in 0 until SLOTS) {
                try {
                    val meta = File(dir, "$i.json"); val pcm = File(dir, "$i.pcm")
                    if (!meta.exists() || !pcm.exists()) continue
                    val j = JSONObject(meta.readText())
                    if (NativeEngine.loadSwap(i, pcm.absolutePath)) {
                        clips[i].name = j.optString("name"); clips[i].beats = j.optDouble("beats", 4.0).toFloat()
                        clips[i].srcBpm = j.optDouble("bpm", 0.0).toFloat(); clips[i].filled = true
                    }
                } catch (_: Exception) {}
            }
        }
    }

    private fun writeMeta(slot: Int) {
        val c = clips[slot]
        File(dir, "$slot.json").writeText(JSONObject().put("name", c.name).put("beats", c.beats.toDouble()).put("bpm", c.srcBpm.toDouble()).toString())
    }

    /** Pads always show their number; only pages carry names. */
    fun label(slot: Int): String = "${slot % PER_PAGE + 1}"

    /** What the page button shows: the user's name for the page, or P1..P8. */
    fun pageLabel(p: Int): String = pageNames[p].ifBlank { "P${p + 1}" }

    fun setPageName(p: Int, text: String) { pageNames[p] = text.take(16) }

    fun savePageNames() {
        val ja = org.json.JSONArray(); pageNames.forEach { ja.put(it.trim()) }
        app.getSharedPreferences("stemswap", Context.MODE_PRIVATE).edit().putString("pageNames", ja.toString()).apply()
    }

    fun nextPage(step: Int) { page = (page + step + PAGES) % PAGES }

    fun cycleLength() { lenBeats = LENGTHS[(LENGTHS.indexOf(lenBeats) + 1) % LENGTHS.size] }

    private fun toast(msg: String) = Toast.makeText(app, msg, Toast.LENGTH_SHORT).show()

    /** Works like a hot cue: tap an empty pad to store this deck's vocal on it, tap a filled pad to swap it in / out, long-press a filled pad to erase it. */
    fun tap(d: DeckState, slot: Int) {
        if (clips[slot].filled) toggle(d, slot) else capture(d, slot)
    }

    /** Takes the vocal stem of deck [d] for one deck-loop length: the active loop, otherwise [lenBeats] starting exactly where the song is
     *  right now (playing or stopped; it does not have to be a cue point). */
    fun capture(d: DeckState, slot: Int) {
        if (!d.loaded || !d.stemsReady) { toast("Load a prepared song on this deck first"); return }
        if (d.bpm <= 0f) { toast("This song has no BPM yet"); return }
        val period = 60.0 / d.bpm
        val start: Double; var beats: Float
        if (d.loopActive && d.loopIn >= 0 && d.loopOut > d.loopIn) {
            start = d.loopIn
            beats = if (d.loopBeats > 0f) d.loopBeats else ((d.loopOut - d.loopIn) / period).toFloat()
        } else {
            beats = lenBeats
            start = d.pos()                                // no loop: record from the playhead, playing or stopped
        }
        if (beats <= 0f) return
        val len = if (d.loopActive && d.loopBeats <= 0f && d.loopOut > d.loopIn) d.loopOut - d.loopIn else beats * period
        val s0 = if (start < 0) 0.0 else if (start + len > d.duration) maxOf(0.0, d.duration - len) else start
        if (d.swapSlot == slot) { d.swapSlot = -1; NativeEngine.setSwap(d.id, -1, 0.0, 0.0) }
        if (!NativeEngine.captureSwap(d.id, slot, s0, len)) { toast("Could not grab the vocal"); return }
        val c = clips[slot]
        c.name = d.curTitle.ifEmpty { d.name }; c.beats = beats; c.srcBpm = d.bpm; c.filled = true
        io.launch {
            try { if (NativeEngine.saveSwap(slot, File(dir, "$slot.pcm").absolutePath)) writeMeta(slot) } catch (_: Exception) {}
        }
        toast("Vocal saved to page ${slot / PER_PAGE + 1}, pad ${slot % PER_PAGE + 1}")
    }

    /** Long-press on a filled pad: removes the vocal for good (memory, files, and any deck that is using it). */
    fun erase(slot: Int) {
        val c = clips[slot]
        if (!c.filled) return
        for (dk in decks) if (dk.swapSlot == slot) dk.swapSlot = -1
        NativeEngine.clearSwap(slot)                       // also switches the swap off on any deck that was playing it
        c.filled = false; c.name = ""; c.beats = 0f; c.srcBpm = 0f
        io.launch { try { File(dir, "$slot.pcm").delete(); File(dir, "$slot.json").delete() } catch (_: Exception) {} }
        toast("Pad ${slot % PER_PAGE + 1} on page ${slot / PER_PAGE + 1} erased")
    }

    fun toggle(d: DeckState, slot: Int) {
        if (!d.loaded || !d.stemsReady) { toast("Swap needs a prepared song with stems on this deck"); return }
        if (d.swapSlot == slot) { d.swapSlot = -1; NativeEngine.setSwap(d.id, -1, 0.0, 0.0); return }
        if (d.bpm <= 0f) { toast("This song has no BPM yet"); return }
        val c = clips[slot]
        val period = 60.0 / d.bpm
        // The clip starts on the loop start, or on the next beat of the deck's grid, and then repeats every clip length.
        val anchor = if (d.loopActive && d.loopIn >= 0) d.loopIn
        else if (!d.playing) d.pos()                     // stopped: it sounds right away on its own, and restarts in time with the deck when you press play
        else d.beatOffset + ceil((d.pos() - d.beatOffset) / period - 0.05) * period
        NativeEngine.setSwap(d.id, slot, anchor, c.beats * period)
        d.swapSlot = slot
    }

    var decks: List<DeckState> = emptyList()
}
