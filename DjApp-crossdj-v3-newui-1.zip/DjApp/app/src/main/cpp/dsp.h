// Audio building blocks used by engine.cpp. Pure C++ (no Android), so they can be tested on a PC (see tools/dsp_test.cpp).
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>

namespace dsp {

// ---------------------------------------------------------------- 4-point cubic (Catmull-Rom) interpolation
// weights for the four samples x[-1], x[0], x[1], x[2] around a fractional position f in [0,1).
// Linear interpolation (2 samples) acts as a low-pass filter whose strength depends on f: at f = 0.5 it already loses
// 2.4 dB at 10 kHz and everything near Nyquist, and while scratching or resampling f is almost never 0. Cubic keeps the highs.
inline void cubicW(float f, float &w0, float &w1, float &w2, float &w3) {
    const float f2 = f * f, f3 = f2 * f;
    w0 = -0.5f * f3 + f2 - 0.5f * f;
    w1 = 1.5f * f3 - 2.5f * f2 + 1.f;
    w2 = -1.5f * f3 + 2.f * f2 + 0.5f * f;
    w3 = 0.5f * f3 - 0.5f * f2;
}

// ---------------------------------------------------------------- 3-band EQ (bass / mid / treble), -26 .. +12 dB
// Differences from the old version: biquads run in double precision (a 110 Hz shelf has poles very close to 1, where 32-bit
// float rounding adds noise), and a boost automatically lowers the level in front of the filters ("headroom"), because a
// +12 dB bass boost on a modern loud track otherwise goes straight into clipping.
struct Eq {
    struct Bq { double b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1[2] = {0, 0}, z2[2] = {0, 0}; };
    Bq bq[3];
    float cur[3] = {0, 0, 0};              // smoothed gain in dB (smoothing avoids zipper noise while a fader moves)
    float applied[3] = {1e9f, 1e9f, 1e9f};
    float pre = 1.f;                       // headroom gain currently applied in front of the filters
    float headroom = 0.5f;                 // dB of level removed per dB of boost (0.5: +12 dB boost = -6 dB in front)

    static void coefs(Bq &q, int band, float dbf, float srf) {
        const double db = dbf, sr = srf, pi = 3.14159265358979323846;
        const double A = std::pow(10.0, db / 40.0);
        const double f = band == 0 ? 110.0 : band == 1 ? 1000.0 : 5000.0;
        const double w0 = 2.0 * pi * f / sr, cs = std::cos(w0), sn = std::sin(w0);
        double b0, b1, b2, a0, a1, a2;
        if (band == 1) {                                   // peaking, Q 0.7
            const double al = sn / (2.0 * 0.7);
            b0 = 1 + al * A; b1 = -2 * cs; b2 = 1 - al * A; a0 = 1 + al / A; a1 = -2 * cs; a2 = 1 - al / A;
        } else {
            const double al = sn / 2.0 * 1.41421356237, t = 2.0 * std::sqrt(A) * al;
            if (band == 0) {                               // low shelf
                b0 = A * ((A + 1) - (A - 1) * cs + t); b1 = 2 * A * ((A - 1) - (A + 1) * cs); b2 = A * ((A + 1) - (A - 1) * cs - t);
                a0 = (A + 1) + (A - 1) * cs + t; a1 = -2 * ((A - 1) + (A + 1) * cs); a2 = (A + 1) + (A - 1) * cs - t;
            } else {                                       // high shelf
                b0 = A * ((A + 1) + (A - 1) * cs + t); b1 = -2 * A * ((A - 1) + (A + 1) * cs); b2 = A * ((A + 1) + (A - 1) * cs - t);
                a0 = (A + 1) - (A - 1) * cs + t; a1 = 2 * ((A - 1) - (A + 1) * cs); a2 = (A + 1) - (A - 1) * cs - t;
            }
        }
        q.b0 = b0 / a0; q.b1 = b1 / a0; q.b2 = b2 / a0; q.a1 = a1 / a0; q.a2 = a2 / a0;
    }

    void process(float *l, float *r, int m, const float target[3], float sr) {
        float boost = 0.f;
        for (int b = 0; b < 3; b++) {
            cur[b] += (target[b] - cur[b]) * 0.35f;
            if (std::fabs(target[b] - cur[b]) < 0.01f) cur[b] = target[b];
            boost = std::max(boost, cur[b]);
        }
        // headroom: smooth gain change across the chunk (no zipper noise)
        const float preT = boost > 0.05f ? std::pow(10.f, -headroom * boost / 20.f) : 1.f;
        if (preT != pre || pre != 1.f) {
            for (int i = 0; i < m; i++) {
                const float g = pre + (preT - pre) * (float)(i + 1) / (float)m;
                l[i] *= g; r[i] *= g;
            }
            pre = preT;
        }
        for (int b = 0; b < 3; b++) {
            if (std::fabs(cur[b]) < 0.05f) {               // flat: bypass, no CPU
                bq[b].z1[0] = bq[b].z1[1] = bq[b].z2[0] = bq[b].z2[1] = 0; applied[b] = 1e9f; continue;
            }
            if (std::fabs(cur[b] - applied[b]) > 0.01f) { coefs(bq[b], b, cur[b], sr); applied[b] = cur[b]; }
            Bq &q = bq[b];
            for (int i = 0; i < m; i++) {
                double x = l[i], y = q.b0 * x + q.z1[0];
                q.z1[0] = q.b1 * x - q.a1 * y + q.z2[0]; q.z2[0] = q.b2 * x - q.a2 * y; l[i] = (float)y;
                x = r[i]; y = q.b0 * x + q.z1[1];
                q.z1[1] = q.b1 * x - q.a1 * y + q.z2[1]; q.z2[1] = q.b2 * x - q.a2 * y; r[i] = (float)y;
            }
        }
    }
};

// ---------------------------------------------------------------- master limiter (look-ahead, ~1 ms)
// Replaces the old per-sample tanh soft clip. A clipper reshapes every peak, which on sustained bass sounds like fuzz.
// This turns the whole signal down BEFORE the peak arrives and brings it back up slowly (80 ms), so low notes keep their
// shape. Guarantee: output never exceeds `ceilingLevel` (shown by the tests).
struct Limiter {
    static constexpr int MAXL = 256;
    static constexpr int CAP = MAXL + 2;
    int L = 48;                            // look-ahead in samples (about 1 ms)
    float ceilingLevel = 0.95f;
    float rc = 0.0003f;                    // release coefficient
    float dly[MAXL][2];
    int dp = 0;
    long long qi[CAP]; float qv[CAP];
    int qh = 0, qn = 0;
    float ma[MAXL]; double maSum = 0; int mp = 0;
    long long n = 0;
    float gPrev = 1.f;

    void init(float sr) {
        L = std::max(8, std::min(MAXL - 1, (int)(0.001f * sr + 0.5f)));
        rc = 1.f - std::exp(-1.f / (0.08f * sr));
        reset();
    }
    void reset() {
        std::memset(dly, 0, sizeof dly);
        dp = 0; qh = 0; qn = 0; n = 0; gPrev = 1.f; mp = 0;
        for (int i = 0; i < MAXL; i++) ma[i] = 1.f;
        maSum = (double)L;
    }
    // interleaved stereo, in place
    void process(float *io, int frames) {
        const int D = L - 1;               // delay of the audio = look-ahead - 1
        for (int i = 0; i < frames; i++) {
            const float x0 = io[2 * i], x1 = io[2 * i + 1];
            const float peak = std::max(std::fabs(x0), std::fabs(x1));
            const float gt = peak > ceilingLevel ? ceilingLevel / peak : 1.f;
            // sliding minimum of gt over the last L samples (monotonic queue)
            while (qn > 0) {
                const int back = (qh + qn - 1) % CAP;
                if (qv[back] >= gt) qn--; else break;
            }
            const int pos = (qh + qn) % CAP;
            qi[pos] = n; qv[pos] = gt; qn++;
            while (qn > 0 && qi[qh] <= n - L) { qh = (qh + 1) % CAP; qn--; }
            const float mn = qv[qh];
            // moving average of that minimum over L samples: smooth attack that is finished when the peak arrives
            maSum += (double)mn - (double)ma[mp]; ma[mp] = mn; mp = (mp + 1) % L;
            const float gAvg = (float)(maSum / (double)L);
            // the gain may fall at once (it is already smooth) but only rises slowly
            float g = std::min(gAvg, gPrev + (1.f - gPrev) * rc);
            gPrev = g;
            // delayed audio
            float o0 = dly[dp][0], o1 = dly[dp][1];
            dly[dp][0] = x0; dly[dp][1] = x1;
            if (++dp >= D) dp = 0;
            io[2 * i] = std::max(-1.f, std::min(1.f, o0 * g));
            io[2 * i + 1] = std::max(-1.f, std::min(1.f, o1 * g));
            n++;
        }
    }
};

// ---------------------------------------------------------------- click smoother for position jumps (seek, cue, hot cue)
// When the playhead jumps, the output would step from the last old sample to the first new one: a click. We keep the output
// continuous and let the difference die away over ~4 ms, which turns the click into a soft thud nobody notices.
struct Declick {
    static constexpr int J = 192;
    float dL = 0, dR = 0, lastL = 0, lastR = 0;
    int left = 0;
    bool pending = false;
    void trigger() { pending = true; }
    void process(float *l, float *r, int m) {
        if (m <= 0) return;
        if (pending) { dL = lastL - l[0]; dR = lastR - r[0]; left = J; pending = false; }
        for (int i = 0; i < m && left > 0; i++, left--) {
            const float w = (float)left / (float)J;
            l[i] += dL * w; r[i] += dR * w;
        }
        lastL = l[m - 1]; lastR = r[m - 1];
    }
};

}  // namespace dsp
