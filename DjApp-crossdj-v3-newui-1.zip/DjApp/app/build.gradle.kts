import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.djapp"
    compileSdk = 34
    ndkVersion = "26.1.10909125"
    defaultConfig {
        applicationId = "com.example.djapp"
        minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "0.1"
        externalNativeBuild { cmake { cppFlags += "-std=c++17"; arguments += "-DANDROID_STL=c++_shared" } }
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    buildFeatures { compose = true; prefab = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs { pickFirsts += "**/libc++_shared.so" } }
    // Keep the bundled AI model uncompressed: faster build, and the app can read its exact size.
    androidResources { noCompress += listOf("onnx", "mp3", "ogg") }
}

// ---- Bundle the SCNet model so AI stems work fully offline ------------------------------------------------
// The ~45 MB int8 ONNX model (SCNet-large, MIT licence, audiojs/scnet-large on Hugging Face) is downloaded ONCE at build time into
// src/main/assets (git-ignored) and packed into the APK. The phone never needs internet. To use a copy you already
// have, just put it at that path with that name.
val scnetModel = layout.projectDirectory.file("src/main/assets/scnet-large.int8.onnx").asFile
val scnetSha256 = "b2dc586a1e0e6c0afe4915e9057ea29111397b7bbf589edc3d85de91de79cd72"
fun sha256Of(f: File): String {
    val md = MessageDigest.getInstance("SHA-256")
    f.inputStream().use { i ->
        val b = ByteArray(1 shl 16)
        while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) }
    }
    return md.digest().joinToString("") { "%02x".format(it) }
}
val fetchScnetModel by tasks.registering {
    description = "Downloads the SCNet ONNX model into src/main/assets so it is packed into the APK."
    outputs.file(scnetModel)
    onlyIf { !scnetModel.exists() || scnetModel.length() < 20_000_000L }
    doLast {
        scnetModel.parentFile.mkdirs()
        val part = File(scnetModel.parentFile, scnetModel.name + ".part")
        var lastError: Exception? = null
        for (attempt in 1..3) {
            try {
                val conn = URL("https://huggingface.co/audiojs/scnet-large/resolve/main/scnet-large.int8.onnx")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 30_000; conn.readTimeout = 60_000; conn.instanceFollowRedirects = true
                conn.inputStream.use { input -> part.outputStream().use { out -> input.copyTo(out) } }
                check(part.length() > 20_000_000L) { "downloaded file is too small (${part.length()} bytes)" }
                val got = sha256Of(part)
                check(got == scnetSha256) { "checksum mismatch (got $got)" }
                scnetModel.delete()
                check(part.renameTo(scnetModel)) { "could not move model into place" }
                lastError = null
                break
            } catch (e: Exception) {
                lastError = e
                part.delete()
                println("SCNet model download attempt $attempt failed: ${e.message}")
            }
        }
        lastError?.let { throw GradleException("Could not download the SCNet model: ${it.message}", it) }
        println("SCNet model ready: ${scnetModel.length()} bytes, sha256=" + sha256Of(scnetModel))
    }
}
tasks.named("preBuild") { dependsOn(fetchScnetModel) }
dependencies {
    implementation("com.google.oboe:oboe:1.9.0")
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.19.2")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.0")
}
