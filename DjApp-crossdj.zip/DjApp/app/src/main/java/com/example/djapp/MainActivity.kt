package com.example.djapp

import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28)
            window.attributes.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
        CrashLog.install(this)
        AppSettings.load(this)
        if (AppSettings.keepAwake) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (!NativeEngine.start()) Toast.makeText(this, "Could not start audio output", Toast.LENGTH_LONG).show()
        AppSettings.applyToEngine()
        Sampler.init(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { DjScreen() } }
    }
    override fun onDestroy() { VideoMixer.releaseAll(); NativeEngine.stop(); super.onDestroy() }
}

@Composable
fun DjScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val decks = remember { listOf(DeckState(0, PurpleDeck, PurpleDark), DeckState(1, TealDeck, TealDark)) }
    var panel by remember { mutableStateOf(Panel.None) }
    var cross by remember { mutableFloatStateOf(0.5f) }
    var recording by remember { mutableStateOf(false) }
    var recSecs by remember { mutableIntStateOf(0) }
    var recPath by remember { mutableStateOf("") }
    val level = remember { mutableFloatStateOf(0f) }

    val pickA = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) decks[0].load(ctx, scope, uri) }
    val pickB = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) decks[1].load(ctx, scope, uri) }
    val videoA = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) VideoMixer.layers[0].load(ctx, uri, lock = false) }
    val videoB = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) VideoMixer.layers[1].load(ctx, uri, lock = false) }

    LaunchedEffect(Unit) {
        while (true) {
            for (d in decks) { d.playing = NativeEngine.isPlaying(d.id); d.posSec = NativeEngine.getPosition(d.id) }
            VideoMixer.tick(decks)
            delay(200)
        }
    }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { }; level.floatValue = NativeEngine.getLevel() } }
    LaunchedEffect(recording) { if (recording) { recSecs = 0; while (true) { delay(1000); recSecs++ } } }
    BackHandler(panel != Panel.None) { panel = Panel.None }

    fun toggleRec() {
        if (recording) {
            NativeEngine.stopRecording(); recording = false
            Toast.makeText(ctx, "Saved: $recPath", Toast.LENGTH_LONG).show()
        } else {
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: ctx.filesDir
            val f = File(dir, "DJ_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".wav")
            if (NativeEngine.startRecording(f.absolutePath)) { recPath = f.absolutePath; recording = true }
            else Toast.makeText(ctx, "Could not start recording", Toast.LENGTH_SHORT).show()
        }
    }
    fun sync(me: DeckState, other: DeckState) {
        if (!me.syncTo(other)) Toast.makeText(ctx, "BPM not detected yet", Toast.LENGTH_SHORT).show()
    }
    fun toggle(p: Panel) { panel = if (panel == p) Panel.None else p }
    fun loadFromLibrary(deck: Int, uri: android.net.Uri) {
        // A mis-tap in the library must never cut a playing deck.
        if (decks[deck].playing) Toast.makeText(ctx, "Pause deck ${if (deck == 0) "A" else "B"} first", Toast.LENGTH_SHORT).show()
        else decks[deck].load(ctx, scope, uri)
    }

    Box(Modifier.fillMaxSize().background(Color.Black).windowInsetsPadding(WindowInsets.displayCutout)) {
        Column(Modifier.fillMaxSize().background(BgDark)) {
            Box(Modifier.weight(12f).fillMaxWidth()) {
                TopBar(decks, level, recording, recSecs, { panel = Panel.Library }, { panel = Panel.Library }, ::toggleRec)
            }
            HLine()
            Box(Modifier.weight(74f).fillMaxWidth()) {
                Column(Modifier.fillMaxSize()) {
                    Box(Modifier.weight(46f).fillMaxWidth()) { WaveSection(decks) }
                    HLine()
                    Box(Modifier.weight(54f).fillMaxWidth()) { MiddleSection(decks, level, panel, ::toggle) }
                }
                if (panel != Panel.None) PanelHost(
                    panel, decks, ::loadFromLibrary,
                    { d -> (if (d == 0) pickA else pickB).launch(arrayOf("audio/*", "video/*")) },
                    { d -> (if (d == 0) videoA else videoB).launch(arrayOf("video/*")) },
                    // The sampler stays a low strip (waveforms visible) until the sample browser is opened.
                    modifier = if (panel == Panel.Sampler && !Sampler.browse)
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().fillMaxHeight(0.58f)
                    else Modifier.fillMaxSize()
                ) { panel = Panel.None }
            }
            HLine()
            Box(Modifier.weight(14f).fillMaxWidth()) {
                BottomBar(decks, cross, { cross = it; NativeEngine.setCrossfader(it); VideoMixer.audioCross = it }, ::sync)
            }
        }
        CrashLog.last?.let { msg ->
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.94f)).clickable { }.padding(20.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("The app closed unexpectedly last time. Please screenshot this and send it to the developer:", color = Color.White, fontSize = 12.sp)
                    Text(msg, color = Color(0xFFFFB4A9), fontSize = 8.sp, modifier = Modifier.weight(1f))
                    PadButton("CLOSE", Modifier.width(100.dp), active = true) { CrashLog.dismiss() }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ waveforms (Serato-style)
@Composable
private fun WaveSection(decks: List<DeckState>) {
    Column(Modifier.fillMaxSize()) {
        for (i in 0..1) {
            Column(Modifier.weight(1f).fillMaxWidth()) {
                ScrollingWave(decks[i], if (i == 0) "A" else "B", Modifier.weight(3f).fillMaxWidth())
                OverviewWave(decks[i], Modifier.weight(1f).fillMaxWidth())
            }
            if (i == 0) HLine()
        }
    }
}

@Composable private fun HLine() = Box(Modifier.fillMaxWidth().height(1.dp).background(Color.Black.copy(alpha = 0.6f)))

// ------------------------------------------------------------------ top bar
@Composable
private fun TopBar(
    decks: List<DeckState>, level: State<Float>, recording: Boolean, recSecs: Int,
    loadA: () -> Unit, loadB: () -> Unit, onRec: () -> Unit
) {
    Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        CircleIconButton(Modifier.fillMaxHeight(0.86f).aspectRatio(1f), loadA, borderColor = Color.White) {
            PlusIcon(PurpleDeck, Modifier.fillMaxSize(0.42f))
        }
        DeckTitle(decks[0], Modifier.weight(1f))
        Row(Modifier.width(124.dp).fillMaxHeight(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(28.dp).clip(CircleShape).background(Color.Black), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(22.dp, 20.dp)) {
                    val lv = level.value.coerceIn(0f, 1f)
                    val hs = listOf(0.55f, 0.8f, 1f, 0.8f, 0.55f)
                    val bw = 2.2.dp.toPx(); val gap = (size.width - bw * 5) / 4
                    for (i in 0..4) {
                        val h = size.height * (0.18f + 0.82f * lv * hs[i])
                        drawRect(Color.White, Offset(i * (bw + gap), (size.height - h) / 2), Size(bw, h))
                    }
                }
            }
            val blink by rememberInfiniteTransition(label = "rec").animateFloat(
                1f, 0.25f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label = "recAlpha"
            )
            Row(Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onRec).padding(horizontal = 6.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(15.dp).clip(CircleShape).background(Color(0xFFB00F0F).copy(alpha = if (recording) blink else 1f)))
                Spacer(Modifier.width(5.dp))
                Text(
                    if (recording) "%d:%02d".format(recSecs / 60, recSecs % 60) else "REC",
                    color = Color.White, fontSize = 13.sp
                )
            }
        }
        DeckTitle(decks[1], Modifier.weight(1f))
        CircleIconButton(Modifier.fillMaxHeight(0.86f).aspectRatio(1f), loadB, borderColor = Color.White) {
            PlusIcon(TealDeck, Modifier.fillMaxSize(0.42f))
        }
    }
}

@Composable
private fun DeckTitle(d: DeckState, modifier: Modifier) {
    val sub = buildList {
        if (d.loading) add("decoding…")
        else if (d.loaded) {
            add(if (d.bpm > 0f) "%.1f BPM".format(d.bpm) else "analysing BPM…")
            if (d.key.isNotEmpty()) add(d.key)
            when {
                d.stemProg in 0f..1f -> add(if (AppSettings.modelStatus.isNotEmpty()) AppSettings.modelStatus else "stems ${(d.stemProg * 100).toInt()}%")
                d.stemsReady -> add("stems ready")
                else -> {}
            }
        } else add("tap + to load")
    }.joinToString("  ·  ")
    Column(modifier.padding(horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(
            d.name.uppercase(), color = TextGray, fontSize = 14.sp, fontWeight = FontWeight.Light,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
        )
        Text(sub, color = d.accent.copy(alpha = 0.9f), fontSize = 9.sp, maxLines = 1)
    }
}

// ------------------------------------------------------------------ middle: tempo | platter | controls | platter | tempo
@Composable
private fun MiddleSection(decks: List<DeckState>, level: State<Float>, panel: Panel, toggle: (Panel) -> Unit) {
    Row(Modifier.fillMaxSize()) {
        TempoColumn(decks[0], Modifier.weight(7f).fillMaxHeight()) {
            CircleIconButton(Modifier.size(32.dp), { toggle(Panel.Stems) }, active = panel == Panel.Stems, accent = PurpleLight) {
                WaveIcon(Color.White, Modifier.size(18.dp))
            }
        }
        Box(Modifier.weight(31f).fillMaxHeight()) { Platter(decks[0], PurpleDeck, PurpleDark) }
        CenterColumn(decks, level, panel, toggle, Modifier.weight(24f).fillMaxHeight())
        Box(Modifier.weight(31f).fillMaxHeight()) { Platter(decks[1], TealDeck, TealDark) }
        TempoColumn(decks[1], Modifier.weight(7f).fillMaxHeight()) {
            CircleIconButton(Modifier.size(32.dp), { toggle(Panel.Settings) }, active = panel == Panel.Settings, accent = TealDeck) {
                GearIcon(Color.White, Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun GearIcon(color: Color, modifier: Modifier = Modifier) = Canvas(modifier) {
    val c = center; val r = size.minDimension * 0.28f
    for (i in 0 until 8) {
        val a = Math.toRadians(i * 45.0)
        val dx = Math.cos(a).toFloat(); val dy = Math.sin(a).toFloat()
        drawLine(color, c + Offset(dx * r, dy * r), c + Offset(dx * r * 1.65f, dy * r * 1.65f), r * 0.62f, StrokeCap.Butt)
    }
    drawCircle(color, r * 1.25f, c); drawCircle(BgDark, r * 0.55f, c)
}

@Composable
private fun TempoColumn(deck: DeckState, modifier: Modifier, icon: @Composable () -> Unit) {
    Column(modifier.padding(vertical = 8.dp, horizontal = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        icon()
        TempoSlider(deck, Modifier.weight(1f).fillMaxWidth())
        Text("TEMPO", color = TextGray, fontSize = 9.sp)
    }
}

@Composable
private fun TempoSlider(deck: DeckState, modifier: Modifier = Modifier) {
    val range = AppSettings.tempoRange
    BoxWithConstraints(modifier.padding(vertical = 17.dp)) {
        val h = maxHeight
        val frac = (deck.tempoPct / range / 2f + 0.5f).coerceIn(0f, 1f)
        Box(Modifier.fillMaxSize().faderTouch(true) { f ->
            var p = (f - 0.5f) * 2f * range
            if (abs(p) < range * 0.03f) p = 0f          // detent at 0 %
            deck.applyTempo(p)
        })
        Canvas(Modifier.fillMaxSize()) {
            val tw = 17.dp.toPx()
            drawRoundRect(Color(0xFF111214), Offset((size.width - tw) / 2, -4.dp.toPx()), Size(tw, size.height + 8.dp.toPx()), CornerRadius(tw / 2))
            drawCircle(deck.accent, 3.5.dp.toPx(), Offset(if (deck.id == 0) 0f else size.width, size.height / 2))
        }
        val pct = deck.tempoPct * 100f
        Box(
            Modifier.align(Alignment.TopCenter).offset(y = h * (1f - frac) - 15.dp).fillMaxWidth(0.98f).height(30.dp)
                .clip(RoundedCornerShape(4.dp)).background(Color(0xFFE6E6E8)),
            contentAlignment = Alignment.Center
        ) {
            Text(if (abs(pct) < 0.05f) "0.0 %" else "%+.1f %%".format(pct), color = Color(0xFF666870), fontSize = 9.sp, maxLines = 1)
        }
    }
}

// ------------------------------------------------------------------ platter with scratch
@Composable
private fun Platter(deck: DeckState, color: Color, inner: Color) {
    var angle by remember { mutableFloatStateOf(0f) }
    var progress by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(deck) {
        while (true) {
            withFrameNanos { }
            val p = NativeEngine.getPosition(deck.id)
            angle = ((p * 200.0) % 360.0).toFloat()          // 200 deg/s ~ 33 rpm
            progress = if (deck.duration > 0) (p / deck.duration).toFloat().coerceIn(0f, 1f) else 0f
        }
    }
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val dia = minOf(maxWidth, maxHeight)
        Box(
            Modifier.size(dia).pointerInput(deck) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val cx = size.width / 2f; val cy = size.height / 2f
                    fun ang(p: Offset) = Math.toDegrees(atan2((p.y - cy).toDouble(), (p.x - cx).toDouble())).toFloat()
                    var last = ang(down.position); var lastT = down.uptimeMillis
                    var engaged = false; var travelled = 0f; var vel = 0f
                    while (true) {
                        val c = awaitPointerEvent().changes.firstOrNull() ?: break
                        if (!c.pressed) break
                        val a = ang(c.position)
                        var da = a - last
                        if (da > 180f) da -= 360f; if (da < -180f) da += 360f
                        val dt = (c.uptimeMillis - lastT).coerceAtLeast(1L) / 1000f
                        travelled += abs(da)
                        if (travelled > 3f) engaged = true      // plain taps don't stop the music
                        if (engaged) {
                            vel = vel * 0.5f + (da / 200f / dt) * 0.5f
                            NativeEngine.setJog(deck.id, true, vel.coerceIn(-8f, 8f))
                        }
                        last = a; lastT = c.uptimeMillis; c.consume()
                    }
                    if (engaged) NativeEngine.setJog(deck.id, false, 0f)
                }
            },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val r = size.minDimension / 2; val c = center
                drawCircle(color, r, c)
                for (k in listOf(0.55f, 0.66f, 0.77f, 0.88f)) drawCircle(Color.Black.copy(alpha = 0.10f), r * k, c, style = Stroke(1.dp.toPx()))
                if (progress > 0f) drawArc(
                    Color.White.copy(alpha = 0.6f), -90f, progress * 360f, false,
                    topLeft = c - Offset(r * 0.94f, r * 0.94f), size = Size(r * 1.88f, r * 1.88f),
                    style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
                )
                drawCircle(Color.Black, r, c, style = Stroke(2.dp.toPx()))
                drawCircle(inner, r * 0.355f, c)
                rotate(angle, pivot = c) {
                    // small tick on the label so you can see the platter turn
                    drawRect(Color.White, c + Offset(-r * 0.012f, -r * 0.355f), Size(r * 0.024f, r * 0.07f))
                }
            }
            Text(
                "MAXXIDODJ", color = Color.White, fontSize = (dia.value * 0.075f).sp, fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp, maxLines = 1,
                modifier = Modifier.graphicsLayer { rotationZ = angle }
            )
            Text(
                if (deck.loaded) "%d:%02d / %d:%02d".format(deck.posSec.toInt() / 60, deck.posSec.toInt() % 60, deck.duration.toInt() / 60, deck.duration.toInt() % 60) else "",
                color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = dia * 0.12f)
            )
            val badge = buildString {
                if (deck.loopActive) append("LOOP ")
                if (deck.filter != 0f) append("FLT ")
                if (deck.reverb > 0f) append("REV ")
                if (deck.phaser > 0f) append("PHS ")
            }.trim()
            if (badge.isNotEmpty()) Text(
                badge, color = Color.White.copy(alpha = 0.85f), fontSize = 10.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = dia * 0.1f)
            )
        }
    }
}

// ------------------------------------------------------------------ centre column
@Composable
private fun CenterColumn(decks: List<DeckState>, level: State<Float>, panel: Panel, toggle: (Panel) -> Unit, modifier: Modifier) {
    Column(modifier.padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        val bs = Modifier.size(32.dp)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            CircleIconButton(bs, { toggle(Panel.Loop) }, active = panel == Panel.Loop || decks.any { it.loopActive }) {
                Text("↻", color = Color.White, fontSize = 17.sp)
            }
            CircleIconButton(bs, { toggle(Panel.Mixer) }, active = panel == Panel.Mixer) {
                MixerIcon(Color.White, Modifier.size(16.dp))
            }
            CircleIconButton(bs, { toggle(Panel.Fx) }, active = panel == Panel.Fx || decks.any { it.reverb > 0f || it.phaser > 0f }) {
                Text("FX", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic)
            }
            CircleIconButton(bs, { toggle(Panel.Library) }, active = panel == Panel.Library || Library.analysing) {
                Text("LIB", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        Box(Modifier.weight(1f).padding(vertical = 10.dp).width(28.dp).background(Color.Black)) {
            Canvas(Modifier.fillMaxSize()) {
                val lv = level.value.coerceIn(0f, 1f)
                val top = size.height * (1f - lv)
                drawRect(
                    Brush.verticalGradient(listOf(Color(0xFFE53935), Color(0xFFFFC107), TealDeck), 0f, size.height),
                    Offset(0f, top), Size(size.width, size.height - top)
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            CircleIconButton(bs, { toggle(Panel.Pads) }, active = panel == Panel.Pads) {
                GridIcon(Color.White, Modifier.size(15.dp))
            }
            CircleIconButton(bs, { toggle(Panel.Sampler) }, active = panel == Panel.Sampler || Sampler.pads.any { it.playing }, accent = PurpleLight) {
                Text("SMP", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            CircleIconButton(bs, { toggle(Panel.Video) }, active = panel == Panel.Video || VideoMixer.layers.any { it.ready }, accent = TealDeck) {
                Text("VID", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ------------------------------------------------------------------ bottom: transport | crossfader | transport
@Composable
private fun BottomBar(decks: List<DeckState>, cross: Float, onCross: (Float) -> Unit, onSync: (DeckState, DeckState) -> Unit) {
    val a = decks[0]; val b = decks[1]
    Row(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.weight(31f).fillMaxHeight(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CueButton(a, Modifier.weight(1f))
            PlayButton(a, PurpleLight, PurpleLight, Modifier.weight(1f))
            SyncButton(Modifier.weight(1f)) { onSync(a, b) }
        }
        Crossfader(cross, onCross, Modifier.weight(23f).fillMaxHeight())
        Row(Modifier.weight(31f).fillMaxHeight(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SyncButton(Modifier.weight(1f)) { onSync(b, a) }
            CueButton(b, Modifier.weight(1f))
            PlayButton(b, TealDeck, Color(0xFF7FE3C9), Modifier.weight(1f))
        }
    }
}

@Composable
private fun GrayButton(label: String, modifier: Modifier, touch: Modifier) {
    Box(
        modifier.fillMaxHeight().clip(RoundedCornerShape(7.dp)).background(Brush.verticalGradient(listOf(BtnTop, BtnBottom))).then(touch),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color(0xFFEDEDEF), fontSize = 17.sp, fontWeight = FontWeight.Light, letterSpacing = 0.5.sp) }
}

@Composable
private fun CueButton(d: DeckState, modifier: Modifier) =
    GrayButton("CUE", modifier, Modifier.pressable({ d.cueDown() }, { d.cueUp() }))

@Composable
private fun SyncButton(modifier: Modifier, onClick: () -> Unit) =
    GrayButton("SYNC", modifier, Modifier.clickable(onClick = onClick))

@Composable
private fun PlayButton(d: DeckState, c1: Color, c2: Color, modifier: Modifier) {
    Box(
        modifier.fillMaxHeight().clip(RoundedCornerShape(7.dp))
            .background(Brush.horizontalGradient(listOf(c1, c2, c1))).clickable { d.togglePlay() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(22.dp)) {
            if (d.playing) {
                val w = size.width * 0.28f
                drawRect(Color.Black, Offset(size.width * 0.1f, 0f), Size(w, size.height))
                drawRect(Color.Black, Offset(size.width * 0.62f, 0f), Size(w, size.height))
            } else {
                drawPath(Path().apply { moveTo(size.width * 0.12f, 0f); lineTo(size.width, size.height / 2); lineTo(size.width * 0.12f, size.height); close() }, Color.Black)
            }
        }
    }
}

@Composable
private fun Crossfader(value: Float, onChange: (Float) -> Unit, modifier: Modifier) {
    Box(modifier.faderTouch(false) { f -> onChange(if (abs(f - 0.5f) < 0.03f) 0.5f else f) }) {
        Canvas(Modifier.fillMaxSize()) {
            val tw = 18.dp.toPx(); val th = minOf(34.dp.toPx(), size.height)
            val cy = size.height / 2; val bar = 9.dp.toPx()
            val tx = tw / 2 + (size.width - tw) * value
            drawRoundRect(Color(0xFF14161A), Offset(0f, cy - bar / 2 - 1.dp.toPx()), Size(size.width, bar + 2.dp.toPx()), CornerRadius(bar))
            drawRoundRect(PurpleDeck, Offset(1.dp.toPx(), cy - bar / 2), Size(tx - 1.dp.toPx(), bar), CornerRadius(bar / 2))
            drawRoundRect(TealDeck, Offset(tx, cy - bar / 2), Size(size.width - tx - 1.dp.toPx(), bar), CornerRadius(bar / 2))
            drawRoundRect(Color(0xFFE4E4E6), Offset(tx - tw / 2, cy - th / 2), Size(tw, th), CornerRadius(3.dp.toPx()))
            drawLine(Color(0xFF2A2D35), Offset(tx, cy - th / 2 + 2.dp.toPx()), Offset(tx, cy + th / 2 - 2.dp.toPx()), 2.dp.toPx())
        }
    }
}
