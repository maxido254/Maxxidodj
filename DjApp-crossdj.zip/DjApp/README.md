# MAXXIDODJ

Landscape 2-deck DJ app with sampler packs and video mixing (Kotlin/Compose UI + C++/Oboe audio engine).

## Build
1. Open in Android Studio (Ladybug or newer), let Gradle sync (NDK + CMake via SDK Manager).
2. Run on a real device (emulators have poor audio latency).
Cloud build: push to GitHub, Actions > Build APK > Run workflow, download `DjApp-debug-apk`.

## Screen map
| Control | What it does |
|---|---|
| purple / teal **+** | load a track onto deck A / B |
| **platter** | drag in circles to scratch; hold still to stop; ring = track progress |
| **TEMPO** fader | +/- range set in Settings (default 8 %); snaps to 0 |
| **CUE** | playing: back to cue and pause. Paused elsewhere: set cue. Hold at cue: preview |
| **SYNC** | matches tempo to the other deck (needs BPM, detected after load) |
| waveform icon (left) | **Stems**: mute / level per stem, ACAPELLA, NO VOCALS, BEATLESS |
| ↻ | **Loop**: auto-loop 1/4..16 beats, LOOP IN / LOOP OUT / EXIT / RELOOP, halve / double |
| **LIB** | **Library**: every audio file on the phone with BPM + key, sortable, load to deck A / B |
| sliders icon | **Mixer**: volume + DJ filter |
| **FX** | **Effects**: filter, reverb (+ room size), phaser (+ rate) per deck |
| grid icon | 4 **hot cues** per deck (tap set/jump, long-press clear) |
| **SMP** | **Sampler**: 8 pads x 4 banks, sample-pack folders, one-shot / hold / loop (see below) |
| **VID** | **Video mixer**: one video per deck, crossfaded on screen, fullscreen output (see below) |
| gear (right) | Settings: MIXER (tempo range, crossfader curve, master), STEMS, SAMPLER, VIDEO, DISPLAY, **CONTACT DEVELOPER** (WhatsApp) |
| **REC** | records the master output to a 16-bit WAV (app Music folder) |

## Sampler and sample packs
Tap **SMP**. The strip at the bottom shows the 8 pads of the current bank (banks 1-4). Pads fire on touch-down.
* **BROWSE > + FOLDER**: pick any folder on the phone as a *sample pack*. Sub-folders (kicks, loops, vocals...) are listed as
  filter chips. The folder permission is remembered; no storage permission needed.
* Tap a pad (it gets a white outline), then tap a file: the sample is loaded onto that pad, auditioned, and the selection
  moves to the next pad. **FILL BANK** loads the first 8 files of the current folder, **CLEAR** empties the bank.
* Pad mode (button under the banks, or Settings > SAMPLER): **ONE-SHOT**, **HOLD** (plays while pressed), **LOOP** (tap on / tap off).
* Samples are decoded (max 30 s each) into the cache and played by the native engine, mixed after the decks, so they are
  included in REC. Pad assignments and packs are restored on the next start.

## Video mixing
Tap **VID**. Each deck has a video layer; the picture is muted (all sound comes from the audio engine).
* **Video as a track**: load a video file with FILE A / FILE B (Library panel, or the + buttons). The audio is decoded as usual and
  the picture stays locked to the deck: it follows play / pause / cue / scratch position and the tempo fader.
* **Clips**: LOAD CLIP puts a separate looping video on a deck. It plays while the deck plays (or always, with PLAY WITHOUT DECK).
* **Mix**: BLEND (A * (1-x) + B * x), DIP (fade through black) or CUT, driven by the audio crossfader or a MANUAL video fader.
  With only one video loaded it simply shows that one. BRIGHT dims the output.
* **FULLSCREEN OUTPUT** shows only the mixed picture (tap to close). The video keeps running when the panel is closed.

## Settings (saved between launches)
MIXER: tempo range, crossfader curve (smooth / sharp-cut / linear), master gain. STEMS: quality. SAMPLER: pad mode, volume.
VIDEO: transition, fader source, speed follows tempo, brightness. DISPLAY: stay awake. CONTACT: WhatsApp.

## Library, BPM and key (all offline)
Tap **LIB**, allow audio access once, and the app lists the audio files on the device. **ANALYSE** works through the
tracks in the background (low priority, stop any time): it decodes ~80 s from the middle of each file and detects
**BPM** (onset autocorrelation) and **key** (chroma + Krumhansl-Schmuckler, shown as Camelot code + name, e.g. `8A Am`).
Results are cached in app storage, so each track is only analysed once (changed files are re-analysed).
Sort by title, artist, BPM, key (Camelot wheel order 1A, 1B, 2A ...) or length; tap a sort button again to flip direction.
Tracks that are not analysed yet always sit at the bottom. **A / B** load a track onto a deck (refused while that deck plays).
Loading a track also shows its key under the deck name. Key detection is an estimate: relative major/minor mix-ups are
the usual error, and neighbours on the Camelot wheel mix well anyway.

## Stems
Two separators (Settings > Stem quality, applies to the next loaded track):
* **Better** (default, `HpssSeparator`): STFT percussive/harmonic split (drums), harmonic low band (bass),
  harmonic + centre-panned mid band (vocals), remainder = other. "Other" is computed as mix minus the other
  three, so stems always sum back to the original exactly. Streams the file, low RAM. Runs on a low-priority thread.
* **Fast** (`LiteSeparator`): simple filters.
* **AI** (`DemucsSeparator`): HT-Demucs neural network via ONNX Runtime, **fully offline**. The ~166 MB model is bundled
  in the APK: the Gradle task `fetchDemucsModel` downloads it once at build time into `app/src/main/assets/`
  (git-ignored; do not commit it, GitHub rejects files over 100 MB) and the app unpacks it on first use.
  If you already have `htdemucs_fp16weights.onnx`, copy it there as `htdemucs_fp16.onnx` and no download happens.
  The app has no INTERNET permission. If the model is missing from a build, it falls back to Better.
Stem mute/level changes are ramped in the engine so there are no clicks.

## Effects (engine.cpp, per deck)
* DJ filter: one knob, low-pass to the left, high-pass to the right, 24 dB/oct.
* Phaser: 6 all-pass stages, swept sine LFO, stereo offset, feedback.
* Reverb: Freeverb (8 combs + 4 all-pass per channel), wet + room size; tail keeps ringing after pause.
* Loops: sample-accurate wrap in the audio thread.

Known gaps: tempo still changes pitch (no key lock yet); SYNC matches tempo but does not phase-align beats; video output is on the phone screen only (no external display yet).
