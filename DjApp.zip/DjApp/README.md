# DjApp

Landscape 2-deck DJ app (Kotlin/Compose UI + C++/Oboe audio engine).

## Build
1. Open in Android Studio (Ladybug or newer), let Gradle sync (NDK + CMake via SDK Manager).
2. Run on a real device (emulators have poor audio latency).
Cloud build: push to GitHub, Actions > Build APK > Run workflow, download `DjApp-debug-apk`.

## Screen map
| Control | What it does |
|---|---|
| purple / teal **+** | load a track onto deck A / B |
| **platter** | drag in circles to scratch; hold still to stop; ring = track progress |
| **TEMPO** fader | +/- range set in Settings (default 8 %); snaps to 0 |
| **CUE** | playing: back to cue and pause. Paused elsewhere: set cue. Hold at cue: preview |
| **SYNC** | matches tempo to the other deck (needs BPM, detected after load) |
| waveform icon (left) | **Stems**: mute / level per stem, ACAPELLA, NO VOCALS, BEATLESS |
| ↻ | **Loop**: auto-loop 1/4..16 beats, LOOP IN / LOOP OUT / EXIT / RELOOP, halve / double |
| sliders icon | **Mixer**: volume + DJ filter |
| **FX** | **Effects**: filter, reverb (+ room size), phaser (+ rate) per deck |
| grid icon | 4 **hot cues** per deck (tap set/jump, long-press clear) |
| gear (right) | Settings: tempo range, stem quality |
| **REC** | records the master output to a 16-bit WAV (app Music folder) |

## Stems
Two separators (Settings > Stem quality, applies to the next loaded track):
* **Better** (default, `HpssSeparator`): STFT percussive/harmonic split (drums), harmonic low band (bass),
  harmonic + centre-panned mid band (vocals), remainder = other. "Other" is computed as mix minus the other
  three, so stems always sum back to the original exactly. Streams the file, low RAM. Runs on a low-priority thread.
* **Fast** (`LiteSeparator`): simple filters.
Neither is AI. For true AI separation implement `StemSeparator` (Demucs/Spleeter) and pass it to `StemCache.prepare`.
Stem mute/level changes are ramped in the engine so there are no clicks.

## Effects (engine.cpp, per deck)
* DJ filter: one knob, low-pass to the left, high-pass to the right, 24 dB/oct.
* Phaser: 6 all-pass stages, swept sine LFO, stereo offset, feedback.
* Reverb: Freeverb (8 combs + 4 all-pass per channel), wet + room size; tail keeps ringing after pause.
* Loops: sample-accurate wrap in the audio thread.

Known gaps: tempo still changes pitch (no key lock yet); SYNC matches tempo but does not phase-align beats.
