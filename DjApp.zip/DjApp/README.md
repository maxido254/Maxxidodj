# DjApp starter
1. Open this folder in Android Studio (Ladybug or newer) and let Gradle sync. Install NDK + CMake via SDK Manager if prompted.
2. Run on a real device (emulators have poor audio latency).
3. Load a track on each deck, press Play, move the crossfader.
Cloud build (no laptop): push this folder to a GitHub repo, open Actions > Build APK > Run workflow, then download the DjApp-debug-apk artifact.
Note: tempo currently changes pitch too. Key lock (SoundTouch) comes next.
Low-end phones (e.g. itel A80): decoded audio is streamed to a cache file and memory-mapped, so a track uses almost no RAM; audio buffer auto-grows if it crackles; ARM 32/64-bit builds included.

## Stems
After loading, each deck prepares 4 stems (vocals/drums/bass/other) in the background on a low-priority thread, with a progress bar. The track plays immediately and the stems swap in seamlessly when ready. Stems are cached (newest 3 kept, ~200 MB per 5-min song).
Current separator = LiteSeparator (fast filters, NOT AI). To use real AI (Demucs/Spleeter), implement StemSeparator in Stems.kt and pass it to StemCache.prepare.
