package com.example.djapp

import android.content.Context
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Stem order used everywhere: 0 vocals, 1 drums, 2 bass, 3 other. */
val STEM_NAMES = listOf("vocals", "drums", "bass", "other")

interface StemSeparator {
    val id: String
    /** Reads interleaved stereo int16 [mix], writes vocals/drums/bass/other .pcm into [outDir]. */
    fun separate(mix: File, rate: Int, outDir: File, progress: (Float) -> Unit, cancelled: () -> Boolean): Boolean
}

private class Biquad(lowpass: Boolean, fc: Double, fs: Double) {
    private val b0: Double; private val b1: Double; private val b2: Double
    private val a1: Double; private val a2: Double
    private var z1 = 0.0; private var z2 = 0.0
    init {
        val w = 2 * Math.PI * minOf(fc, fs * 0.45) / fs
        val c = Math.cos(w); val al = Math.sin(w) / (2 * 0.7071); val a0 = 1 + al
        if (lowpass) { b0 = (1 - c) / 2 / a0; b1 = (1 - c) / a0 } else { b0 = (1 + c) / 2 / a0; b1 = -(1 + c) / a0 }
        b2 = b0; a1 = -2 * c / a0; a2 = (1 - al) / a0
    }
    fun p(x: Double): Double { val y = b0 * x + z1; z1 = b1 * x - a1 * y + z2; z2 = b2 * x - a2 * y; return y }
}

/**
 * FAST mode: cheap filter-based split that runs in seconds even on budget CPUs.
 * Bass = <150 Hz, Vocals = centre-panned mids, Drums = highs, Other = the rest.
 * The 4 stems always add back up to the original. It is NOT AI separation.
 */
class LiteSeparator : StemSeparator {
    override val id = "lite"

    override fun separate(mix: File, rate: Int, outDir: File, progress: (Float) -> Unit, cancelled: () -> Boolean): Boolean {
        val fs = rate.toDouble()
        val bassL1 = Biquad(true, 150.0, fs); val bassL2 = Biquad(true, 150.0, fs)
        val bassR1 = Biquad(true, 150.0, fs); val bassR2 = Biquad(true, 150.0, fs)
        val vocHP = Biquad(false, 200.0, fs); val vocLP = Biquad(true, 4000.0, fs)
        val drumL = Biquad(false, 4500.0, fs); val drumR = Biquad(false, 4500.0, fs)

        val frames = 16384
        val inBuf = ByteArray(frames * 4)
        val outBytes = Array(4) { ByteArray(frames * 4) }
        val outShorts = Array(4) { ByteBuffer.wrap(outBytes[it]).order(ByteOrder.nativeOrder()).asShortBuffer() }
        val total = mix.length().coerceAtLeast(1); var done = 0L
        val outs = STEM_NAMES.map { BufferedOutputStream(File(outDir, "$it.pcm").outputStream(), 64 * 1024) }
        try {
            FileInputStream(mix).use { inp ->
                while (true) {
                    if (cancelled()) return false
                    val n = readFully(inp, inBuf)
                    if (n < 4) break
                    val fr = n / 4
                    val sb = ByteBuffer.wrap(inBuf, 0, fr * 4).order(ByteOrder.nativeOrder()).asShortBuffer()
                    for (i in 0 until fr) {
                        val l = sb.get(2 * i).toDouble(); val r = sb.get(2 * i + 1).toDouble()
                        val bl = bassL2.p(bassL1.p(l)); val br = bassR2.p(bassR1.p(r))
                        val rl = l - bl; val rr = r - br
                        val vc = vocLP.p(vocHP.p((rl + rr) * 0.5))
                        val dl = drumL.p(rl); val dr = drumR.p(rr)
                        put(outShorts[0], i, vc, vc)
                        put(outShorts[1], i, dl, dr)
                        put(outShorts[2], i, bl, br)
                        put(outShorts[3], i, rl - vc - dl, rr - vc - dr)
                    }
                    for (s in 0 until 4) outs[s].write(outBytes[s], 0, fr * 4)
                    done += n; progress((done.toFloat() / total).coerceAtMost(1f))
                }
            }
        } finally { outs.forEach { it.close() } }
        return true
    }

    private fun put(b: java.nio.ShortBuffer, i: Int, l: Double, r: Double) {
        b.put(2 * i, l.coerceIn(-32768.0, 32767.0).toInt().toShort())
        b.put(2 * i + 1, r.coerceIn(-32768.0, 32767.0).toInt().toShort())
    }

    private fun readFully(inp: InputStream, buf: ByteArray): Int {
        var t = 0
        while (t < buf.size) { val n = inp.read(buf, t, buf.size - t); if (n < 0) break; t += n }
        return t
    }
}

object StemCache {
    /** Returns the 4 stem file paths (cached after the first time), or null if cancelled/failed. */
    fun prepare(ctx: Context, mix: File, rate: Int, keyBase: String,
                progress: (Float) -> Unit, cancelled: () -> Boolean,
                sep: StemSeparator = LiteSeparator()): Array<String>? {
        val root = File(ctx.cacheDir, "stems").apply { mkdirs() }
        val dir = File(root, "${keyBase}_${mix.length()}_${sep.id}")
        if (!ready(dir)) {
            val tmp = File(root, dir.name + ".tmp"); tmp.deleteRecursively(); tmp.mkdirs()
            if (!sep.separate(mix, rate, tmp, progress, cancelled)) { tmp.deleteRecursively(); return null }
            dir.deleteRecursively()
            if (!tmp.renameTo(dir)) return null
        }
        dir.setLastModified(System.currentTimeMillis())
        prune(root, 3)
        return STEM_NAMES.map { File(dir, "$it.pcm").absolutePath }.toTypedArray()
    }

    private fun ready(dir: File) = dir.isDirectory && STEM_NAMES.all { File(dir, "$it.pcm").length() > 0 }

    /** Stems are big (~200 MB per 5 min song), so keep only the newest few. */
    private fun prune(root: File, keep: Int) {
        root.listFiles { f -> f.isDirectory && !f.name.endsWith(".tmp") }
            ?.sortedByDescending { it.lastModified() }?.drop(keep)?.forEach { it.deleteRecursively() }
    }
}
