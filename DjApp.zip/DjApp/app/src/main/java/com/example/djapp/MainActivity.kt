package com.example.djapp

import android.net.Uri
import android.os.Bundle
import android.os.Process
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import java.io.File
import java.util.concurrent.Executors

/** One low-priority thread for stem prep: decks queue up and the audio thread is never starved. */
private val prepDispatcher = Executors.newSingleThreadExecutor { r ->
    Thread({ Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND); r.run() }, "stem-prep")
}.asCoroutineDispatcher()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NativeEngine.start()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) { Mixer() } } }
    }
    override fun onDestroy() { NativeEngine.stop(); super.onDestroy() }
}

@Composable
fun Mixer() {
    var cross by remember { mutableFloatStateOf(0.5f) }
    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        DeckPanel(0, "Deck A")
        DeckPanel(1, "Deck B")
        Text("Crossfader  A ◄──► B")
        Slider(cross, { cross = it; NativeEngine.setCrossfader(it) })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeckPanel(id: Int, title: String) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("No track") }
    var loading by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var vol by remember { mutableFloatStateOf(1f) }
    var tempo by remember { mutableFloatStateOf(1f) }
    var pos by remember { mutableDoubleStateOf(0.0) }
    var prog by remember { mutableFloatStateOf(-1f) }        // -1 none, 0..1 preparing, 2 ready
    val on = remember { mutableStateListOf(true, true, true, true) }
    var prepJob by remember { mutableStateOf<Job?>(null) }
    var curMix by remember { mutableStateOf<File?>(null) }
    val labels = listOf("Vocals", "Drums", "Bass", "Other")

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        prepJob?.cancel(); prog = -1f; for (i in 0..3) on[i] = true
        loading = true; name = "Decoding…"; playing = false
        scope.launch {
            try {
                // Unique file per load: never overwrite a file the engine has mapped.
                val f = File(ctx.cacheDir, "deck${id}_${System.nanoTime()}.pcm")
                val rate = withContext(Dispatchers.IO) { Decoder.decode(ctx, uri, f) }
                NativeEngine.loadDeck(id, f.absolutePath, rate)
                curMix?.delete(); curMix = f
                name = uri.lastPathSegment?.substringAfterLast('/') ?: "Loaded"
                loading = false
                // Track is playable right away; stems are prepared in the background.
                prog = 0f
                prepJob = scope.launch(prepDispatcher) {
                    val key = uri.toString().hashCode().toUInt().toString(16)
                    val paths = StemCache.prepare(ctx, f, rate, key, { prog = it }, { !isActive })
                    if (isActive && paths != null) { NativeEngine.setStems(id, paths); prog = 2f }
                    else if (isActive) prog = -1f
                }
            } catch (e: Exception) { name = "Error: ${e.message}"; loading = false }
        }
    }
    LaunchedEffect(Unit) { while (true) { pos = NativeEngine.getPosition(id); delay(250) } }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("$title — $name", maxLines = 1)
            Text("%d:%02d".format(pos.toInt() / 60, pos.toInt() % 60))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch(arrayOf("audio/*")) }, enabled = !loading) { Text("Load") }
                Button(onClick = { playing = !playing; NativeEngine.setPlaying(id, playing) }, enabled = !loading) {
                    Text(if (playing) "Pause" else "Play")
                }
            }
            if (prog in 0f..1f) {
                Text("Preparing stems… ${(prog * 100).toInt()}%  (you can already play)", fontSize = 12.sp)
                LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth())
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                for (i in 0..3) FilterChip(
                    selected = on[i], enabled = prog == 2f, modifier = Modifier.weight(1f),
                    onClick = { on[i] = !on[i]; NativeEngine.setStemVolume(id, i, if (on[i]) 1f else 0f) },
                    label = { Text(labels[i], fontSize = 12.sp, maxLines = 1) }
                )
            }
            Text("Volume"); Slider(vol, { vol = it; NativeEngine.setVolume(id, it) })
            Text("Tempo ${"%.0f".format((tempo - 1) * 100)}%")
            Slider(tempo, { tempo = it; NativeEngine.setTempo(id, it) }, valueRange = 0.8f..1.2f)
        }
    }
}
