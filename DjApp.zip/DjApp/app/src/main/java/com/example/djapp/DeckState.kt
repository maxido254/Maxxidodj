package com.example.djapp

import android.content.Context
import android.net.Uri
import android.os.Process
import android.provider.OpenableColumns
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.*
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import kotlin.math.*

/** One low-priority thread for stem prep: decks queue up and the audio thread is never starved. */
private val prepDispatcher = Executors.newSingleThreadExecutor { r ->
    Thread({ Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND); r.run() }, "stem-prep")
}.asCoroutineDispatcher()

object AppSettings {
    var tempoRange by mutableFloatStateOf(0.08f)      // +/- fraction
    var betterStems by mutableStateOf(true)           // HPSS separator vs. fast filters
}

class DeckState(val id: Int, val accent: Color, val dark: Color) {
    var name by mutableStateOf(if (id == 0) "DECK A" else "DECK B")
    var loaded by mutableStateOf(false)
    var loading by mutableStateOf(false)
    var playing by mutableStateOf(false)
    var bpm by mutableFloatStateOf(0f)
    var duration by mutableDoubleStateOf(0.0)
    var posSec by mutableDoubleStateOf(0.0)

    // Mixer / tempo
    var tempoPct by mutableFloatStateOf(0f)           // -range..+range
    var vol by mutableFloatStateOf(1f)

    // Effects
    var filter by mutableFloatStateOf(0f)
    var reverb by mutableFloatStateOf(0f)
    var room by mutableFloatStateOf(0.6f)
    var phaser by mutableFloatStateOf(0f)
    var phRate by mutableFloatStateOf(0.5f)

    // Stems
    val stemOn = mutableStateListOf(true, true, true, true)
    val stemLevel = mutableStateListOf(1f, 1f, 1f, 1f)
    var stemProg by mutableFloatStateOf(-1f)          // -1 none, 0..1 preparing, 2 ready
    val stemsReady get() = stemProg == 2f

    // Cue / hot cues / loops
    var cue = 0.0
    val hotcues = mutableStateListOf(-1.0, -1.0, -1.0, -1.0)
    var loopIn by mutableDoubleStateOf(-1.0)
    var loopOut by mutableDoubleStateOf(-1.0)
    var loopActive by mutableStateOf(false)
    var loopBeats by mutableFloatStateOf(0f)          // 0 = manual loop

    private var prepJob: Job? = null
    private var curMix: File? = null
    private var previewing = false

    val effectiveBpm get() = bpm * (1f + tempoPct)
    fun pos(): Double = NativeEngine.getPosition(id)

    // ---------------------------------------------------------------- transport
    fun togglePlay() { playing = !playing; NativeEngine.setPlaying(id, playing) }

    /** CDJ-style cue: playing -> back to cue & pause; paused elsewhere -> set cue; hold at cue -> preview. */
    fun cueDown() {
        val p = pos()
        when {
            playing -> { NativeEngine.setPlaying(id, false); playing = false; NativeEngine.seek(id, cue) }
            abs(p - cue) < 0.06 -> { previewing = true; NativeEngine.setPlaying(id, true) }
            else -> cue = p
        }
    }
    fun cueUp() {
        if (previewing) { previewing = false; NativeEngine.setPlaying(id, false); NativeEngine.seek(id, cue) }
    }

    fun hotcue(i: Int) {
        if (hotcues[i] < 0) hotcues[i] = pos() else NativeEngine.seek(id, hotcues[i])
    }
    fun clearHotcue(i: Int) { hotcues[i] = -1.0 }

    // ---------------------------------------------------------------- tempo / sync
    fun setTempoPct(p: Float) {
        tempoPct = p.coerceIn(-AppSettings.tempoRange, AppSettings.tempoRange)
        NativeEngine.setTempo(id, 1f + tempoPct)
    }
    /** Matches this deck's tempo to [other]'s current BPM. Returns false if a BPM is unknown. */
    fun syncTo(other: DeckState): Boolean {
        if (bpm <= 0f || other.bpm <= 0f) return false
        var ratio = other.effectiveBpm / bpm
        while (ratio > 1.5f) ratio /= 2f
        while (ratio < 0.75f) ratio *= 2f
        setTempoPct(ratio - 1f)
        return true
    }

    // ---------------------------------------------------------------- loops
    private fun pushLoop() = NativeEngine.setLoop(id, loopIn, loopOut, loopActive)

    fun beatLoop(beats: Float) {
        if (bpm <= 0f) return
        if (loopActive && loopBeats == beats) { exitLoop(); return }
        val s = pos()
        loopIn = s; loopOut = s + beats * 60.0 / bpm; loopBeats = beats; loopActive = true; pushLoop()
    }
    fun loopInSet() {
        loopIn = pos(); loopBeats = 0f
        if (loopOut > loopIn + 0.02) pushLoop() else { loopOut = -1.0; loopActive = false; pushLoop() }
    }
    /** "Loop out": closes the loop at the current position and starts looping. */
    fun loopOutSet() {
        val p = pos()
        if (loopIn < 0 || p <= loopIn + 0.02) return
        loopOut = p; loopBeats = 0f; loopActive = true; pushLoop()
    }
    fun exitLoop() { loopActive = false; if (loopIn >= 0 && loopOut > loopIn) pushLoop() }
    fun reloop() {
        if (loopIn >= 0 && loopOut > loopIn) { loopActive = true; pushLoop(); NativeEngine.seek(id, loopIn) }
    }
    fun halveLoop() {
        if (!loopActive) return
        val len = (loopOut - loopIn) / 2
        if (len < 0.02) return
        loopOut = loopIn + len; if (loopBeats > 0) loopBeats /= 2; pushLoop()
    }
    fun doubleLoop() {
        if (!loopActive) return
        loopOut = loopIn + (loopOut - loopIn) * 2; if (loopBeats > 0) loopBeats *= 2; pushLoop()
    }

    // ---------------------------------------------------------------- effects
    fun pushFilter() = NativeEngine.setFilter(id, filter)
    fun pushReverb() = NativeEngine.setReverb(id, reverb, room)
    fun pushPhaser() = NativeEngine.setPhaser(id, phaser, phRate)
    fun pushVolume() = NativeEngine.setVolume(id, vol)
    fun resetFx() {
        filter = 0f; reverb = 0f; phaser = 0f; pushFilter(); pushReverb(); pushPhaser()
    }

    // ---------------------------------------------------------------- stems
    private fun stemGain(i: Int) = if (stemOn[i]) stemLevel[i] else 0f
    fun pushStem(i: Int) = NativeEngine.setStemVolume(id, i, stemGain(i))
    fun toggleStem(i: Int) { stemOn[i] = !stemOn[i]; pushStem(i) }
    fun setStemLevel(i: Int, v: Float) { stemLevel[i] = v; if (!stemOn[i] && v > 0f) stemOn[i] = true; pushStem(i) }
    fun soloStem(i: Int) { for (j in 0..3) { stemOn[j] = j == i; pushStem(j) } }
    fun muteOnly(i: Int) { for (j in 0..3) { stemOn[j] = j != i; pushStem(j) } }
    fun resetStems() { for (j in 0..3) { stemOn[j] = true; stemLevel[j] = 1f; pushStem(j) } }

    // ---------------------------------------------------------------- loading
    fun load(ctx: Context, scope: CoroutineScope, uri: Uri) {
        prepJob?.cancel()
        stemProg = -1f; resetStemsUi()
        loading = true; loaded = false; name = "Decoding…"; playing = false; bpm = 0f; duration = 0.0; posSec = 0.0
        NativeEngine.setPlaying(id, false)
        cue = 0.0; loopActive = false; loopIn = -1.0; loopOut = -1.0; loopBeats = 0f
        for (i in 0..3) hotcues[i] = -1.0
        scope.launch {
            try {
                // Unique file per load: never overwrite a file the engine has mapped.
                val f = File(ctx.cacheDir, "deck${id}_${System.nanoTime()}.pcm")
                val rate = withContext(Dispatchers.IO) { Decoder.decode(ctx, uri, f) }
                NativeEngine.loadDeck(id, f.absolutePath, rate)
                curMix?.delete(); curMix = f
                name = displayName(ctx, uri)
                duration = NativeEngine.getDuration(id)
                loading = false; loaded = true
                launch(Dispatchers.Default) { bpm = BpmDetector.detect(f, rate) }
                // Track is playable right away; stems are prepared in the background.
                stemProg = 0f
                val sep: StemSeparator = if (AppSettings.betterStems) HpssSeparator() else LiteSeparator()
                prepJob = scope.launch(prepDispatcher) {
                    val key = uri.toString().hashCode().toUInt().toString(16)
                    val paths = StemCache.prepare(ctx, f, rate, key, { stemProg = it.coerceIn(0f, 1f) }, { !isActive }, sep)
                    if (isActive && paths != null) { NativeEngine.setStems(id, paths); stemProg = 2f }
                    else if (isActive) stemProg = -1f
                }
            } catch (e: Exception) { name = "Error: ${e.message}"; loading = false }
        }
    }

    private fun resetStemsUi() { for (i in 0..3) { stemOn[i] = true; stemLevel[i] = 1f } }

    private fun displayName(ctx: Context, uri: Uri): String {
        var n: String? = null
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) n = it.getString(0)
            }
        } catch (_: Exception) {}
        return (n ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Loaded").substringBeforeLast('.')
    }
}

/** Estimates BPM from a 75 s slice of the decoded track (onset envelope + autocorrelation). */
object BpmDetector {
    fun detect(pcm: File, rate: Int): Float = try { analyze(pcm, rate) } catch (_: Exception) { 0f }

    private fun analyze(pcm: File, rate: Int): Float {
        val hop = 256
        val total = pcm.length() / 4
        val start = if (total > rate * 110L) rate * 30L else 0L
        val count = minOf(total - start, rate * 75L)
        if (count < rate * 8L) return 0f
        val n = (count / hop).toInt()
        val env = FloatArray(n)
        RandomAccessFile(pcm, "r").use { raf ->
            raf.seek(start * 4)
            val blocksPer = 64
            val buf = ByteArray(hop * 4 * blocksPer)
            val a = (1.0 - exp(-2.0 * PI * 200.0 / rate)).toFloat()
            var lp = 0f; var idx = 0
            while (idx < n) {
                val blocks = minOf(blocksPer, n - idx)
                raf.readFully(buf, 0, blocks * hop * 4)
                val sb = ByteBuffer.wrap(buf, 0, blocks * hop * 4).order(ByteOrder.nativeOrder()).asShortBuffer()
                for (b in 0 until blocks) {
                    var eLow = 0f; var eAll = 0f
                    for (i in 0 until hop) {
                        val j = (b * hop + i) * 2
                        val m = (sb.get(j) + sb.get(j + 1)) * (0.5f / 32768f)
                        lp += a * (m - lp); eLow += lp * lp; eAll += m * m
                    }
                    env[idx++] = sqrt(eLow / hop) + 0.5f * sqrt(eAll / hop)
                }
            }
        }
        // Onset strength: positive change of compressed energy, minus local mean.
        val onset = FloatArray(n)
        for (i in 1 until n) onset[i] = max(0f, ln(1f + 100f * env[i]) - ln(1f + 100f * env[i - 1]))
        val win = 70
        val sm = FloatArray(n)
        var acc = 0f
        for (i in 0 until n) { acc += onset[i]; if (i >= win) acc -= onset[i - win]; sm[i] = acc / min(i + 1, win) }
        for (i in 0 until n) onset[i] = max(0f, onset[i] - sm[i])

        val envRate = rate / hop.toDouble()
        val minLag = floor(envRate * 60 / 180).toInt()
        val maxLag = ceil(envRate * 60 / 65).toInt()
        val maxAc = min(maxLag * 2 + 1, n / 2)
        val ac = FloatArray(maxAc + 1)
        for (lag in minLag..maxAc) {
            var s = 0f
            for (i in 0 until n - lag) s += onset[i] * onset[i + lag]
            ac[lag] = s / (n - lag)
        }
        var best = -1; var bestScore = 0f
        for (lag in minLag..min(maxLag, maxAc)) {
            val s = ac[lag] + if (lag * 2 <= maxAc) 0.5f * ac[lag * 2] else 0f
            if (s > bestScore) { bestScore = s; best = lag }
        }
        if (best <= minLag || best >= maxAc) return 0f
        val y0 = ac[best - 1]; val y1 = ac[best]; val y2 = ac[best + 1]
        val den = y0 - 2 * y1 + y2
        val off = if (den != 0f) (0.5f * (y0 - y2) / den).coerceIn(-0.5f, 0.5f) else 0f
        var bpm = (60.0 * envRate / (best + off)).toFloat()
        while (bpm < 80f) bpm *= 2f
        while (bpm > 175f) bpm /= 2f
        return (bpm * 10f).roundToInt() / 10f
    }
}
