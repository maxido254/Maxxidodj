package com.example.djapp

object NativeEngine {
    init { System.loadLibrary("djengine") }
    external fun start(): Boolean
    external fun stop()
    /** Loads the full mix (instant play). Resets position. */
    external fun loadDeck(deck: Int, pcmPath: String, sampleRate: Int)
    /** Swaps in 4 stems (vocals, drums, bass, other) without interrupting playback. */
    external fun setStems(deck: Int, paths: Array<String>)
    external fun setStemVolume(deck: Int, stem: Int, volume: Float)
    external fun setPlaying(deck: Int, playing: Boolean)
    external fun setVolume(deck: Int, volume: Float)
    external fun setTempo(deck: Int, tempo: Float)
    external fun setCrossfader(x: Float)
    external fun getPosition(deck: Int): Double
}
